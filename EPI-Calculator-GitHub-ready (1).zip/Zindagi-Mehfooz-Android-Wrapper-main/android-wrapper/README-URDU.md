# EPI Calculator — Android Studio پروجیکٹ

## کھولنے کا طریقہ
1. Android Studio (Koala 2024.1.1 یا نیا) انسٹال ہو۔ JDK 17 اس کے ساتھ آتا ہے۔
2. ZIP کھولیں → Android Studio میں **File → Open** → یہ فولڈر (جس میں `app` اور `build.gradle.kts` ہیں) چنیں۔
3. پہلی بار Gradle Sync خود چلے گا (انٹرنیٹ چاہیے)۔ SDK 34 نہ ہو تو Studio خود انسٹال کرنے کو کہے گا۔
4. فون USB سے جوڑیں (USB debugging آن) → ▶ Run۔

## APK بنانا
- **Build → Build Bundle(s) / APK(s) → Build APK(s)** — فائل: `app/build/outputs/apk/debug/app-debug.apk`

## ضروری باتیں
- Package: `org.zm.calculator`، ورژن 1.3.0 (کوڈ 4)۔
- اگر فون میں GitHub سے بنی پرانی ایپ لگی ہے تو Studio والی APK اس کے اوپر انسٹال نہیں ہوگی (دستخط الگ ہوتے ہیں)۔ پہلے پرانی ایپ ہٹانی پڑے گی، اور ایپ کا ڈیٹا بھی مٹ جائے گا — پہلے بیک اپ لے لیں۔
- پہلی بار "From Download" / "From WhatsApp" پر "All files access" کی سیٹنگ کھلتی ہے: EPI Calculator کے آگے سوئچ آن کریں۔
- ایپ کی ویب فائلیں: `app/src/main/assets/` (index.html، js، css)۔ Kotlin کوڈ: `app/src/main/java/org/zm/calculator/`۔
- شروع کی تصویر (3.5 سیکنڈ): `app/src/main/assets/splash.jpg`۔
