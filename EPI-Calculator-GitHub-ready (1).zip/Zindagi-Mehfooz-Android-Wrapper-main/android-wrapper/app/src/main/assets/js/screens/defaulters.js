// ---------- PAGE 8: Defaulter Children — group by address or by defaulted vaccine ----------
// Addresses are typed by hand across many visits/vaccinators, so the same
// physical place often shows up with different capitalization or a small
// spelling slip ("Banho Khushk" / "banhu khushak" / "Banho Khushak"). These
// helpers make address grouping ignore case and treat close spelling
// variants as the same place, instead of splitting them into separate rows.
// =====================================================================
// ADDRESS CLEANING + GROUPING (shared by Daily "Village-wise List" and
// Defaulters "By Address")
//
// A printed address looks like:
//   "<village text> <mobile no.> <more village text> <UC> <Tehsil>"
// Only the VILLAGE text identifies the place. So we:
//   1. remove mobile numbers (keeping the text on BOTH sides of them),
//   2. remove the word "village" in any spelling (Vill / Vilage / گاؤں ...),
//   3. remove the trailing UC / Tehsil / District names,
//   4. compare what is left ignoring case, spelling slips, running letters,
//      initials (M = Muhammad, B = Bozdar), word order and extra words.
// =====================================================================

// Urdu / Arabic-Indic digits -> ASCII so phone numbers written in Urdu digits are caught.
function asciiDigits(s){
  return (s || '')
    .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0));
}

// Words that only mean "village" (any spelling / language) - never part of the place name.
const VILLAGE_WORD_RE = new RegExp(
  '(?<![\\p{L}\\p{N}])(?:' +
  'v[ie]+l+[ae]*g+[ea]*s?|vil+a?ge?s?|vill?g|vlg|vilaj|villaj|vill?|' +
  'gaon|gaoon|gaoun|goan|gaun|gawn|gawan|' +
  '\u06af\u0627\u0624\u06ba|\u06af\u0627\u0648\u06ba|\u06af\u0627\u0648\u0646|\u06af\u0648\u0627\u0646|\u0648\u0644\u06cc\u062c|\u0648\u0644\u0627\u0626\u06cc\u062c' +
  ')(?![\\p{L}\\p{N}])[\\s:.\\-]*', 'giu');

// A phone number = a run of digits (spaces / dashes / dots allowed inside) with 7+ digits,
// optionally written as "+92 ...", with an optional label in front ("Mobile:", "Cell#", "Ph").
const PHONE_RE = /(?:(?<![\p{L}])(?:mobile|mob|cell|phone|ph|contact|cont|tel|whatsapp|no|number)\b\.?\s*(?:no|number|#)?\.?\s*[:#\-]?\s*)?\+?\(?\d[\d\s\-.()]{5,}\d/giu;

function stripNoiseFromAddress(s){
  return asciiDigits(s)
    // invisible / odd whitespace (NBSP, zero-width, tabs) -> normal space
    .replace(/[\u00A0\u1680\u2000-\u200F\u2028\u2029\u202F\u205F\u3000\uFEFF]/g, ' ')
    // mobile / phone numbers ONLY (the words on both sides stay: they are address)
    .replace(PHONE_RE, m => (m.replace(/\D/g, '').length >= 7 ? ' ' : m))
    // the word "village" in any spelling - anywhere in the address
    .replace(VILLAGE_WORD_RE, ' ')
    // leftover separators left by the removals
    .replace(/[\s,;|/]+/g, ' ')
    .trim();
}

// Keep old name as alias so any earlier call sites still work.
function stripPhoneFromAddress(s){ return stripNoiseFromAddress(s); }

// ---------- trailing District / Tehsil / UC removal ----------
function addrWordKey(w){
  return (w || '').toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
}
function addrPhraseWords(str){
  return (str || '').replace(/[-–—]/g, ' ').split(/\s+/).map(addrWordKey).filter(Boolean);
}

let _locSuffixIndex = null;
function getLocationSuffixIndex(){
  const data = (typeof window !== 'undefined' && window.SINDH_LOCATIONS) || null;
  if (_locSuffixIndex && _locSuffixIndex.src === data) return _locSuffixIndex;
  const idx = { src: data, districts: [], tehsils: [] };
  if (data) {
    Object.keys(data).forEach(dist => {
      idx.districts.push(addrPhraseWords(dist));
      Object.keys(data[dist] || {}).forEach(teh => {
        const full = addrPhraseWords(teh);
        const ucs = [];
        (data[dist][teh] || []).forEach(entry => {
          const name = typeof entry === 'string' ? entry : (entry && (entry.name || entry.uc)) || '';
          // "Jarwar (UC-46)", "Mirpur Mathelo- Mirpur Mathelo 01", "Mirpurkhas-3" ...
          const noParen = name.replace(/\([^)]*\)/g, ' ');
          const variants = [noParen].concat(noParen.split(/\s*[-–—]\s*/));
          variants.forEach(v => {
            const w = addrPhraseWords(v);
            if (w.length) ucs.push(w);
            const noNum = w.filter((x, i) => !(i === w.length - 1 && /^\d+$/.test(x)));
            if (noNum.length && noNum.length !== w.length) ucs.push(noNum);
          });
        });
        // Tehsil is often printed short (first word only): "Mirpur Mathelo" -> "Mirpur"
        const spellings = [full];
        if (full.length > 1 && full[0].length > 2) spellings.push([full[0]]);
        spellings.forEach(w => idx.tehsils.push({ words: w, ucs }));
      });
    });
    const byLen = (x, y) => y.words.length - x.words.length;
    idx.tehsils.sort(byLen);
    idx.districts.sort((x, y) => y.length - x.length);
  }
  _locSuffixIndex = idx;
  return idx;
}

function addrSameWord(a, b){
  if (a === b) return true;
  if (!a || !b) return false;
  const fa = phoneticFoldToken(a), fb = phoneticFoldToken(b);
  if (fa === fb) return true;
  return Math.max(a.length, b.length) >= 5 && levenshteinDistance(fa, fb) <= 1;
}

// Does phrase (array of keys) end exactly at position `end` of keys? -> length matched, or 0
function phraseEndsAt(keys, end, phrase){
  const n = phrase.length;
  if (!n || end - n < 0) return 0;
  for (let i = 0; i < n; i++) if (!addrSameWord(keys[end - n + i], phrase[i])) return 0;
  return n;
}

const ADDRESS_TAIL_FILLER = new Set(['taluka', 'talka', 'tehsil', 'tahsil', 'tal', 'district', 'dist', 'dst', 'uc', 'union', 'council']);

// Drops "<UC> <Tehsil> [<District>]" from the END of the address words.
function stripLocationSuffix(words){
  if (!words.length) return words;
  const idx = getLocationSuffixIndex();
  const keys = words.map(addrWordKey);
  let end = words.length;
  const dropFiller = () => { while (end > 1 && (ADDRESS_TAIL_FILLER.has(keys[end - 1]) || !keys[end - 1])) end--; };

  dropFiller();
  for (const d of idx.districts) { const n = phraseEndsAt(keys, end, d); if (n && end - n > 0) { end -= n; break; } }
  dropFiller();

  let matchedTehsil = null;
  for (const t of idx.tehsils) {
    const n = phraseEndsAt(keys, end, t.words);
    if (n && end - n > 0) { matchedTehsil = t; end -= n; break; }
  }
  dropFiller();

  // UC name that sits just before the Tehsil (or, with no Tehsil printed, the logged-in UC)
  let ucCandidates = [];
  if (matchedTehsil) ucCandidates = matchedTehsil.ucs;
  else {
    try {
      const login = (typeof epiReadLogin === 'function') ? epiReadLogin() : null;
      if (login && login.uc) ucCandidates = [addrPhraseWords(login.uc.replace(/\([^)]*\)/g, ' '))];
    } catch (e) { /* ignore */ }
  }
  ucCandidates = ucCandidates.slice().sort((x, y) => y.length - x.length);
  for (const u of ucCandidates) { const n = phraseEndsAt(keys, end, u); if (n && end - n > 0) { end -= n; break; } }
  dropFiller();

  return words.slice(0, Math.max(end, 1));
}

// The village part of an address, in its original spelling/case ('' if nothing usable).
function addressVillageCore(s){
  const cleaned = stripNoiseFromAddress(s);
  if (!cleaned) return '';
  const words = cleaned.split(/\s+/);
  const core = stripLocationSuffix(words).join(' ').trim();
  return core || cleaned;
}

// Clean display form of an address: no phone / no "village" label / no UC + Tehsil tail.
function cleanAddressForDisplay(s){
  return addressVillageCore(s).replace(/\s+/g, ' ').trim();
}

// Phonetic / spelling variants common in Sindhi-Urdu romanization.
// Each group collapses to the first (canonical) form.
const ADDRESS_SYNONYMS = [
  ['muhammad', 'mohd', 'muhd', 'md', 'mohammad', 'mohammed', 'muhammed', 'mahmad', 'mohamad', 'muhamad'],
  ['yar', 'yaar'],
  ['ahmad', 'ahmed'],
  ['hussain', 'husain', 'hosein'],
  ['lund', 'lound', 'loond'],
  ['pitafi', 'patafi', 'petafi', 'pitafe', 'pitafee', 'pitafy'],
  ['kori', 'kore', 'korai', 'koree'],
  ['gabol', 'gabole', 'gabool'],
  ['mirani', 'meerani', 'meeranee'],
  ['mir', 'meer', 'meeer'],
  ['bozdar', 'bozdaar', 'buzdar', 'bozdr', 'bozdaar'],
  ['khushk', 'khushak', 'khushik', 'khushke'],
  ['banhu', 'banho', 'banhoo'],
  ['mewo', 'mevo', 'meywo', 'mewoo'],
];

const ADDRESS_SYNONYM_MAP = (() => {
  const m = Object.create(null);
  ADDRESS_SYNONYMS.forEach(group => {
    const canon = group[0];
    group.forEach(v => { m[v] = canon; });
  });
  return m;
})();

// Spelling-variant fold per word: banho/banhu, khushk/khushak, doubled letters,
// oo/u, ee/i, aa/a, ph/f, w/v, q/k ...  ("Mewo" == "Mevo", "Meer" == "Mir")
function phoneticFoldToken(w){
  if (!w || /^[\d,]+$/.test(w) || /[^\u0000-\u024F]/.test(w)) return w;   // numbers / Urdu script untouched
  return w
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/(.)\1+/g, '$1')            // doubled letters
    .replace(/ph/g, 'f')
    .replace(/[wv]/g, 'v')
    .replace(/q/g, 'k')
    .replace(/(ou|oo|o)/g, 'u')
    .replace(/(ee|ea|ei|ie|y$)/g, 'i')
    .replace(/(aa|ai|ay|ae)/g, 'a')
    .replace(/(.)\1+/g, '$1');
}

function normalizeAddressText(s){
  let t = stripNoiseFromAddress(s)
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, '')       // periods, commas, dashes ... ("B." -> "b")
    .replace(/\s+/g, ' ')
    .trim();
  t = t.split(' ').map(tok => phoneticFoldToken(ADDRESS_SYNONYM_MAP[tok] || tok)).join(' ');
  return t.replace(/\s+/g, ' ').trim();
}

// Consonant-only "skeleton" with all spaces removed: "Banho Khushk"/"banhu khushak" -> "bnhkhshk"
function addressSkeleton(s){
  return (s || '').replace(/\s+/g, '').replace(/[aeiou]/g, '');
}

function splitAddressLocality(addr){
  const idx = addr.indexOf(',');
  if (idx === -1) return { locality: addr, rest: '' };
  return { locality: addr.slice(0, idx).trim(), rest: addr.slice(idx + 1).trim() };
}

function levenshteinDistance(a, b){
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = new Array(n + 1), curr = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i-1] === b[j-1] ? 0 : 1;
      curr[j] = Math.min(curr[j-1] + 1, prev[j] + 1, prev[j-1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

// Very common tribe / first-name / place words. They can never, on their own, prove two
// addresses are the same place ("Bozdar" alone must not swallow every Bozdar village).
const ADDRESS_GENERIC_WORDS = new Set(
  ['muhammad','khan','shah','syed','sayed','sheikh','shaikh','baloch','bozdar','khushk','gabol','mirani',
   'pitafi','lund','kori','jatoi','mahar','chachar','soomro','jamali','solangi','jarwar','mathelo','mirpur',
   'goth','mir','ghulam','abdul','haji','wala']
    .map(w => phoneticFoldToken(w)));

function addrIsInitial(t){ return t.length === 1 && /\p{L}/u.test(t); }

// One word matches another if equal / one-letter initial / real prefix / small typo.
function addressTokensMatch(a, b){
  if (a === b) return true;
  if (!a || !b) return false;
  if (addrIsInitial(a) && b.startsWith(a)) return true;       // M -> muhammad, B -> bozdar
  if (addrIsInitial(b) && a.startsWith(b)) return true;
  const [sh, lo] = a.length <= b.length ? [a, b] : [b, a];
  if (sh.length >= 3 && lo.startsWith(sh) && sh.length / lo.length >= 0.6) return true;   // bozd -> bozdar
  const maxLen = Math.max(a.length, b.length);
  if (maxLen < 4) return false;
  return levenshteinDistance(a, b) <= (maxLen <= 5 ? 1 : 2);
}

// A word that can actually identify a place: 3+ letters and not a generic tribe/name word.
function addressSignificantToken(t){
  return t.length >= 3 && !ADDRESS_GENERIC_WORDS.has(t);
}

// Every word of `S` must pair with a DIFFERENT word of `L`, in ANY order.
function tokensSubsetMatch(S, L){
  const used = new Array(L.length).fill(false);
  let significant = false;
  // match longer / more specific words first so initials don't steal their partner
  const order = S.map((t, i) => i).sort((i, j) => S[j].length - S[i].length);
  for (const i of order) {
    let hit = -1;
    // exact / full-word match preferred over initial / prefix match
    for (let j = 0; j < L.length && hit < 0; j++) if (!used[j] && S[i] === L[j]) hit = j;
    for (let j = 0; j < L.length && hit < 0; j++) if (!used[j] && addressTokensMatch(S[i], L[j])) hit = j;
    if (hit < 0) return false;
    used[hit] = true;
    // Proof of "same place" must come from a real word match (not from an initial like
    // "B" matching "Banho") and from a word that is not just a common tribe/name word.
    if (addressSignificantToken(S[i]) && !addrIsInitial(S[i]) && !addrIsInitial(L[hit])) significant = true;
  }
  return significant;
}

// Two village names count as the same place when:
//  - equal after case / spelling / synonym folding, or
//  - equal with spaces removed ("BanhoKhushk" = "Banho Khushk") or 1-2 typos apart, or
//  - the words line up in ANY order, allowing initials and extra words
//    ("M Ali B" = "Muhammad Ali Bozdar";  "Abc Mewo Bozdar" = "Mewo Bozdar Abc" = "Vill Mewo Bozdar")
function localitiesMatch(a, b){
  if (a === b) return true;
  if (!a || !b) return false;

  const ca = a.replace(/\s+/g, ''), cb = b.replace(/\s+/g, '');
  if (ca === cb) return true;
  const cMax = Math.max(ca.length, cb.length);
  if (cMax >= 5 && levenshteinDistance(ca, cb) <= Math.max(1, Math.min(2, Math.round(cMax * 0.12)))) return true;
  if (ca[0] === cb[0] && cMax >= 6) {
    const sa = addressSkeleton(a), sb = addressSkeleton(b);
    if (sa.length >= 4 && sa === sb) return true;
  }

  const ta = a.split(/\s+/).filter(Boolean);
  const tb = b.split(/\s+/).filter(Boolean);
  if (!ta.length || !tb.length) return false;
  const [S, L] = ta.length <= tb.length ? [ta, tb] : [tb, ta];
  return tokensSubsetMatch(S, L);
}

// Groups any list of { address } items into { "<village label>": [items] }.
function groupItemsByAddress(items){
  const NO_ADDR = 'No address recorded';
  const noAddr = [];
  const prepared = [];
  (items || []).forEach(it => {
    const core = cleanAddressForDisplay((it && it.address) || '');
    if (!core) { noAddr.push(it); return; }
    prepared.push({ it, core, norm: normalizeAddressText(core) });
  });
  // Deterministic order: short / plain forms first so they seed the clusters.
  prepared.sort((x, y) => (x.norm.split(' ').length - y.norm.split(' ').length) || x.norm.localeCompare(y.norm));

  const clusters = [];
  prepared.forEach(p => {
    const c = clusters.find(c => c.norms.some(n => localitiesMatch(n, p.norm)));
    if (c) {
      c.items.push(p.it);
      c.counts[p.core] = (c.counts[p.core] || 0) + 1;
      if (!c.norms.includes(p.norm)) c.norms.push(p.norm);
    } else {
      clusters.push({ norms: [p.norm], items: [p.it], counts: { [p.core]: 1 } });
    }
  });

  const groups = {};
  const addGroup = (label, list) => {
    let key = label, n = 2;
    while (Object.prototype.hasOwnProperty.call(groups, key)) key = `${label} (${n++})`;
    groups[key] = list;
  };
  clusters.forEach(c => {
    // label = spelling used most often; tie -> the fuller (longer) one
    const label = Object.entries(c.counts).sort((x, y) => (y[1] - x[1]) || (y[0].length - x[0].length))[0][0];
    addGroup(label, c.items);
  });
  if (noAddr.length) addGroup(NO_ADDR, noAddr);
  return groups;
}

// Splits ONLY the uploaded Children Defaulters Report entries against the
// Daily Registry records: anyone whose overdue vaccine now appears in our
// own records counts as covered. Nothing is stored; this is
// recomputed every time a view opens.
function splitDefaultersByCoverage(){
  const store = loadStore();
  const uploaded = Object.values(loadDefaultersStore());
  const still = [], covered = [];
  uploaded.forEach(def => {
    const cov = computeDefaulterCoverage(def, store);
    (defaulterStatusOf(cov) === 'covered' ? covered : still).push(def);
  });
  return { still, covered };
}

function groupDefaultersByAddress(defaulters){
  // Same rules as the Daily village-wise list: mobile numbers, the word
  // "village" and the trailing UC / Tehsil are ignored, and spelling / case /
  // initials / word-order variants of one village land in ONE result.
  return groupItemsByAddress(defaulters);
}

function groupDefaultersByVaccine(defaulters){
  const groups = {};
  (defaulters || []).forEach(def => {
    (def.defaultedVaccines || []).forEach(tag => {
      if (!groups[tag]) groups[tag] = [];
      groups[tag].push(def);
    });
  });
  return groups;
}

function defVaccineLabel(tag){ return EPI_SHORT[tag] || TT_LABELS[tag] || tag; }

// Turns a plain list of defaulters into the { def, cov, status } rows that
// both renderDefaulterDetailCards and buildDefaultersPdf work with.
// Records saved by an older build carry no EPI No and would just show a dash
// forever with no explanation. Wherever that happens, say what to do about it.
function epiMissingNoticeHtml(list){
  const missing = (list || []).filter(d => !d.epiNo).length;
  if (!missing) return '';
  const total = (list || []).length;
  return `<div class="card" style="margin-top:0;border-color:#e2b8a3;background:#fdf4ef;">
    <div class="note" style="margin:0;color:#9d174d;">
      <b>EPI No missing on ${missing} of ${total} records.</b> They were saved before the EPI No could be read.
      Go to the main menu → <b>Back to Add New PDF Files</b> → <b>📋 Defaulters List</b>, pick the
      <b>Children Defaulters Report</b> again and press <b>Process and Save Data</b>. The EPI No will then fill in everywhere.
    </div></div>`;
}

function setEpiNotice(elId, list){
  const el = document.getElementById(elId);
  if (el) el.innerHTML = epiMissingNoticeHtml(list);
}

function defaulterResultsFor(list){
  const store = loadStore();
  return (list || []).map(def => {
    const cov = computeDefaulterCoverage(def, store);
    return { def, cov, status: defaulterStatusOf(cov) };
  });
}

function renderDefaulterDetailCards(list, offset){
  offset = offset || 0;
  const store = loadStore();
  return list.map((def, idx0) => {
    const idx = idx0 + offset;
    const cov = computeDefaulterCoverage(def, store);
    const status = defaulterStatusOf(cov);
    const badgeColor = status === 'covered' ? 'var(--accent)' : 'var(--danger)';
    let badgeLabel = status === 'covered' ? '✅ Covered' : '⚠ Still Defaulting';
    if (status === 'covered' && cov.coverageEvents && cov.coverageEvents.length) {
      const bits = cov.coverageEvents.map(ev => {
        const d = dmy(ev.date) || '—';
        const v = (ev.vaccineLabels || []).join(', ') || '—';
        return d + ' · ' + v;
      });
      badgeLabel = '✅ Covered — ' + bits.join(' | ');
    } else if (status === 'covered' && cov.coverageDetail && cov.coverageDetail.dateText) {
      badgeLabel = '✅ Covered — ' + cov.coverageDetail.dateText.replace(/\n/g, ' | ');
    }
    const dobText = def.dob ? `${String(def.dob.day).padStart(2,'0')}/${String(def.dob.month).padStart(2,'0')}/${def.dob.year}` : '—';
    const vaccineText = (def.defaultedVaccines.map(defVaccineLabel).join(', ')) || '—';
    const enrollText = [def.enrollmentCenter, def.enrollmentVaccinator].filter(Boolean).join(' / ') || '—';
    return `<article class="child-card result-card">
      <div class="qr-code"><span class="qr-label">EPI No</span><span class="qr-number">${def.epiNo ? escapeHtml(def.epiNo) : '—'}</span></div>
      <div class="qr-code"><span class="qr-label">QR Code</span><span class="qr-right"><span class="qr-number">${escapeHtml(def.id)}</span>${def.id ? `<button type="button" class="qr-copy-btn" data-qr-copy="${escapeHtml(def.id)}">📋 Copy</button>` : ''}</span></div>
      <div class="result-line"><span class="result-label">Status</span><span class="result-value" style="color:${badgeColor};font-weight:700;">${badgeLabel}</span></div>
      <div class="result-line"><span class="result-label">Name</span><span class="result-value person-name">${def.name ? escapeHtml(def.name) : 'Name not recorded'}</span></div>
      <div class="result-line"><span class="result-label">Father/Husband</span><span class="result-value">${def.fatherName ? escapeHtml(def.fatherName) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Date of Birth</span><span class="result-value">${dobText}</span></div>
      <div class="result-line"><span class="result-label">Defaulted Vaccine</span><span class="result-value">${escapeHtml(vaccineText)}</span></div>
      <div class="result-line"><span class="result-label">Due / Defaulted Date</span><span class="result-value">${dmy(def.dueDate) || '—'} / ${dmy(def.defaultedDate) || '—'}</span></div>
      <div class="result-address"><span class="result-label">Address</span><span class="result-value">${def.address ? escapeHtml(def.address) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Enrollment</span><span class="result-value">${escapeHtml(enrollText)}</span></div>
      <div class="result-line"><span class="result-label">Last Visited Center</span><span class="result-value">${def.lastVisitedCenter ? escapeHtml(def.lastVisitedCenter) : '—'}</span></div>
      <div class="result-meta"><span>No. ${idx + 1}</span><span>${escapeHtml(def.status || '')}</span></div>
    </article>`;
  }).join('');
}

let defDetailReturnTo = 'defaulterChildrenView';

function showDefDetailView(list, title, returnTo, summaryHtml){
  hideAllViews();
  document.getElementById('defDetailView').style.display = 'block';
  window.scrollTo(0, 0);
  document.getElementById('defDetailTitle').textContent = title;
  setEpiNotice('defDetailEpiNotice', list);
  const box = document.getElementById('defDetailTable');
  if (list && list.length) {
    renderPagedCards(box, list.length, (a, b) => renderDefaulterDetailCards(list.slice(a, b), a), summaryHtml || '');
  } else {
    box.innerHTML = (summaryHtml || '') + '<div style="color:var(--muted);">No records found.</div>';
  }
  lastRendered['defDetailTable'] = list || [];
  defDetailReturnTo = returnTo;
}

function showDefaulterChildrenView(){
  hideAllViews();
  document.getElementById('defaulterChildrenView').style.display = 'block';
  window.scrollTo(0, 0);
  // Recomputed on every visit, so the split always reflects the newest Daily
  // Registry data without the user having to do anything.
  const { still, covered } = splitDefaultersByCoverage();
  // Records saved by an older version have no EPI No and would silently show a
  // dash forever. Say so plainly instead, with the fix.
  const all = still.concat(covered);
  const noEpi = all.filter(d => !d.epiNo).length;
  const epiNote = noEpi
    ? `<div class="card" style="margin-top:0;border-color:#e2b8a3;background:#fdf4ef;"><div class="note" style="margin:0;color:#9d174d;">${noEpi} of ${all.length} saved defaulters have no <b>EPI No</b> — they were saved before it could be read. Upload the <b>Children Defaulters Report</b> again and press Process to fill them in.</div></div>`
    : '';
  document.getElementById('defChildrenCounts').innerHTML = ((still.length + covered.length)
    ? `<div class="card" style="margin-top:0;"><div class="age-grid">
         <div class="age-box"><span>⚠ Still to chase</span><span class="n" style="color:var(--danger);">${still.length}</span></div>
         <div class="age-box"><span>✅ Covered</span><span class="n" style="color:var(--accent);">${covered.length}</span></div>
       </div></div>`
    : '') + epiNote;
}

function showDefCoveredView(){
  const { covered } = splitDefaultersByCoverage();
  // Two results: (1) counts by vaccine that was covered, (2) full detail list.
  const byVac = {};
  const store = loadStore();
  covered.forEach(def => {
    const cov = computeDefaulterCoverage(def, store);
    const tags = (cov.coveredTags && cov.coveredTags.length)
      ? cov.coveredTags
      : (def.defaultedVaccines || []);
    tags.forEach(t => { byVac[t] = (byVac[t] || 0) + 1; });
  });
  const order = (typeof DEFAULTER_VACCINE_ORDER !== 'undefined' && DEFAULTER_VACCINE_ORDER.length)
    ? DEFAULTER_VACCINE_ORDER
    : Object.keys(byVac);
  const vacRows = order.filter(t => byVac[t]).map(t =>
    `<tr><td class="ct-label">${escapeHtml(defVaccineLabel(t))}</td><td class="ct-n">${byVac[t]}</td></tr>`
  ).join('');
  const summaryHtml = covered.length
    ? `<div class="card count-table-card" style="margin-bottom:12px;">
         <h2 class="ct-title">Covered by Vaccine</h2>
         <table class="count-table">
           <thead><tr><th>Vaccine</th><th>Count</th></tr></thead>
           <tbody>${vacRows || '<tr><td colspan="2" class="ct-empty">There is Nothing</td></tr>'}</tbody>
         </table>
       </div>
       <h2 style="font-size:15px;margin:4px 0 10px;text-align:center;">Complete Details</h2>`
    : '';
  showDefDetailView(covered, `✅ Covered — ${covered.length}`, 'defaulterChildrenView', summaryHtml);
}

var lastDefSource = 'report';

function showDefByAddressView(stillList, emptyMsg){
  hideAllViews();
  document.getElementById('defByAddressView').style.display = 'block';
  window.scrollTo(0, 0);
  stillList = stillList || splitDefaultersByCoverage().still;
  emptyMsg = emptyMsg || 'Nothing left to chase — either no Defaulters List has been processed, or everyone on it has been covered.';
  setEpiNotice('defByAddressEpiNotice', stillList);
  const groups = groupDefaultersByAddress(stillList);
  const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0]));
  const listEl = document.getElementById('defByAddressList');
  if (!entries.length) {
    listEl.innerHTML = `<div class="card"><div style="color:var(--muted);">${emptyMsg}</div></div>`;
    return;
  }
  listEl.innerHTML = `<div class="card">${entries.map(([addr, list], i) => `
    <div class="date-row addr-row">
      <button type="button" class="addr-row-main" data-i="${i}">
        <span class="dname">📍 ${escapeHtml(addr)}</span>
        <span class="dcount">${list.length} ${list.length === 1 ? 'record' : 'records'}</span>
      </button>
      <button type="button" class="age-pdf-btn" data-i="${i}" title="Share / Download PDF for ${escapeHtml(addr)}">📤</button>
    </div>`).join('')}</div>`;
  listEl.querySelectorAll('.addr-row-main').forEach((btn, i) => {
    const [addr, list] = entries[i];
    btn.addEventListener('click', () => showDefDetailView(list, `📍 ${addr}`, 'defByAddressView'));
  });
  listEl.querySelectorAll('.date-row.addr-row .age-pdf-btn').forEach((btn, i) => {
    const [addr, list] = entries[i];
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      runDefaultersExportFlow(`Defaulters — ${addr}`, defaulterResultsFor(list), 'address-' + (i + 1));
    });
  });
}

function showDefByVaccineView(stillList, emptyMsg){
  hideAllViews();
  document.getElementById('defByVaccineView').style.display = 'block';
  window.scrollTo(0, 0);
  stillList = stillList || splitDefaultersByCoverage().still;
  emptyMsg = emptyMsg || 'Nothing left to chase — either no Defaulters List has been processed, or everyone on it has been covered.';
  setEpiNotice('defByVaccineEpiNotice', stillList);
  const groups = groupDefaultersByVaccine(stillList);
  const order = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2','TT1','TT2','TT3','TT4','TT5'];
  const present = order.filter(t => groups[t] && groups[t].length);
  const gridEl = document.getElementById('defByVaccineGrid');
  if (!present.length) {
    gridEl.innerHTML = `<div style="color:var(--muted);">${emptyMsg}</div>`;
    return;
  }
  gridEl.innerHTML = present.map(t => `
    <div class="epi-box clickable" data-tag="${t}">
      <div class="epi-box-top">
        <div class="n">${groups[t].length}</div>
        <button type="button" class="age-pdf-btn" data-tag="${t}" title="Share / Download PDF for ${escapeHtml(defVaccineLabel(t))}" aria-label="Share or download PDF for ${escapeHtml(defVaccineLabel(t))} defaulters">📤</button>
      </div>
      <div class="l">${defVaccineLabel(t)}</div>
    </div>`).join('');
  gridEl.querySelectorAll('.epi-box').forEach(box => {
    const tag = box.dataset.tag;
    box.addEventListener('click', () => showDefDetailView(groups[tag], `💉 ${defVaccineLabel(tag)} — Defaulters`, 'defByVaccineView'));
  });
  gridEl.querySelectorAll('.age-pdf-btn').forEach(btn => {
    const tag = btn.dataset.tag;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      runDefaultersExportFlow(`${defVaccineLabel(tag)} — Defaulters`, defaulterResultsFor(groups[tag]), 'vaccine-' + tag);
    });
  });
}

document.getElementById('btnGoDefaulterChildren').addEventListener('click', showDefaulterChildrenView);
document.getElementById('btnGoDefByAddress').addEventListener('click', () => {
  lastDefSource = 'report';
  showDefByAddressView();
});
document.getElementById('btnGoDefByVaccine').addEventListener('click', () => {
  lastDefSource = 'report';
  showDefByVaccineView();
});
document.getElementById('btnGoDefCovered').addEventListener('click', showDefCoveredView);

// Checks one defaulter entry against the saved children/women records: which
// of the defaulted vaccine(s) have already been given (per our own records),
// and — when covered — exactly when and by whom, reusing the same per-visit
// breakdown used everywhere else in the app.
function computeDefaulterCoverage(def, store){
  const rec = store[def.id];
  if (!rec) return { found: false, coveredTags: [], allCovered: false, coverageDetail: null, coverageEvents: [] };
  const coveredTags = def.defaultedVaccines.filter(tag => {
    const isTt = tag.startsWith('TT');
    const tags = isTt ? classifyTT(rec.doses) : classifyEpi(rec.doses);
    return tags.includes(tag);
  });
  // A defaulter entry can list two vaccines together (e.g. "Penta2, Measles2")
  // when the child is behind on more than one dose at the same time. Giving
  // EITHER one of the two per the EPI schedule — or both — is enough to
  // consider the child covered; it is not required that every listed vaccine
  // be given before counting it as covered.
  const allCovered = coveredTags.length > 0;
  const coverageDetail = coveredTags.length ? dateAndVaccinatorText(rec) : null;

  // Per-visit events that actually delivered the defaulted vaccine(s) —
  // used on the Covered detail card: "Covered — DD/MM/YYYY · Vaccine".
  const coverageEvents = [];
  if (coveredTags.length && rec) {
    const visits = (rec.visits && rec.visits.length)
      ? rec.visits.slice()
      : [{ vaccDate: rec.vaccDate, doses: rec.doses, vaccinatorName: rec.vaccinatorName, centerName: rec.centerName }];
    visits.sort((a, b) => compareDateObjs(a.vaccDate, b.vaccDate));
    const needed = new Set(coveredTags);
    for (const v of visits) {
      if (!needed.size) break;
      const isTt = isTtRecord(v.doses);
      const tags = isTt ? classifyTT(v.doses) : classifyEpi(v.doses);
      const matched = tags.filter(t => needed.has(t));
      if (!matched.length) continue;
      matched.forEach(t => needed.delete(t));
      coverageEvents.push({
        date: v.vaccDate,
        vaccines: matched,
        vaccineLabels: matched.map(t => defVaccineLabel(t)),
        who: (typeof vaccinatorCenterLabel === 'function' ? vaccinatorCenterLabel(v) : '') || ''
      });
    }
  }
  return { found: true, coveredTags, allCovered, coverageDetail, coverageEvents, rec };
}

function defaulterStatusOf(cov){ return cov.allCovered ? 'covered' : 'still'; }
