package org.zm.calculator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.qrcode.QRCodeMultiReader
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Reads EVERY QR code in a photo and, for QR codes that can't be decoded, the
 * number printed beside them (OCR). Runs several passes — the whole picture plus
 * overlapping tiles, two different decoders — so small / many / slightly blurred
 * QR codes are found. Call [read] from a background thread.
 */
class QrReader(private val context: Context) {

    private class Found(val text: String, val box: Rect)

    companion object {
        private const val TAG = "QrReader"
        private const val CODE_LEN = 14
        private const val MAX_SIDE = 3200

        private val P14 = Regex("(?<!\\d)\\d{14}(?!\\d)")
        private val PYS = Regex("(?<!\\d)(\\d{4}|\\d{2})[\\s\\-\\u2013\\u2014_/.]+(\\d{3,12})(?!\\d)")
        private val PLAIN = Regex("^[\\d\\s]+$")

        /** All codes found in a text, each turned into the 14-digit form (see storage.js normalizeQrCode). */
        fun extractAll(text: String): List<String> {
            val out = ArrayList<String>()
            var rest = text
            for (m in P14.findAll(text)) out.add(m.value)
            rest = P14.replace(rest, " ")
            for (m in PYS.findAll(rest)) {
                var y = m.groupValues[1]
                val serial = m.groupValues[2]
                if (y.length == 4) {
                    val yy = y.substring(2).toIntOrNull() ?: continue
                    if (!y.startsWith("20") || yy < 19 || yy > 39) continue
                    y = y.substring(2)
                } else {
                    val yy = y.toIntOrNull() ?: continue
                    if (yy < 19 || yy > 39) continue
                }
                val total = y.length + serial.length
                if (total > CODE_LEN) continue
                out.add(y + "0".repeat(CODE_LEN - total) + serial)
            }
            if (out.isEmpty() && PLAIN.matches(text.trim())) {
                val d = text.replace(Regex("\\s+"), "")
                if (d.length in 10 until CODE_LEN) {
                    val yy = d.substring(0, 2).toIntOrNull() ?: 0
                    if (yy in 19..39) out.add(d.substring(0, 2) + "0".repeat(CODE_LEN - d.length) + d.substring(2))
                }
            }
            return out
        }
    }

    /** Reads all pictures; returns the JSON the web page expects. */
    fun read(uris: List<Uri>): String {
        val codes = LinkedHashMap<String, Boolean>()   // code -> taken from printed number (OCR)
        val raw = ArrayList<String>()
        var qrCount = 0
        for (u in uris) {
            try {
                val bmp = loadBitmap(u) ?: continue
                val one = readOne(bmp, raw)
                for ((c, fromOcr) in one) {
                    if (!codes.containsKey(c)) codes[c] = fromOcr
                }
                bmp.recycle()
            } catch (t: Throwable) {
                Log.w(TAG, "reading a picture failed", t)
            }
        }
        for (v in codes.values) if (!v) qrCount++
        val ocrCount = codes.size - qrCount
        return JSONObject()
            .put("codes", JSONArray(codes.keys.toList()))
            .put("qrCount", qrCount)
            .put("ocrCount", ocrCount)
            .put("raw", JSONArray(raw))
            .toString()
    }

    private fun readOne(bmp: Bitmap, rawOut: MutableList<String>): Map<String, Boolean> {
        val w = bmp.width
        val h = bmp.height
        val regions = buildRegions(w, h)

        // ---- 1) QR codes: two decoders, over the whole picture and over overlapping tiles ----
        val hits = LinkedHashMap<String, Rect>()
        fun addFound(f: Found) {
            val codes = extractAll(f.text)
            if (codes.isEmpty()) {
                if (!rawOut.contains(f.text)) rawOut.add(f.text)
            } else {
                for (c in codes) if (!hits.containsKey(c)) hits[c] = f.box
            }
        }
        val zxingFound = ArrayList<Found>()
        for (r in regions) {
            val crop = crop(bmp, r)
            try {
                zxing(crop, r.left, r.top, zxingFound)
            } finally {
                if (crop !== bmp) crop.recycle()
            }
        }
        zxingFound.forEach { addFound(it) }

        try {
            val scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            )
            for (r in regions.take(5)) {            // the whole picture + 2x2 tiles
                val crop = crop(bmp, r)
                try {
                    val list = Tasks.await(scanner.process(InputImage.fromBitmap(crop, 0)))
                    for (b in list) {
                        val text = b.rawValue ?: continue
                        val bb = b.boundingBox
                        val box = if (bb != null) Rect(bb.left + r.left, bb.top + r.top, bb.right + r.left, bb.bottom + r.top)
                        else Rect(r.left, r.top, r.right, r.bottom)
                        addFound(Found(text, box))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "ML Kit barcode pass failed", e)
                } finally {
                    if (crop !== bmp) crop.recycle()
                }
            }
            scanner.close()
        } catch (e: Throwable) {
            Log.w(TAG, "ML Kit barcode unavailable", e)
        }

        // ---- 2) Printed numbers beside the QR codes (OCR) ----
        val ocr = LinkedHashMap<String, Rect>()
        try {
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            for (r in regions.take(5)) {
                val crop = crop(bmp, r)
                try {
                    val text = Tasks.await(recognizer.process(InputImage.fromBitmap(crop, 0)))
                    for (block in text.textBlocks) {
                        for (line in block.lines) {
                            val bb = line.boundingBox ?: continue
                            val box = Rect(bb.left + r.left, bb.top + r.top, bb.right + r.left, bb.bottom + r.top)
                            for (c in extractAll(line.text)) if (!ocr.containsKey(c)) ocr[c] = box
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "OCR pass failed", e)
                } finally {
                    if (crop !== bmp) crop.recycle()
                }
            }
            recognizer.close()
        } catch (e: Throwable) {
            Log.w(TAG, "OCR unavailable", e)
        }

        // ---- 3) Combine: a decoded QR always wins; a printed number is used only for a
        //         QR that could not be decoded (not for a misread of one that was). ----
        val result = LinkedHashMap<String, Boolean>()
        for (c in hits.keys) result[c] = false
        val decodedWithOwnNumber = HashSet<String>()
        for (c in hits.keys) if (ocr.containsKey(c)) decodedWithOwnNumber.add(c)
        for ((c, box) in ocr) {
            if (hits.containsKey(c)) continue
            var nearestKey: String? = null
            var nearestBox: Rect? = null
            var best = Double.MAX_VALUE
            for ((k, qb) in hits) {
                val d = hypot((box.centerX() - qb.centerX()).toDouble(), (box.centerY() - qb.centerY()).toDouble())
                if (d < best) { best = d; nearestKey = k; nearestBox = qb }
            }
            var skip = false
            if (nearestKey != null && nearestBox != null) {
                val size = max(nearestBox.width(), nearestBox.height()).toDouble()
                // right beside a decoded QR whose own number was not seen = most likely a misread of that QR
                if (best < size * 1.4 && !decodedWithOwnNumber.contains(nearestKey)) skip = true
            }
            if (!skip) result[c] = true
        }
        return result
    }

    private fun buildRegions(w: Int, h: Int): List<Rect> {
        val out = ArrayList<Rect>()
        out.add(Rect(0, 0, w, h))
        fun grid(n: Int, overlap: Float) {
            val tw = w / n
            val th = h / n
            val ow = (tw * overlap).toInt()
            val oh = (th * overlap).toInt()
            for (iy in 0 until n) for (ix in 0 until n) {
                val l = max(0, ix * tw - ow)
                val t = max(0, iy * th - oh)
                val r = min(w, (ix + 1) * tw + ow)
                val b = min(h, (iy + 1) * th + oh)
                if (r - l > 64 && b - t > 64) out.add(Rect(l, t, r, b))
            }
        }
        grid(2, 0.2f)
        grid(3, 0.25f)
        return out
    }

    private fun crop(bmp: Bitmap, r: Rect): Bitmap {
        if (r.left == 0 && r.top == 0 && r.width() == bmp.width && r.height() == bmp.height) return bmp
        return Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
    }

    private fun zxing(crop: Bitmap, ox: Int, oy: Int, out: MutableList<Found>) {
        val w = crop.width
        val h = crop.height
        val px = IntArray(w * h)
        crop.getPixels(px, 0, w, 0, 0, w, h)
        val src = RGBLuminanceSource(w, h, px)
        val hints = mapOf<DecodeHintType, Any>(
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)
        )
        for (mode in 0..1) {
            val bin = if (mode == 0) HybridBinarizer(src) else GlobalHistogramBinarizer(src)
            try {
                val results = QRCodeMultiReader().decodeMultiple(BinaryBitmap(bin), hints)
                for (res in results) {
                    val pts = res.resultPoints
                    var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
                    var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                    if (pts != null) for (p in pts) {
                        minX = min(minX, p.x); maxX = max(maxX, p.x)
                        minY = min(minY, p.y); maxY = max(maxY, p.y)
                    }
                    val box = if (pts != null && pts.isNotEmpty()) {
                        val pad = max(10f, 0.25f * max(maxX - minX, maxY - minY))
                        Rect(
                            (minX - pad).toInt() + ox, (minY - pad).toInt() + oy,
                            (maxX + pad).toInt() + ox, (maxY + pad).toInt() + oy
                        )
                    } else Rect(ox, oy, ox + w, oy + h)
                    out.add(Found(res.text ?: "", box))
                }
            } catch (_: Exception) {
                // nothing found in this tile with this decoder
            }
        }
    }

    // Loads the picture upright (EXIF) and no bigger than MAX_SIDE on its long side.
    private fun loadBitmap(uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longest = max(bounds.outWidth, bounds.outHeight)
        if (longest <= 0) return null
        var sample = 1
        while (longest / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        var degrees = 0
        try {
            resolver.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> degrees = 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> degrees = 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> degrees = 270
                }
            }
        } catch (_: Exception) { }

        val big = max(bmp.width, bmp.height)
        val scale = if (big > MAX_SIDE) MAX_SIDE.toFloat() / big else 1f
        if (degrees != 0 || scale != 1f) {
            val m = Matrix()
            if (degrees != 0) m.postRotate(degrees.toFloat())
            if (scale != 1f) m.postScale(scale, scale)
            val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (t !== bmp) { bmp.recycle(); bmp = t }
        }
        return bmp
    }
}
