// ---- Persistent storage (localStorage — works fully offline in any browser,
// including when this HTML file is saved/reopened directly, not just inside Claude) ----
const LS_KEY = 'epi_tracker_children_v1';

// Dual-write: localStorage (fast) + IndexedDB (larger / more durable on Android).
const DEF_LS_KEY = 'epi_tracker_defaulters_v1';
const QR_LS_KEY = 'epi_tracker_qr_inventory_v1';
const IDB_NAME = 'epi_zindagi_mehfooz_v1';
const IDB_STORE = 'kv';

let _idb = null;
let _idbReady = null;

function idbOpen(){
  if (_idb) return Promise.resolve(_idb);
  if (_idbReady) return _idbReady;
  _idbReady = new Promise(function(resolve){
    try {
      if (!window.indexedDB) { resolve(null); return; }
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function(e){
        const db = e.target.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = function(e){ _idb = e.target.result; resolve(_idb); };
      req.onerror = function(){ resolve(null); };
    } catch (e) { resolve(null); }
  });
  return _idbReady;
}

function idbSet(key, value){
  return idbOpen().then(function(db){
    if (!db) return false;
    return new Promise(function(resolve){
      try {
        const tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(value, key);
        tx.oncomplete = function(){ resolve(true); };
        tx.onerror = function(){ resolve(false); };
      } catch (e) { resolve(false); }
    });
  });
}

function idbGet(key){
  return idbOpen().then(function(db){
    if (!db) return null;
    return new Promise(function(resolve){
      try {
        const tx = db.transaction(IDB_STORE, 'readonly');
        const req = tx.objectStore(IDB_STORE).get(key);
        req.onsuccess = function(){ resolve(req.result == null ? null : req.result); };
        req.onerror = function(){ resolve(null); };
      } catch (e) { resolve(null); }
    });
  });
}

function requestPersistentStorage(){
  try {
    if (navigator.storage && navigator.storage.persist) {
      return navigator.storage.persist().then(function(granted){
        try { window.__epiPersistGranted = !!granted; } catch (e) {}
        return granted;
      }).catch(function(){ return false; });
    }
  } catch (e) {}
  return Promise.resolve(false);
}

async function hydrateStorageFromIdb(){
  await idbOpen();
  async function hydrateKey(lsKey){
    let lsEmpty = true;
    try {
      const raw = localStorage.getItem(lsKey);
      if (raw && raw !== '{}' && raw !== '[]' && raw !== 'null') lsEmpty = false;
    } catch (e) { lsEmpty = true; }
    if (!lsEmpty) return;
    const fromIdb = await idbGet(lsKey);
    if (fromIdb == null) return;
    try {
      const str = typeof fromIdb === 'string' ? fromIdb : JSON.stringify(fromIdb);
      localStorage.setItem(lsKey, str);
    } catch (e) {}
  }
  await hydrateKey(LS_KEY);
  await hydrateKey(DEF_LS_KEY);
  await hydrateKey(QR_LS_KEY);
  await hydrateKey('epi_tracker_village_visits_v1');
  await hydrateKey('epi_tracker_village_dismiss_v1');
  // Force next loadStore/loadDefaultersStore to re-read localStorage
  try { _storeCache = null; _defCache = null; window.__storeVer++; window.__defVer++; } catch (e) {}
}

function mirrorToIdb(lsKey, obj){
  try { idbSet(lsKey, obj).catch(function(){}); } catch (e) {}
}

window.hydrateStorageFromIdb = hydrateStorageFromIdb;
window.requestPersistentStorage = requestPersistentStorage;


// The saved data is read from localStorage as one big JSON text. Parsing it is the single most
// expensive step on a phone, and many screens used to repeat it (one screen even parsed it once
// PER child). Now it is parsed once and re-used until the saved text actually changes.
// window.__storeVer / __defVer change whenever the saved data changes (used by result caches).
let _storeCache = null, _defCache = null;
window.__storeVer = 0; window.__defVer = 0;
function cloneJson(o){
  try { return structuredClone(o); } catch (e) { return JSON.parse(JSON.stringify(o)); }
}
function loadStore(){
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return {};
    if (_storeCache && _storeCache.raw === raw) return _storeCache.obj;
    const obj = JSON.parse(raw);
    _storeCache = { raw, obj }; window.__storeVer++;
    return obj;
  } catch(e) { return {}; }
}
// For code that CHANGES the data before saving it (so a half-finished change can never leak
// into the shared cached copy).
function loadStoreCopy(){ return cloneJson(loadStore()); }
function saveStore(obj){
  let lsOk = false;
  try {
    const str = JSON.stringify(obj);
    localStorage.setItem(LS_KEY, str);
    lsOk = true;
    _storeCache = { raw: str, obj };
  } catch(e) {
    _storeCache = null;
    console.warn('localStorage full, using IndexedDB (up to ~1 GB)', e);
  }
  window.__storeVer++;
  mirrorToIdb(LS_KEY, obj);
  updateStorageNote();
  if (lsOk) return true;
  // localStorage full — data still kept in IndexedDB for large capacity
  try {
    if (statusEl) statusEl.innerHTML = '<span class="ok">✔ Saved in app storage (large capacity).</span>';
  } catch (e2) {}
  return true;
}

// Shows how much of the browser's storage budget the saved data is using.
function updateStorageNote(){
  const el = document.getElementById('storageNote');
  if (!el) return;
  try {
    // Both stores share the same browser quota, so both must be measured —
    // reporting only the children store made the app look far emptier than it
    // was and gave no warning before the quota ran out.
    const raw = localStorage.getItem(LS_KEY) || '';
    const defRaw = localStorage.getItem(DEF_LS_KEY) || '';
    const bytes = new Blob([raw]).size + new Blob([defRaw]).size;
    const kb = bytes/1024;
    const size = kb < 10 ? kb.toFixed(1) + ' KB' : (kb < 1024 ? kb.toFixed(0) + ' KB' : (kb/1024).toFixed(2) + ' MB');
    const n = Object.keys(loadStore()).length;
    const dn = Object.keys(loadDefaultersStore()).length;
    if (!n && !dn) { el.textContent = 'No records saved yet.'; return; }
    const parts = [];
    if (n) parts.push(`${n} record(s)`);
    if (dn) parts.push(`${dn} defaulter(s)`);
    el.textContent = `${parts.join(' + ')} saved • about ${size} used (up to about 1 GB on this device).`;
  } catch(e) { el.textContent = ''; }
}

// A "source" entry identifies one imported file. Older saved data stores it as
// a plain filename string; newer data stores {name, size} so that two
// different files sharing the same name (e.g. two vaccinators' same-named
// "Daily Immunization Registry" PDFs) are told apart.
function sourceEntryName(s){ return typeof s === 'string' ? s : ((s && s.name) || ''); }
function sourceEntrySize(s){ return typeof s === 'string' ? null : ((s && typeof s.size === 'number') ? s.size : null); }
function sourceEntryMatches(s, name, size){
  if (typeof s === 'string') return s === name; // legacy entries: name-only match
  return s && s.name === name && s.size === size;
}
// Removes ONE saved file's data from the daily store (store is a copy that the
// caller saves afterwards). A child's merged record keeps only the visits that
// still come from other saved files; its doses, last date and vaccinator are
// worked out again from those. Records saved before visits remembered their
// file (no `srcs`) behave as before: removed once no source file is left.
function removeSourceFromDailyStore(store, name, size){
  const fileKey = sourceKey(name, size);
  for (const id of Object.keys(store)) {
    const rec = store[id];
    if (!rec || !rec.sources) continue;
    if (!rec.sources.some(s => sourceEntryMatches(s, name, size))) continue;
    rec.sources = rec.sources.filter(s => !sourceEntryMatches(s, name, size));
    if (rec.visits && rec.visits.length) {
      rec.visits = rec.visits.filter(v => {
        if (!Array.isArray(v.srcs)) return true;          // old data: unknown origin, keep
        v.srcs = v.srcs.filter(k => k !== fileKey);
        return v.srcs.length > 0;
      });
    }
    if (rec.sources.length === 0 || (rec.visits && rec.visits.length === 0)) { delete store[id]; continue; }
    recomputeRecordFromVisits(rec);
  }
  return store;
}

// doses / latest date / vaccinator / centre of a record, from its visits only.
function recomputeRecordFromVisits(rec){
  if (!rec.visits || !rec.visits.length) return;
  let doses = {};
  rec.visits.forEach(v => { doses = mergeDoses(doses, v.doses || {}); });
  rec.doses = doses;
  const latest = rec.visits.slice().sort((a, b) => compareDateObjs(a.vaccDate, b.vaccDate)).pop();
  if (latest) {
    if (latest.vaccDate) rec.vaccDate = latest.vaccDate;
    if (latest.vaccinatorName) rec.vaccinatorName = latest.vaccinatorName;
    if (latest.centerName) rec.centerName = latest.centerName;
  }
}

function sourceKey(name, size){ return name + '::' + (size == null ? '' : size); }
function splitSourceKey(key){
  const idx = key.lastIndexOf('::');
  if (idx < 0) return [key, null];
  const sizePart = key.slice(idx + 2);
  return [key.slice(0, idx), sizePart === '' ? null : Number(sizePart)];
}

// ---- Defaulters List storage (separate from the children/women records above) ----
function loadDefaultersStore(){
  try {
    const raw = localStorage.getItem(DEF_LS_KEY);
    if (!raw) return {};
    if (_defCache && _defCache.raw === raw) return _defCache.obj;
    const obj = JSON.parse(raw);
    _defCache = { raw, obj }; window.__defVer++;
    return obj;
  } catch(e) { return {}; }
}
function loadDefaultersStoreCopy(){ return cloneJson(loadDefaultersStore()); }
function saveDefaultersStore(obj){
  try {
    const str = JSON.stringify(obj);
    localStorage.setItem(DEF_LS_KEY, str);
    _defCache = { raw: str, obj };
  } catch(e) { _defCache = null; console.warn('defaulters LS full', e); }
  window.__defVer++;
  mirrorToIdb(DEF_LS_KEY, obj);
  return true;
}

// ---- EPI No lookup ----
// The Daily Immunization Report only prints the 14-digit QR code. The 8-digit
// EPI No is printed in the Children Defaulters Report (Identifier column), so
// it is looked up from the saved defaulters by QR code. A child who is not in
// any saved Defaulters Report simply shows "—".
function buildEpiMap(){
  const map = {};
  const def = loadDefaultersStore();
  for (const id in def) { if (def[id] && def[id].epiNo) map[id] = def[id].epiNo; }
  return map;
}

// ---- QR Code inventory (separate from the children/women & defaulters stores
// above) — a list of the 14-digit QR codes the user has in hand, each stored
// as { code, date, used } (date is optional — whatever was set on the Insert
// QR Code page when that code was added; used starts false). Whenever a
// Daily Immunization Report is processed, any code in this list that matches
// a QR code found in that report is marked used — it stays in the list (in
// the "Used" section, stamped) rather than being deleted, so nothing is lost. ----
const QR_CODE_MAX_LEN = 14;

function loadQrStore(){
  try {
    const raw = localStorage.getItem(QR_LS_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    // Transparently migrate the old plain-string format (no date/used) saved
    // by earlier versions of this page.
    return arr.map(e => (typeof e === 'string') ? { code: e, date: null, used: false } : { used: false, ...e });
  } catch(e) { return []; }
}
function saveQrStore(arr){
  try { localStorage.setItem(QR_LS_KEY, JSON.stringify(arr)); } catch(e) { console.warn('qr LS full', e); }
  mirrorToIdb(QR_LS_KEY, arr);
  return true;
}
// "Unused / Used / Total" and the next unused QR code — shown on the QR options window.
function refreshQrSummary(){
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  const unused = all.filter(e => !e.used);
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('qrSumUnused', unused.length);
  set('qrSumUsed', all.length - unused.length);
  set('qrSumTotal', all.length);
  set('qrNextCode', unused.length ? unused[0].code : '—');
  const btn = document.getElementById('qrNextCopyBtn');
  if (btn) btn.disabled = !unused.length;
}

function updateQrTotalCount(){
  const n = loadQrStore().length;
  try { refreshQrSummary(); } catch (e) {}
  const el = document.getElementById('qrTotalCount');
  if (el) el.textContent = n;
  const el2 = document.getElementById('qrDeleteTotalCount');
  if (el2) el2.textContent = n;
}

// One row for the Saved QR Codes result page / insert list: the code itself,
// Copy & Delete (copies then removes that single code), and Share.
// Used codes additionally get a rotated "USED" stamp.
const qrSelected = new Set();   // codes ticked for "Share Selected"
function qrRowHtml(code, used){
  const stamp = used ? '<span class="qr-stamp">Used</span>' : '';
  const checked = qrSelected.has(code) ? ' checked' : '';
  const c = escapeHtml(code);
  return `<div class="qr-row${used ? ' qr-used-row' : ''}">
    <label class="qr-code-text"><input type="checkbox" class="qr-select-cb" data-qr-sel="${c}"${checked}> ${c}${stamp}</label>
    <span class="qr-row-actions"><button type="button" class="qr-copy-one-btn" data-qr-copy1="${c}" title="Copy this QR code">📋 Copy</button></span>
  </div>`;
}

// Long lists are drawn in pieces of 250 rows ("Show more"), so even thousands of codes
// open, tick and delete quickly. The full list of codes stays in listEl.__codes, so
// Select All / Share / Delete Selected always work on EVERY code, not only the drawn ones.
const QR_PAGE = 250;
function fillQrList(listEl, entries){
  listEl.__entries = entries;
  listEl.__codes = entries.map(e => e.code);
  let shown = 0;
  function more(){
    const next = entries.slice(shown, shown + QR_PAGE);
    shown += next.length;
    const old = listEl.querySelector('.qr-more-btn');
    if (old) old.remove();
    listEl.insertAdjacentHTML('beforeend', next.map(e => qrRowHtml(e.code, !!e.used)).join(''));
    if (shown < entries.length) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'qr-more-btn';
      b.textContent = 'Show more (' + (entries.length - shown) + ' more)';
      b.addEventListener('click', more);
      listEl.appendChild(b);
    }
  }
  listEl.innerHTML = '';
  more();
}
function qrListIsOnScreen(el){
  if (!el) return false;
  for (let n = el; n && n !== document.body; n = n.parentElement) {
    if (n.style && n.style.display === 'none') return false;
  }
  return true;
}

// Toolbar above a QR list: Select All / Clear + "Share Selected (n)".
function ensureQrToolbar(listEl){
  if (!listEl) return;
  let bar = listEl.previousElementSibling;
  if (!bar || !bar.classList || !bar.classList.contains('qr-toolbar')) {
    bar = document.createElement('div');
    bar.className = 'qr-toolbar';
    bar.innerHTML = '<button type="button" class="qr-sel-all-btn">☑ Select All</button>' +
      '<button type="button" class="qr-sel-clear-btn">✖ Clear</button>' +
      '<button type="button" class="qr-share-sel-btn">📤 Share Selected (<span class="qr-sel-n">0</span>)</button>' +
      '<button type="button" class="qr-copy-sel-btn">📋 Copy Selected (<span class="qr-sel-n">0</span>)</button>' +
      '<button type="button" class="qr-del-sel-btn">🗑 Delete Selected (<span class="qr-sel-n">0</span>)</button>';
    listEl.parentNode.insertBefore(bar, listEl);
  }
  updateQrSelectionUi();
}
function updateQrSelectionUi(){
  document.querySelectorAll('.qr-sel-n').forEach(el => { el.textContent = qrSelected.size; });
  document.querySelectorAll('.qr-share-sel-btn').forEach(b => { b.disabled = qrSelected.size === 0; });
  document.querySelectorAll('.qr-del-sel-btn').forEach(b => { b.disabled = qrSelected.size === 0; });
  document.querySelectorAll('.qr-copy-sel-btn').forEach(b => { b.disabled = qrSelected.size === 0; });
}
function visibleQrCodes(btn){
  const bar = btn.closest('.qr-toolbar');
  const list = bar && bar.nextElementSibling;
  if (!list) return [];
  if (Array.isArray(list.__codes)) return list.__codes;       // every code of the list, drawn or not
  return Array.from(list.querySelectorAll('.qr-select-cb')).map(cb => cb.getAttribute('data-qr-sel'));
}
// Share several codes at once, one per line, through one Share sheet.
function shareQrCodes(codes){
  const list = (codes || []).filter(Boolean);
  if (!list.length) return;
  const text = list.join('\n');
  try {
    if (window.AndroidEpi && typeof window.AndroidEpi.shareText === 'function') {
      window.AndroidEpi.shareText(text, 'QR Codes (' + list.length + ')');
      return;
    }
  } catch (e) {}
  if (navigator.share) {
    navigator.share({ title: 'QR Codes', text: text }).catch(function(){});
  } else if (legacyCopyToClipboard(text)) {
    try { if (typeof showToast === 'function') showToast(list.length + ' codes copied — paste to share'); } catch(e){}
  } else {
    try { window.prompt('Copy these QR Codes:', text); } catch(e){}
  }
}

// Shows the "next page" result after codes are added: unused codes in their
// own box and used codes (stamped) in a separate box, each code with its own
// Copy & Delete + Share buttons.
let qrTab = 'unused';
function setQrTab(name, scroll){
  qrTab = name === 'used' ? 'used' : 'unused';
  const pu = document.getElementById('qrPageUnused'), pd = document.getElementById('qrPageUsed');
  if (pu) pu.style.display = qrTab === 'unused' ? 'block' : 'none';
  if (pd) pd.style.display = qrTab === 'used' ? 'block' : 'none';
  document.querySelectorAll('#qrTabs .qr-tab').forEach(b => b.classList.toggle('active', b.dataset.tab === qrTab));
  if (scroll) window.scrollTo(0, 0);
}

// QR Code Results: two pages — QR codes not used yet, and QR codes already Used
// (a code becomes Used when a processed Daily Immunization Report contains it).
function renderQrList(){
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  const unused = all.filter(e => !e.used);
  const used = all.filter(e => e.used);
  const setText = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  setText('qrListTotal', all.length);
  setText('qrUnusedCount', unused.length);
  setText('qrUsedCount', used.length);
  setText('qrTabUnusedN', unused.length);
  setText('qrTabUsedN', used.length);

  const draw = (id, entries, emptyText) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (entries.length) fillQrList(el, entries);
    else { el.__codes = []; el.innerHTML = '<div class="note" style="margin:0;">' + emptyText + '</div>'; }
    ensureQrToolbar(el);
  };
  draw('qrUnusedList', unused, 'No unused QR codes.');
  draw('qrUsedList', used, 'No QR code has been used yet.');
  setQrTab(qrTab);
}

// List shown in the Delete QR Code window (tick boxes + Select All / Clear / Share / Delete Selected).
function renderQrDeleteList(){
  const listEl = document.getElementById('qrDeleteList');
  if (!listEl) return;
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  // forget ticks of codes that no longer exist
  const present = new Set(all.map(e => e.code));
  Array.from(qrSelected).forEach(c => { if (!present.has(c)) qrSelected.delete(c); });
  if (!all.length) {
    listEl.__codes = [];
    listEl.innerHTML = '<div class="note" style="margin:0;">No QR codes saved.</div>';
    const bar = listEl.previousElementSibling;
    if (bar && bar.classList && bar.classList.contains('qr-toolbar')) bar.remove();
    updateQrSelectionUi();
    return;
  }
  fillQrList(listEl, all);
  ensureQrToolbar(listEl);
}

// Brings every QR list / counter up to date after codes were added or deleted.
function refreshQrViews(){
  try { updateQrTotalCount(); } catch (e) {}
  // only the list that is on screen is drawn again; the others are drawn when opened
  try { if (qrListIsOnScreen(document.getElementById('qrDeleteList'))) renderQrDeleteList(); } catch (e) {}
  try { if (qrListIsOnScreen(document.getElementById('qrInsertList'))) renderQrInsertList(); } catch (e) {}
  try { if (qrListIsOnScreen(document.getElementById('qrResultView'))) renderQrList(); } catch (e) {}
  try {
    const m = document.getElementById('qrMenuTotalCount');
    if (m) m.textContent = loadQrStore().length;
  } catch (e) {}
}

// Turns what a QR code (or the number printed beside it) says into the 14-digit code.
//   26000020969217      -> kept as is (any 14 digits; nothing else is restricted)
//   26-20969217         -> year code + zeros + number, so it becomes 14 digits: 26000020969217
//   2026-20969217       -> 4-digit year is shortened to its last two digits first
// Only the start must be a year code (19 ... 39); the rest is free for future codes.
function normalizeQrCode(raw){
  const t = String(raw == null ? '' : raw).trim();
  if (!t) return null;
  let m = t.match(/(?<!\d)\d{14}(?!\d)/);
  if (m) return m[0];
  m = t.match(/(?<!\d)(\d{4}|\d{2})[\s\-\u2013\u2014_\/.]+(\d{3,12})(?!\d)/);
  if (m) {
    let y = m[1];
    const serial = m[2];
    if (y.length === 4) {
      const yy = parseInt(y.slice(2), 10);
      if (y.slice(0, 2) !== '20' || yy < 19 || yy > 39) return null;
      y = y.slice(2);
    } else {
      const yy = parseInt(y, 10);
      if (yy < 19 || yy > 39) return null;
    }
    const total = y.length + serial.length;
    if (total > QR_CODE_MAX_LEN) return null;
    return y + '0'.repeat(QR_CODE_MAX_LEN - total) + serial;
  }
  if (/^[\d\s]+$/.test(t)) {
    const d = t.replace(/\s+/g, '');
    if (d.length >= 10 && d.length < QR_CODE_MAX_LEN) {
      const yy = parseInt(d.slice(0, 2), 10);
      if (yy >= 19 && yy <= 39) return d.slice(0, 2) + '0'.repeat(QR_CODE_MAX_LEN - d.length) + d.slice(2);
    }
  }
  return null;
}

// Copies text to the clipboard (the code only — nothing is deleted) and tells the person.
function qrCopyText(text, doneMsg){
  const done = () => {
    try { if (typeof showToast === 'function') { showToast(doneMsg); return; } } catch (e) {}
    try { const st = document.getElementById('qrDeleteStatus'); if (st) st.innerHTML = '<span class="ok">' + escapeHtml(doneMsg) + '</span>'; } catch (e) {}
  };
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, () => { if (legacyCopyToClipboard(text)) done(); else window.prompt('Copy:', text); });
      return;
    }
  } catch (e) {}
  if (legacyCopyToClipboard(text)) done(); else { try { window.prompt('Copy:', text); } catch (e) {} }
}

// Compact list for the Insert QR Code page (same actions).
function renderQrInsertList(){
  const listEl = document.getElementById('qrInsertList');
  if (!listEl) return;
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  if (!all.length) {
    listEl.innerHTML = '<div class="note" style="margin:0;">No QR codes saved yet.</div>';
    return;
  }
  fillQrList(listEl, all);
  ensureQrToolbar(listEl);
}

// Copy-to-clipboard for the small button next to every QR code, on either
// the Saved QR Codes result page or anywhere else a ".qr-copy-btn" appears.
// Three fallbacks are tried in order because the modern Clipboard API is
// often blocked entirely on pages opened via a "content://" link (no secure
// origin) or inside restricted in-app browsers — when both programmatic
// methods fail, a prompt() box is used as a last resort so the code is at
// least selectable/copyable by hand rather than the button just failing.
function legacyCopyToClipboard(text){
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '0';
    ta.style.left = '0';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    return false;
  }
}

function copyQrCode(code, btn){
  const showResult = (ok) => {
    if (!btn) return;
    const original = btn.textContent;
    btn.textContent = ok ? '✔ Copied' : '✖ Failed';
    setTimeout(() => { if (document.body.contains(btn)) btn.textContent = original; }, 1400);
  };
  const useLegacyThenPrompt = () => {
    if (legacyCopyToClipboard(code)) { showResult(true); return; }
    // Guaranteed-to-work fallback: the code sits in a prompt box the user
    // can select and copy manually even when every automated method is
    // blocked by the browser.
    try { window.prompt('Copy this QR Code (already selected):', code); } catch (e) { /* ignore */ }
    showResult(false);
  };
  if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code).then(() => showResult(true)).catch(useLegacyThenPrompt);
  } else {
    useLegacyThenPrompt();
  }
}

function deleteOneQrCode(code){
  const existing = loadQrStore();
  const remaining = existing.filter(e => e.code !== code);
  if (remaining.length === existing.length) return false;
  saveQrStore(remaining);
  updateQrTotalCount();
  if (typeof renderQrList === 'function') renderQrList();
  if (typeof renderQrInsertList === 'function') renderQrInsertList();
  return true;
}

function copyAndDeleteQrCode(code, btn){
  // Copy first, then delete only this code from the store.
  const afterCopy = () => {
    deleteOneQrCode(code);
    if (btn && document.body.contains(btn)) {
      // Row will be removed by re-render; brief feedback is optional.
    }
  };
  const showResult = (ok) => {
    if (btn && document.body.contains(btn)) {
      const original = btn.textContent;
      btn.textContent = ok ? '✔ Copied' : '✖ Failed';
      setTimeout(() => {
        if (document.body.contains(btn)) btn.textContent = original;
        afterCopy();
      }, 600);
    } else {
      afterCopy();
    }
  };
  const useLegacyThenPrompt = () => {
    if (legacyCopyToClipboard(code)) { showResult(true); return; }
    try { window.prompt('Copy this QR Code (already selected):', code); } catch (e) { /* ignore */ }
    showResult(false);
  };
  if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code).then(() => showResult(true)).catch(useLegacyThenPrompt);
  } else {
    useLegacyThenPrompt();
  }
}

function shareQrCode(code){
  const text = String(code || '');
  if (!text) return;
  try {
    if (window.AndroidEpi && typeof window.AndroidEpi.shareText === 'function') {
      window.AndroidEpi.shareText(text, 'QR Code');
      return;
    }
  } catch (e) {}
  if (navigator.share) {
    navigator.share({ title: 'QR Code', text: text }).catch(function(){
      // User cancelled or share failed — fall back to copy.
      if (legacyCopyToClipboard(text)) {
        try { if (typeof showToast === 'function') showToast('Copied to clipboard'); } catch(e){}
      } else {
        try { window.prompt('Share / copy this QR Code:', text); } catch(e){}
      }
    });
  } else if (legacyCopyToClipboard(text)) {
    try { if (typeof showToast === 'function') showToast('Copied — paste to share'); } catch(e){}
  } else {
    try { window.prompt('Share / copy this QR Code:', text); } catch(e){}
  }
}

document.addEventListener('change', (ev) => {
  const cb = ev.target.closest && ev.target.closest('.qr-select-cb');
  if (!cb) return;
  const code = cb.getAttribute('data-qr-sel');
  if (cb.checked) qrSelected.add(code); else qrSelected.delete(code);
  updateQrSelectionUi();
});

document.addEventListener('click', (ev) => {
  const selAll = ev.target.closest('.qr-sel-all-btn');
  if (selAll) {
    visibleQrCodes(selAll).forEach(c => qrSelected.add(c));
    document.querySelectorAll('.qr-select-cb').forEach(cb => { cb.checked = qrSelected.has(cb.getAttribute('data-qr-sel')); });
    updateQrSelectionUi();
    return;
  }
  const selClear = ev.target.closest('.qr-sel-clear-btn');
  if (selClear) {
    qrSelected.clear();
    document.querySelectorAll('.qr-select-cb').forEach(cb => { cb.checked = false; });
    updateQrSelectionUi();
    return;
  }
  const copyOne = ev.target.closest('.qr-copy-one-btn');
  if (copyOne) { qrCopyText(copyOne.getAttribute('data-qr-copy1'), 'QR code copied'); return; }
  const copySel = ev.target.closest('.qr-copy-sel-btn');
  if (copySel) {
    const ordered = loadQrStore().map(e => e.code).filter(c => qrSelected.has(c)).sort();
    if (ordered.length) qrCopyText(ordered.join('\n'), ordered.length + ' QR code(s) copied');
    return;
  }
  const delSel = ev.target.closest('.qr-del-sel-btn');
  if (delSel) {
    const chosen = Array.from(qrSelected);
    if (!chosen.length) return;
    // the confirmation pop-up opens at once, above this window
    Promise.resolve(confirmDialog('Delete ' + chosen.length + ' selected QR code(s)?', 'Delete')).then(ok => {
      if (!ok) return;
      const gone = new Set(chosen);
      const remaining = loadQrStore().filter(e => !gone.has(e.code));
      saveQrStore(remaining);
      qrSelected.clear();
      refreshQrViews();
      const st = document.getElementById('qrDeleteStatus');
      if (st) st.innerHTML = '<span class="ok">' + chosen.length + ' QR code(s) deleted.</span>';
    });
    return;
  }
  const shareSel = ev.target.closest('.qr-share-sel-btn');
  if (shareSel) {
    // keep list order (sorted) rather than click order
    const ordered = loadQrStore().map(e => e.code).filter(c => qrSelected.has(c)).sort();
    shareQrCodes(ordered);
    return;
  }
  const copyBtn = ev.target.closest('.qr-copy-btn');
  if (copyBtn) {
    copyQrCode(copyBtn.getAttribute('data-qr-copy') || '', copyBtn);
    return;
  }
  const copyDelBtn = ev.target.closest('.qr-copy-delete-btn');
  if (copyDelBtn) {
    copyAndDeleteQrCode(copyDelBtn.getAttribute('data-qr-copy') || '', copyDelBtn);
    return;
  }
  const shareBtn = ev.target.closest('.qr-share-btn');
  if (shareBtn) {
    shareQrCode(shareBtn.getAttribute('data-qr-share') || '');
    return;
  }
});

// Download QR Codes as a printable PDF (EPI Pakistan style): each code is
// drawn as a scannable QR module grid with its number printed underneath.
// Scanning any QR returns the same number that is printed below it.
document.getElementById('qrExportTxtBtn').addEventListener('click', () => {
  const all = loadQrStore().slice().sort((a, b) => a.code.localeCompare(b.code));
  const codes = all.filter(e => !e.used).map(e => e.code);
  if (!codes.length) {
    if (typeof alertDialog === 'function') alertDialog('No QR codes to download.');
    else if (typeof backupMsg === 'function') backupMsg('No QR codes to download.', true);
    return;
  }
  if (typeof exportQrCodesPdf === 'function') {
    exportQrCodesPdf(codes);
  } else {
    // Fallback plain text if PDF helper is missing
    NativeBridge.primeNotifications();
    downloadText(`qr-codes-${new Date().toISOString().slice(0, 10)}.txt`, 'text/plain', codes.join('\n'));
    backupMsg('File Saved in Download File.');
  }
});

// derive the list of processed files + per-file record counts from the store itself,
// keyed by name+size so same-named files with different content are kept distinct.
function deriveFileList(store){
  const counts = {};
  for (const id in store) {
    const rec = store[id];
    (rec.sources || []).forEach(s => {
      const name = sourceEntryName(s);
      const size = sourceEntrySize(s);
      const key = sourceKey(name, size);
      if (!counts[key]) counts[key] = { name, size, count: 0 };
      counts[key].count++;
    });
  }
  return counts;
}

// Same idea for the Defaulters List store. Without this, a processed
// Defaulters PDF never appeared in "Saved Files" and there was NO way at all
// to remove one — only "Clear All" could touch it.
function deriveDefaulterFileList(defStore){
  const counts = {};
  for (const id in defStore) {
    const rec = defStore[id];
    (rec.sources || []).forEach(s => {
      const name = sourceEntryName(s);
      const size = sourceEntrySize(s);
      const key = sourceKey(name, size);
      if (!counts[key]) counts[key] = { name, size, count: 0 };
      counts[key].count++;
    });
  }
  return counts;
}

function fileRowsHtml(counts, icon, kind, metaFn){
  const keys = Object.keys(counts).sort((a, b) => {
    const A = counts[a], B = counts[b];
    return A.name.localeCompare(B.name) || (A.size||0) - (B.size||0);
  });
  return keys.map(key => {
    const info = counts[key];
    const sizeLabel = info.size != null ? ` • ${(info.size/1024).toFixed(1)} KB` : '';
    return `
      <div class="frow">
        <span class="fname">${icon} ${escapeHtml(info.name)} <span style="color:var(--muted);">(${info.count} records${sizeLabel})</span>${metaFn ? metaFn(key) : ''}</span>
        <button class="rmbtn" data-key="${escapeHtml(key)}" data-kind="${kind}" title="Delete" aria-label="Delete file ${escapeHtml(info.name)} and its data">🗑</button>
      </div>`;
  }).join('');
}
