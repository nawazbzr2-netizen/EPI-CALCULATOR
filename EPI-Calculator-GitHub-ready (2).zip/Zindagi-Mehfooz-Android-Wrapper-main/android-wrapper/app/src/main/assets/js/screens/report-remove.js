// ============================================================
// report-remove.js — "Remove" and "Delete" under the Month & Vaccinator/Center pickers
// of the Daily Immunization Report results.
//
//   They work on the files shown by the picked month(s) / vaccinator(s):
//   Remove : the processed data of that selection is taken out of the app, and so
//            are its results. The files themselves stay on the phone.
//   Delete : the same, and the original PDF files that no longer have any data left
//            in the app are also deleted from the phone.
//
//   With nothing picked (All months and All vaccinators) both buttons are off.
// ============================================================

function reportSelectionIsActive(){
  // a month and/or a vaccinator is really picked (not "All" for both)
  return !reportFilterIsAll();
}

function updateReportRemoveButtons(){
  const on = reportSelectionIsActive();
  ['btnReportRemove', 'btnReportDelete'].forEach(id => {
    const b = document.getElementById(id);
    if (b) b.disabled = !on;
  });
}

// what a Remove / Delete of the current selection would take away
function reportRemovalPlan(){
  const store = loadStore();
  let visits = 0;
  const children = new Set();
  Object.values(store).forEach(rec => {
    reportFilterAllVisits(rec).forEach(v => { if (reportFilterMatchesVisit(v)) { visits++; children.add(rec.id); } });
  });
  const after = loadStoreCopy();
  removeFilteredVisitsFromStore(after);
  const before = deriveFileList(store);
  const left = deriveFileList(after);
  const gone = Object.keys(before).filter(k => !left[k]).map(k => ({ name: before[k].name, size: before[k].size }));
  return { visits, children: children.size, goneFiles: gone, after };
}

async function runReportRemoval(alsoFromPhone){
  if (!reportSelectionIsActive()) return;
  // resolve a default month if none was set yet, so the summary below is exact
  try { applyReportFilter(Object.values(loadStore())); } catch (e) {}
  const plan = reportRemovalPlan();
  if (!plan.visits) {
    await alertDialog('Nothing is saved for the picked month(s) / vaccinator(s).');
    return;
  }
  const what = reportFilterMonthsSummary() + ' · ' + reportFilterVcSummary();
  const filesLine = plan.goneFiles.length
    ? '\n' + plan.goneFiles.length + ' processed file(s) are removed from the app' + (alsoFromPhone ? ' AND deleted from the phone.' : '.')
    : '\nNo file is left without data, so no file is removed from the list.';
  const ok = await confirmDialog(
    (alsoFromPhone ? 'DELETE' : 'Remove') + ' the data of:\n' + what + '\n\n' +
    plan.children + ' child record(s), ' + plan.visits + ' visit(s).' + filesLine +
    (alsoFromPhone ? '\n\nThis cannot be undone.' : ''),
    alsoFromPhone ? 'Delete' : 'Remove');
  if (!ok) return;

  window.__epiBusy(true, alsoFromPhone ? 'ڈیلیٹ کیا جا رہا ہے…' : 'ہٹایا جا رہا ہے…');
  // let the spinner paint before the work starts
  await new Promise(r => setTimeout(r, 60));
  let phoneMsg = '';
  try {
    saveStore(plan.after);
    refreshAfterDataChange();
    if (alsoFromPhone && plan.goneFiles.length) {
      let res = null;
      try {
        if (window.AndroidEpi && typeof window.AndroidEpi.deleteFilesFromPhone === 'function') {
          res = JSON.parse(window.AndroidEpi.deleteFilesFromPhone(JSON.stringify(plan.goneFiles)) || 'null');
        }
      } catch (e) { console.warn(e); }
      if (res) {
        phoneMsg = '\n' + res.deleted + ' file(s) deleted from the phone.';
        if (res.failed && res.failed.length) {
          phoneMsg += '\n' + res.failed.length + ' could not be deleted from the phone (delete them with your file manager, or allow “All files access” for this app):\n' +
            res.failed.slice(0, 6).join('\n') + (res.failed.length > 6 ? '\n…' : '');
        }
      } else {
        phoneMsg = '\nThe files could not be deleted from the phone on this device.';
      }
    }
  } finally {
    window.__epiBusy(false);
  }
  await alertDialog('Done.\n' + plan.children + ' child record(s) removed from the results.' +
    (plan.goneFiles.length ? '\n' + plan.goneFiles.length + ' file(s) removed from the app.' : '') + phoneMsg);
}

(function(){
  const rm = document.getElementById('btnReportRemove');
  const del = document.getElementById('btnReportDelete');
  if (rm) rm.addEventListener('click', () => { if (!rm.disabled) runReportRemoval(false); });
  if (del) del.addEventListener('click', () => { if (!del.disabled) runReportRemoval(true); });
  updateReportRemoveButtons();
})();
