package org.zm.calculator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.qrcode.QRCodeMultiReader
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Reads EVERY QR code in a photo and, for QR codes that can't be decoded, the
 * number printed beside them (OCR). Runs several passes — the whole picture plus
 * overlapping tiles, two different decoders — so small / many / slightly blurred
 * QR codes are found. Call [read] from a background thread.
 */
class QrReader(
    private val context: Context,
    private val onProgress: (Int, String) -> Unit = { _, _ -> }
) {

    private class Found(val text: String, val box: Rect)

    companion object {
        private const val TAG = "QrReader"
        private const val CODE_LEN = 14
        private const val MAX_SIDE = 2800

        private val P14 = Regex("(?<!\\d)\\d{14}(?!\\d)")
        private val PYS = Regex("(?<!\\d)(\\d{4}|\\d{2})[\\s\\-\\u2013\\u2014_/.]+(\\d{3,12})(?!\\d)")
        private val PLAIN = Regex("^[\\d\\s]+$")

        /** All codes found in a text, each turned into the 14-digit form (see storage.js normalizeQrCode). */
        fun extractAll(text: String): List<String> {
            val out = ArrayList<String>()
            var rest = text
            for (m in P14.findAll(text)) out.add(m.value)
            rest = P14.replace(rest, " ")
            for (m in PYS.findAll(rest)) {
                var y = m.groupValues[1]
                val serial = m.groupValues[2]
                if (y.length == 4) {
                    val yy = y.substring(2).toIntOrNull() ?: continue
                    if (!y.startsWith("20") || yy < 19 || yy > 39) continue
                    y = y.substring(2)
                } else {
                    val yy = y.toIntOrNull() ?: continue
                    if (yy < 19 || yy > 39) continue
                }
                val total = y.length + serial.length
                if (total > CODE_LEN) continue
                out.add(y + "0".repeat(CODE_LEN - total) + serial)
            }
            if (out.isEmpty() && PLAIN.matches(text.trim())) {
                val d = text.replace(Regex("\\s+"), "")
                if (d.length in 10 until CODE_LEN) {
                    val yy = d.substring(0, 2).toIntOrNull() ?: 0
                    if (yy in 19..39) out.add(d.substring(0, 2) + "0".repeat(CODE_LEN - d.length) + d.substring(2))
                }
            }
            return out
        }
    }

    /** Reads all pictures; returns the JSON the web page expects. */
    fun read(uris: List<Uri>): String {
        val codes = LinkedHashMap<String, Int>()   // code -> 0 = from the QR, 1 = printed number, 2 = completed from the number series
        val raw = ArrayList<String>()
        var index = 0
        for (u in uris) {
            index++
            try {
                val bmp = loadBitmap(u) ?: continue
                val one = readOne(bmp, raw, index, uris.size)
                for ((c, origin) in one) {
                    val old = codes[c]
                    if (old == null || origin < old) codes[c] = origin
                }
                bmp.recycle()
            } catch (t: Throwable) {
                Log.w(TAG, "reading a picture failed", t)
            }
        }
        var qr = 0
        var printed = 0
        var filled = 0
        for (v in codes.values) when (v) { 0 -> qr++; 1 -> printed++; else -> filled++ }
        return JSONObject()
            .put("codes", JSONArray(codes.keys.toList()))
            .put("qrCount", qr)
            .put("ocrCount", printed)
            .put("filledCount", filled)
            .put("raw", JSONArray(raw))
            .toString()
    }

    private fun progress(imageNo: Int, imageCount: Int, step: Int, steps: Int, text: String) {
        val base = (imageNo - 1) * 100 / imageCount
        val pct = base + (step * 100 / steps) / imageCount
        try { onProgress(pct.coerceIn(0, 99), text) } catch (_: Exception) { }
    }

    private fun readOne(bmp: Bitmap, rawOut: MutableList<String>, imageNo: Int, imageCount: Int): Map<String, Int> {
        val w = bmp.width
        val h = bmp.height
        val regions = buildRegions(w, h)
        val hits = LinkedHashMap<String, Rect>()          // QR codes that were decoded (14-digit form)
        val votes = HashMap<String, Int>()                 // printed numbers: in how many passes each was read
        val steps = 4

        fun pass(label: String, step: Int, work: (MutableMap<String, Rect>) -> Unit) {
            progress(imageNo, imageCount, step, steps, label)
            val seen = LinkedHashMap<String, Rect>()
            try { work(seen) } catch (t: Throwable) { Log.w(TAG, "$label failed", t) }
            for (c in seen.keys) votes[c] = (votes[c] ?: 0) + 1
        }

        // pass 1: the picture as it is
        pass("تصویر پڑھی جا رہی ہے", 0) { ocr -> scanBitmap(bmp, regions, hits, rawOut, ocr, true) }

        // pass 2: cleaned up like a document scanner (shadows removed, contrast stretched, sharpened)
        pass("تصویر صاف کی جا رہی ہے", 1) { ocr ->
            val clean = ImageCleaner.scanLook(bmp)
            try { scanBitmap(clean, regions.take(5), hits, rawOut, ocr, true) } finally { clean.recycle() }
        }

        // pass 3: black & white document look (QR codes only)
        pass("کوڈ تلاش کیے جا رہے ہیں", 2) { ocr ->
            val clean = ImageCleaner.blackAndWhite(bmp)
            try { scanBitmap(clean, regions.take(5), hits, rawOut, ocr, false) } finally { clean.recycle() }
        }

        // pass 4: small QR codes and small digits are read again after enlarging each part of the picture
        pass("چھوٹے کوڈ بڑے کر کے پڑھے جا رہے ہیں", 3) { ocr ->
            val tiles = ArrayList<Rect>()
            val n = 3
            val tw = w / n
            val th = h / n
            for (iy in 0 until n) for (ix in 0 until n) {
                tiles.add(Rect(max(0, ix * tw - tw / 4), max(0, iy * th - th / 4), min(w, (ix + 1) * tw + tw / 4), min(h, (iy + 1) * th + th / 4)))
            }
            for (t in tiles) {
                val crop = crop(bmp, t)
                val scale = min(2.0f, 2600f / max(crop.width, crop.height))
                val up = if (scale > 1.05f) Bitmap.createScaledBitmap(crop, (crop.width * scale).toInt(), (crop.height * scale).toInt(), true) else crop
                try {
                    scanBitmap(up, listOf(Rect(0, 0, up.width, up.height)), hits, rawOut, ocr, true, scale, t.left, t.top)
                } finally {
                    if (up !== crop) up.recycle()
                    if (crop !== bmp) crop.recycle()
                }
            }
        }
        try { onProgress(99, "نتیجہ بنایا جا رہا ہے") } catch (_: Exception) { }
        return finalizeCodes(hits.keys, votes)
    }

    // ---------------------------------------------------------------------------------
    // Decides the final list. A QR that was decoded is always right. The printed numbers
    // are only trusted when two different passes read the same number, and only when they
    // belong to the same series as the other codes (same start, close to each other) —
    // a number read wrongly (one or two digits off) is dropped. Stickers on one sheet are
    // numbered one after another, so a few stickers whose QR and number both could not
    // be read are completed from the series; they are counted separately and shown.
    // ---------------------------------------------------------------------------------
    private fun finalizeCodes(decoded: Collection<String>, votes: Map<String, Int>): Map<String, Int> {
        val result = LinkedHashMap<String, Int>()
        for (c in decoded) result[c] = 0

        val trustedOcr = votes.filter { it.value >= 2 }.keys
        var pool: List<String> = (decoded + trustedOcr).distinct()
        val poolIsWeak = pool.isEmpty()
        if (poolIsWeak) pool = votes.keys.toList()           // nothing certain: use what was read
        if (pool.isEmpty()) return result

        // the series every code of the sheet shares: the most common first 9 digits
        val prefixCount = HashMap<String, Int>()
        for (c in pool) {
            val p = c.take(9)
            prefixCount[p] = (prefixCount[p] ?: 0) + (if (decoded.contains(c)) 3 else 1)
        }
        val prefix = prefixCount.maxByOrNull { it.value }?.key ?: return result
        val inSeries = pool.filter { it.startsWith(prefix) }.sortedBy { it.toLongOrNull() ?: 0L }

        // groups of numbers close to each other (gap of at most 6 between neighbours)
        val clusters = ArrayList<MutableList<Long>>()
        for (c in inSeries) {
            val n = c.toLongOrNull() ?: continue
            val last = clusters.lastOrNull()
            if (last != null && n - last.last() <= 6) last.add(n) else clusters.add(mutableListOf(n))
        }
        // when the picture holds a sheet of stickers, a lone number far from the sheet is a misread
        val hasSheet = clusters.any { it.size >= 4 }
        for (cl in clusters) {
            if (cl.size >= 4) {
                // a sheet: all numbers from the first to the last one
                val lo = cl.first()
                val hi = cl.last()
                var n = lo
                while (n <= hi) {
                    val code = n.toString().padStart(CODE_LEN, '0')
                    if (!result.containsKey(code)) result[code] = if ((votes[code] ?: 0) >= 1) 1 else 2
                    n++
                }
                // a number right at the edge of the sheet, read once
                for (e in votes.keys) {
                    val en = e.toLongOrNull() ?: continue
                    if (e.startsWith(prefix) && !result.containsKey(e) && (en in (lo - 3) until lo || en in (hi + 1)..(hi + 3))) result[e] = 1
                }
            } else if (!hasSheet) {
                for (n in cl) {
                    val code = n.toString().padStart(CODE_LEN, '0')
                    if (!result.containsKey(code)) result[code] = 1
                }
            }
        }
        return result
    }

    // One reading pass over a picture: two QR decoders + text recognition, whole picture and tiles.
    private fun scanBitmap(
        bmp: Bitmap,
        regions: List<Rect>,
        hits: MutableMap<String, Rect>,
        rawOut: MutableList<String>,
        ocr: MutableMap<String, Rect>,
        withOcr: Boolean,
        scale: Float = 1f,
        offX: Int = 0,
        offY: Int = 0
    ) {
        // positions are given in the ORIGINAL picture (matters when this is an enlarged part of it)
        fun mapBox(b: Rect) = Rect(
            (b.left / scale).toInt() + offX, (b.top / scale).toInt() + offY,
            (b.right / scale).toInt() + offX, (b.bottom / scale).toInt() + offY
        )
        fun addFound(f: Found) {
            val codes = extractAll(f.text)
            if (codes.isEmpty()) {
                if (!rawOut.contains(f.text)) rawOut.add(f.text)
            } else {
                for (c in codes) if (!hits.containsKey(c)) hits[c] = mapBox(f.box)
            }
        }

        // QR codes — decoder 1 (ZXing, finds many QR codes in one picture)
        val zxingFound = ArrayList<Found>()
        for (r in regions) {
            val crop = crop(bmp, r)
            try {
                zxing(crop, r.left, r.top, zxingFound)
            } finally {
                if (crop !== bmp) crop.recycle()
            }
        }
        zxingFound.forEach { addFound(it) }

        // QR codes — decoder 2 (ML Kit)
        try {
            val scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            )
            for (r in regions.take(5)) {            // the whole picture + 2x2 tiles
                val crop = crop(bmp, r)
                try {
                    val list = Tasks.await(scanner.process(InputImage.fromBitmap(crop, 0)))
                    for (b in list) {
                        val text = b.rawValue ?: continue
                        val bb = b.boundingBox
                        val box = if (bb != null) Rect(bb.left + r.left, bb.top + r.top, bb.right + r.left, bb.bottom + r.top)
                        else Rect(r.left, r.top, r.right, r.bottom)
                        addFound(Found(text, box))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "ML Kit barcode pass failed", e)
                } finally {
                    if (crop !== bmp) crop.recycle()
                }
            }
            scanner.close()
        } catch (e: Throwable) {
            Log.w(TAG, "ML Kit barcode unavailable", e)
        }

        // Printed numbers beside the QR codes (text recognition)
        if (!withOcr) return
        try {
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            for (r in regions.take(5)) {
                val crop = crop(bmp, r)
                try {
                    val text = Tasks.await(recognizer.process(InputImage.fromBitmap(crop, 0)))
                    for (block in text.textBlocks) {
                        for (line in block.lines) {
                            val bb = line.boundingBox ?: continue
                            val box = Rect(bb.left + r.left, bb.top + r.top, bb.right + r.left, bb.bottom + r.top)
                            for (c in extractAll(line.text)) if (!ocr.containsKey(c)) ocr[c] = mapBox(box)
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "OCR pass failed", e)
                } finally {
                    if (crop !== bmp) crop.recycle()
                }
            }
            recognizer.close()
        } catch (e: Throwable) {
            Log.w(TAG, "OCR unavailable", e)
        }
    }

    private fun buildRegions(w: Int, h: Int): List<Rect> {
        val out = ArrayList<Rect>()
        out.add(Rect(0, 0, w, h))
        fun grid(n: Int, overlap: Float) {
            val tw = w / n
            val th = h / n
            val ow = (tw * overlap).toInt()
            val oh = (th * overlap).toInt()
            for (iy in 0 until n) for (ix in 0 until n) {
                val l = max(0, ix * tw - ow)
                val t = max(0, iy * th - oh)
                val r = min(w, (ix + 1) * tw + ow)
                val b = min(h, (iy + 1) * th + oh)
                if (r - l > 64 && b - t > 64) out.add(Rect(l, t, r, b))
            }
        }
        grid(2, 0.2f)
        grid(3, 0.25f)
        return out
    }

    private fun crop(bmp: Bitmap, r: Rect): Bitmap {
        if (r.left == 0 && r.top == 0 && r.width() == bmp.width && r.height() == bmp.height) return bmp
        return Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
    }

    private fun zxing(crop: Bitmap, ox: Int, oy: Int, out: MutableList<Found>) {
        val w = crop.width
        val h = crop.height
        val px = IntArray(w * h)
        crop.getPixels(px, 0, w, 0, 0, w, h)
        val src = RGBLuminanceSource(w, h, px)
        val hints = mapOf<DecodeHintType, Any>(
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)
        )
        for (mode in 0..1) {
            val bin = if (mode == 0) HybridBinarizer(src) else GlobalHistogramBinarizer(src)
            try {
                val results = QRCodeMultiReader().decodeMultiple(BinaryBitmap(bin), hints)
                for (res in results) {
                    val pts = res.resultPoints
                    var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
                    var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                    if (pts != null) for (p in pts) {
                        minX = min(minX, p.x); maxX = max(maxX, p.x)
                        minY = min(minY, p.y); maxY = max(maxY, p.y)
                    }
                    val box = if (pts != null && pts.isNotEmpty()) {
                        val pad = max(10f, 0.25f * max(maxX - minX, maxY - minY))
                        Rect(
                            (minX - pad).toInt() + ox, (minY - pad).toInt() + oy,
                            (maxX + pad).toInt() + ox, (maxY + pad).toInt() + oy
                        )
                    } else Rect(ox, oy, ox + w, oy + h)
                    out.add(Found(res.text ?: "", box))
                }
            } catch (_: Exception) {
                // nothing found in this tile with this decoder
            }
        }
    }

    // Loads the picture upright (EXIF) and no bigger than MAX_SIDE on its long side.
    private fun loadBitmap(uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longest = max(bounds.outWidth, bounds.outHeight)
        if (longest <= 0) return null
        var sample = 1
        while (longest / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        var degrees = 0
        try {
            resolver.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> degrees = 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> degrees = 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> degrees = 270
                }
            }
        } catch (_: Exception) { }

        val big = max(bmp.width, bmp.height)
        val scale = if (big > MAX_SIDE) MAX_SIDE.toFloat() / big else 1f
        if (degrees != 0 || scale != 1f) {
            val m = Matrix()
            if (degrees != 0) m.postRotate(degrees.toFloat())
            if (scale != 1f) m.postScale(scale, scale)
            val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (t !== bmp) { bmp.recycle(); bmp = t }
        }
        return bmp
    }
}
