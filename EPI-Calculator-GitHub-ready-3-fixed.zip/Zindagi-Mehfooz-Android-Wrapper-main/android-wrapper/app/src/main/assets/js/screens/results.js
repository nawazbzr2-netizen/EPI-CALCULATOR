let inUcRecordsGlobal = [];
let outUcRecordsGlobal = [];
let outTalukaRecordsGlobal = [];
let outDistrictRecordsGlobal = [];
let allRecordsGlobal = [];       // every saved record, unfiltered (only the filter pickers use this)
let filteredRecordsGlobal = [];  // after UC + month + vaccinator filter — Search, Results by Date and Stock use this
let currentGroupType = 'in';

// Re-applies the status / UC rules to every stored record.
// This MUST be the single source of truth: the screen, the CSV export and the
// PDF exports all go through it, so a report can never disagree with what the
// app is showing (older records saved before these rules existed used to be
// labelled "In UC" in the CSV while the screen said "Out From Taluka").
let _normMemo = null;
function normalizeStoredRecords(store){
  // Same input + same login + same saved data => same answer, so don't redo it.
  let loginSig = '';
  try { loginSig = [localStorage.getItem('epi_login_district'), localStorage.getItem('epi_login_tehsil'), localStorage.getItem('epi_login_uc')].join('|'); } catch (e) {}
  const sig = window.__storeVer + '|' + window.__defVer + '|' + loginSig;
  if (_normMemo && _normMemo.store === store && _normMemo.sig === sig) return _normMemo.out;
  const epiMap = buildEpiMap();   // QR code -> 8-digit EPI No (from saved Defaulters Reports)
  const out = Object.values(store).map(r => {
    // Status is always re-derived fresh from the Address vs. the currently
    // logged-in District/Tehsil/UC — this is the single source of truth
    // (see js/core/location-context.js), so results stay correct even for
    // records saved under an older version of the app / a different login.
    const facilityUc = addressFilterName(r.address);
    const status = addressLocationStatus(r.address); // 'in_uc' | 'out_uc' | 'out_taluka' | 'out_district'
    const outOfUc = status === 'out_uc';
    const outOfTaluka = status === 'out_taluka';
    const outOfDistrict = status === 'out_district';
    const facility = facilityUc || (outOfDistrict ? 'Out From District' : 'Out From Taluka');
    return { ...r, status, outOfUc, outOfTaluka, outOfDistrict, facility, epiNo: r.epiNo || epiMap[r.id] || null };
  });
  _normMemo = { store, sig, out };
  return out;
}

// ---------- LAZY RESULTS ----------
// Processing / saving a PDF only reads and saves the data. The result lists (In UC, Out of UC,
// filters, dashboards) are worked out later, the first time a result screen is opened - and only
// again if the saved data changed.
let resultsDirty = true;
function markResultsDirty(){ resultsDirty = true; }
function ensureResults(){ if (resultsDirty) renderResults(loadStore(), true); }
// Cheap "data changed" refresh: file lists + buttons now, results on first use.
function refreshResultsLazy(){
  markResultsDirty();
  try { renderProcessedFileLists(); } catch (e) {}
  try { if (typeof updateProcessButtonState === 'function') updateProcessButtonState(); } catch (e) {}
}

// ---------- PAGED CARD LISTS ----------
// Thousands of cards put in the page at once freeze a phone. Show 40 at a time; the next 40 load
// when the person scrolls down (or taps the button). PDF export still uses the FULL list.
const CARD_PAGE_SIZE = 40;
function renderPagedCards(box, total, chunkHtml, prefixHtml){
  box.innerHTML = prefixHtml || '';
  const list = document.createElement('div');
  list.className = 'child-list';
  box.appendChild(list);
  const more = document.createElement('button');
  more.type = 'button';
  more.style.cssText = 'display:none;width:100%;margin:12px 0;padding:11px 16px;border-radius:12px;border:1px solid #d8d2c8;background:#fff;font-weight:600;cursor:pointer;';
  box.appendChild(more);
  let shown = 0, io = null;
  function load(){
    if (shown >= total) return;
    const end = Math.min(shown + CARD_PAGE_SIZE, total);
    list.insertAdjacentHTML('beforeend', chunkHtml(shown, end));
    shown = end;
    if (shown >= total) { more.style.display = 'none'; if (io) io.disconnect(); }
    else { more.style.display = 'block'; more.textContent = 'Show more (' + (total - shown) + ' left)'; }
  }
  more.addEventListener('click', load);
  load();
  if (total > CARD_PAGE_SIZE && 'IntersectionObserver' in window) {
    io = new IntersectionObserver(entries => { if (entries.some(e => e.isIntersecting)) load(); }, { rootMargin: '500px' });
    io.observe(more);
  }
}

function renderResults(store, keepView){
  resultsDirty = false;
  const allRecords = normalizeStoredRecords(store);
  // allRecordsGlobal = every record (feeds the month / vaccinator pickers).
  allRecordsGlobal = allRecords;
  filteredRecordsGlobal = allRecords;

  renderProcessedFileLists();
  updateProcessButtonState();

  if (allRecords.length === 0) {
    inUcRecordsGlobal = []; outUcRecordsGlobal = []; outTalukaRecordsGlobal = []; outDistrictRecordsGlobal = [];
    try { const ucEl = document.getElementById('ucFilter'); if (ucEl) ucEl.innerHTML = '<option value="__all__">All (All UCs Combined)</option>'; } catch (e) {}
    if (!keepView) {
      document.getElementById('uploadView').style.display = 'block';
      resultsWrap.style.display = 'none';
    }
    return;
  }

  // populate / preserve UC filter dropdown from Address endings.
  // The filter lists the logged-in Tehsil's own UCs (from the login
  // selection) plus Out From Taluka / Out From District. Falls back to the
  // original Mirpur Mathelo list if no login context is available.
  const ucFilterEl = document.getElementById('ucFilter');

  // 1) Month + Vaccinator/Center filter first (js/core/report-filter.js), so the
  //    UC list below only shows the UCs where the chosen vaccinator(s) worked.
  if (typeof reconcileReportFilter === 'function') reconcileReportFilter(allRecords);
  const vcFiltered = (typeof applyReportFilter === 'function') ? applyReportFilter(allRecords) : allRecords;

  // populate / preserve UC filter dropdown from Address endings.
  // The filter lists the logged-in Tehsil's own UCs (from the login
  // selection) plus Out From Taluka / Out From District. Falls back to the
  // original Mirpur Mathelo list if no login context is available.
  const facilities = [...new Set(vcFiltered.map(r => r.facility || 'Out From Taluka'))];
  const loginCtx = window.EPI_LOCATION_CONTEXT;
  const ucOrder = (loginCtx ? loginCtx.ucsInTehsil.slice() : [
    'Dhangro','Wahi Ghoto','Garhi Chakar','Jarwar',
    'Mirpur Mathelo- Mirpur Mathelo 1','Mirpur Mathelo 2',
    'Sono Pitafi','Yaro Lund'
  ]).concat(['Out From Taluka','Out From District']);
  facilities.sort((a,b) => {
    const ia = ucOrder.indexOf(a), ib = ucOrder.indexOf(b);
    return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
  });
  const prevSelection = ucFilterEl.value;
  ucFilterEl.innerHTML = `<option value="__all__">All (All UCs Combined)</option>` +
    facilities.map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join('');
  if (prevSelection && (prevSelection === '__all__' || facilities.includes(prevSelection))) {
    ucFilterEl.value = prevSelection;
  } else {
    ucFilterEl.value = '__all__';
  }

  // 2) Then the UC filter.
  const selected = ucFilterEl.value;
  const records = selected === '__all__' ? vcFiltered : vcFiltered.filter(r => (r.facility || 'Out From Taluka') === selected);
  // Search, Results by Date, Stock and every result page read these filtered
  // records, so ONE filter (UC + month + vaccinator) drives every screen.
  filteredRecordsGlobal = records;
  updateReportFilterLabels();

  // IN UC = Identifier does not contain 'Out of UC', and the address is not
  // Out From Taluka/District either — an address outside the tehsil (or
  // outside the district) is never "in UC".
  inUcRecordsGlobal = records.filter(r => !r.outOfUc && !r.outOfTaluka && !r.outOfDistrict);
  // OUT OF UC page = Out of UC + Out From Taluka + Out From District records.
  outUcRecordsGlobal = records.filter(r => r.outOfUc || r.outOfTaluka || r.outOfDistrict);
  // Out From Taluka / Out From District records stay as separate categories
  // so they can be identified in the detailed list, but they are ALSO
  // included in the OUT OF UC result/dashboard. Never cut or discarded.
  outTalukaRecordsGlobal = records.filter(r => r.outOfTaluka);
  outDistrictRecordsGlobal = records.filter(r => r.outOfDistrict);

  if (!keepView) {
    document.getElementById('uploadView').style.display = 'none'; // step 3: upload menu only lives on page 1
    resultsWrap.style.display = 'block';
    showHubView(); // step 2: after data is (re)loaded, land on the 3-option menu page
  }
}

const AGE_LABELS = { b0: '0–11 Months', b1: '12–23 Months', b2: '24–59 Months', tt: 'All T-D', all: 'All Category' };
const AGE_PAGE_TITLES = {
  b0: '0–11 Months',
  b1: '12–23 Months',
  b2: '24–59 Months',
  tt: 'All T-D',
  all: 'All Category'
};
// Bracket label for titles: filtered UC/Taluka/District name when set,
// otherwise (In UC) / (Out Of UC) / (In+Out Uc) / date.
function groupScopeSuffix(){
  // When a specific UC / Out From Taluka / Out From District is selected via
  // the filter, every subsequent result page (0-11, 12-23, 24-59, All T-D,
  // All Category, drill lists) shows that name in the header.
  if (currentGroupFacilityLabel) return currentGroupFacilityLabel;
  if (currentGroupType === 'in') return 'In UC';
  if (currentGroupType === 'out') return 'Out Of UC';
  if (currentGroupType === 'all') return 'In+Out Uc';
  if (currentGroupType === 'date' && typeof currentSelectedDateStr === 'string' && currentSelectedDateStr) {
    // currentSelectedDateStr is YYYY-MM-DD → show DD/MM/YYYY
    var p = currentSelectedDateStr.split('-');
    if (p.length === 3) return p[2] + '/' + p[1] + '/' + p[0];
    return currentSelectedDateStr;
  }
  return '';
}
let currentAgeKey = null; // 'b0' | 'b1' | 'b2' | 'tt' | 'all' while ageDashView is open
let currentDrillLabel = null; // vaccine/dose label of the list currently open on drillView, for filenames

// ---------- download FILE NAME helpers (separate from the on-screen titles) ----------
// Category word used inside a downloaded file's name.
function categoryLabelForFilename(type){
  if (type === 'in') return 'In Uc';
  if (type === 'out') return 'Out Uc';
  if (type === 'all') return 'In & Out Uc';
  return ''; // 'date' (Results by Date) and per-facility pages keep the old naming
}
// Age-group word used inside a downloaded file's name.
const AGE_FILE_LABELS = { b0: '0-11', b1: '12-23', b2: '24-59', tt: 'All T-D', all: 'All' };
// "In Uc 0-11 Vaccinated" / "Out Uc All T-D Vaccinated" / "BCG In Uc 0-11 Vaccinated" ...
function resultsFileName(ageKey, vaccineLabel){
  // Prefer filtered UC / Out From Taluka / Out From District name in the
  // downloaded file name when the filter is active.
  let cat = currentGroupFacilityLabel
    ? String(currentGroupFacilityLabel)
    : categoryLabelForFilename(currentGroupType);
  if (!cat) return null; // fall back to the old EPI-...-timestamp naming
  const age = AGE_FILE_LABELS[ageKey] || '';
  const parts = [];
  if (vaccineLabel) parts.push(vaccineLabel);
  parts.push(cat);
  if (age) parts.push(age);
  parts.push('Vaccinated');
  // vaccine labels like "Penta/OPV 1" or "OPV-0 (Birth)" contain characters
  // that are not safe in a downloaded file's name — clean those up here,
  // never in the on-screen labels themselves.
  return parts.join(' ')
    .replace(/[\/\\:*?"<>|]/g, '-')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

// "In Uc Results → 0-11 → Measles1" — shown in the downloaded PDF's header
// (in place of the on-screen title) for In UC / Out of UC / In & Out UC
// downloads; returns null for Results by Date and per-facility pages, which
// keep the plain on-screen title in the PDF header.
function resultsBreadcrumb(ageKey, vaccineLabel){
  let catLabel;
  // Filtered UC / facility name takes priority in PDF headers too.
  if (currentGroupFacilityLabel) catLabel = String(currentGroupFacilityLabel) + ' Results';
  else if (currentGroupType === 'in') catLabel = 'In Uc Results';
  else if (currentGroupType === 'out') catLabel = 'Out of Uc Results';
  else if (currentGroupType === 'all') catLabel = 'In & Out of Uc Results';
  else return null;
  const parts = [catLabel];
  const age = AGE_FILE_LABELS[ageKey] || '';
  if (age) parts.push(age);
  if (vaccineLabel) parts.push(vaccineLabel);
  return parts.join(' → ');
}

const EPI_SHORT = {
  BCG:'BCG', HepB:'Hepatitis B', OPV0:'OPV-0', Penta1:'Penta1', Penta2:'Penta2',
  Penta3:'Penta3', Measles1:'Measles 1', Measles2:'Measles2'
};

function ageBracketKey(am){ return am <= 11 ? 'b0' : (am <= 23 ? 'b1' : 'b2'); }

// TT (Tetanus) rows belong to women and are grouped/counted by dose, never by age.
function recordGroupKey(r){ return isTtRecord(r.doses) ? 'tt' : ageBracketKey(ageMonths(r.dob, r.vaccDate)); }

// full detail list for a group (Inside UC or Outside UC): name, father's name, address, vaccine, date
const lastRendered = {}; // elId -> the exact record list currently shown there (used by the PDF export)

// ONE on-screen result card, used by every list that shows vaccinated
// children/women (vaccine drill-down, search, hidden detail lists).
// The card shows EPI No and QR Code exactly like the Defaulter Children cards.
// opts.shareButton adds a per-child "Share / Download" button (Search Records).
function recordCardAvatarSrc(r, isTt){
  // Same embedded JPEGs as Card Style PDF (js/export/pdf-assets.js)
  try {
    if (isTt && typeof WOMAN_AVATAR_B64 === 'string' && WOMAN_AVATAR_B64.length > 50)
      return 'data:image/jpeg;base64,' + WOMAN_AVATAR_B64;
    var g = r && r.gender;
    if (g) {
      g = String(g).trim().toUpperCase();
      if (g === 'SON' || g === 'MALE' || g === 'BOY') g = 'M';
      if (g === 'DAUGHTER' || g === 'FEMALE' || g === 'GIRL') g = 'F';
    }
    if (g === 'M' && typeof BOY_AVATAR_B64 === 'string' && BOY_AVATAR_B64.length > 50)
      return 'data:image/jpeg;base64,' + BOY_AVATAR_B64;
    if (g === 'F' && typeof GIRL_AVATAR_B64 === 'string' && GIRL_AVATAR_B64.length > 50)
      return 'data:image/jpeg;base64,' + GIRL_AVATAR_B64;
  } catch (e) {}
  return null;
}


// Pull a phone number from a daily-registry record (address text), same idea as Defaulters.
function phoneFromDailyRecord(r){
  if (r && r.phone) return String(r.phone).trim();
  const src = [r && r.address, r && r.fatherName, r && r.name].filter(Boolean).join(' ');
  if (!src) return '';
  let re;
  try {
    re = (typeof PHONE_RE !== 'undefined' && PHONE_RE)
      ? PHONE_RE
      : /(?:(?<![\p{L}])(?:mobile|mob|cell|phone|ph|contact|cont|tel|whatsapp|no|number)\b\.?\s*(?:no|number|#)?\.?\s*[:#\-]?\s*)?\+?\(?\d[\d\s\-.()]{5,}\d/giu;
  } catch (e) {
    re = /\+?\d[\d\s\-.]{6,}\d/g;
  }
  re.lastIndex = 0;
  const m = src.match(re);
  if (!m || !m.length) return '';
  // Prefer the match with the most digits
  let best = m[0];
  let bestDigits = (best.match(/\d/g) || []).length;
  for (const x of m) {
    const d = (x.match(/\d/g) || []).length;
    if (d > bestDigits) { best = x; bestDigits = d; }
  }
  const digits = best.replace(/\D/g, '');
  if (digits.length < 7) return '';
  return best.replace(/\s+/g, ' ').trim();
}

function recordCardHtml(r, idx, opts){
  opts = opts || {};
  const isTt = isTtRecord(r.doses);
  const dobText = r.dob ? `${String(r.dob.day).padStart(2,'0')}/${String(r.dob.month).padStart(2,'0')}/${r.dob.year}` : '—';
  const tags = isTt ? classifyTT(r.doses) : classifyEpi(r.doses);
  const vaccineText = tags.length
    ? tags.map(t => isTt ? (TT_LABELS[t] || t) : (EPI_SHORT[t] || t)).join(', ')
    : (isTt ? 'No TT dose recorded' : 'No vaccine recorded');
  const personLabel = isTt ? 'Husband Name' : 'Father Name';
  const shareBtn = opts.shareButton
    ? `<button type="button" class="card-share-btn" data-idx="${idx}">📤 Share / Download this card</button>`
    : '';
  const avSrc = recordCardAvatarSrc(r, isTt);
  const avHtml = avSrc
    ? `<img class="card-gender-avatar" src="${avSrc}" alt="" width="56" height="56">`
    : '';
  const phone = phoneFromDailyRecord(r);
  const phoneRow = phone
    ? `<div class="result-line"><span class="result-label">Mobile</span><span class="result-value phone-row"><span class="phone-num">${escapeHtml(phone)}</span><button type="button" class="call-btn" data-call="${escapeHtml(phone)}" aria-label="Call ${escapeHtml(phone)}">📞 Call</button></span></div>`
    : '';
  const epiQr = `${r.epiNo || '—'} / ${r.id || '—'}`;
  // Layout matches Card Style share/download PDF: combined EPI/QR bar, then
  // Name / Father / DOB, vaccination line, address, optional mobile + call.
  return `<article class="child-card result-card">
      <div class="qr-code qr-code-combined"><span class="qr-label">EPI No / QR Code</span><span class="qr-right"><span class="qr-number">${escapeHtml(epiQr)}</span>${r.id ? `<button type="button" class="qr-copy-btn" data-qr-copy="${escapeHtml(r.id)}">📋 Copy</button>` : ''}</span></div>
      <div class="card-top-row">${avHtml}<div class="card-top-main">
      <div class="result-line"><span class="result-label">Name</span><span class="result-value person-name">${r.name ? escapeHtml(r.name) : 'Name not recorded'}</span></div>
      <div class="result-line"><span class="result-label">${personLabel}</span><span class="result-value">${r.fatherName ? escapeHtml(r.fatherName) : '—'}</span></div>
      <div class="result-line"><span class="result-label">Date of Birth</span><span class="result-value">${dobText}</span></div>
      </div></div>
      <div class="result-vaccine"><span class="result-label">Vaccination Date → Dose → Vaccinator</span><span class="result-value">${escapeHtmlMultiline(visitLinesText(r))}</span></div>
      <div class="result-address"><span class="result-label">Address</span><span class="result-value">${r.address ? escapeHtml(r.address) : '—'}</span></div>
      ${phoneRow}
      <div class="result-meta"><span>No. ${idx + 1}</span><span>${r.outOfDistrict ? 'Out From District' : (r.outOfTaluka ? 'Out From Taluka' : (r.outOfUc ? 'Out of UC' : (isTt ? 'Woman' : AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))])))}</span></div>
      ${shareBtn}
    </article>`;
}

function renderDetailTable(records, elId){
  const order = { b1: 0, b0: 1, b2: 2, tt: 3 };
  const keyed = records.map(r => [order[recordGroupKey(r)], r]);   // work out each key once, not on every comparison
  keyed.sort((a, b) => a[0] - b[0]);
  const list = keyed.map(x => x[1]);
  lastRendered[elId] = list;

  const box = document.getElementById(elId);
  if (!list.length) { box.innerHTML = '<div style="color:var(--muted);">No records in this list.</div>'; return; }
  renderPagedCards(box, list.length, (a, b) => list.slice(a, b).map((r, i) => recordCardHtml(r, a + i)).join(''));
}

// one-vaccine drill-down list (and the Search Records results)
function renderDrillTable(records, elId, opts){
  lastRendered[elId] = records.slice();
  const box = document.getElementById(elId);
  if (!records.length) { box.innerHTML = '<div style="color:var(--muted);">No records for this box.</div>'; return; }
  renderPagedCards(box, records.length, (a, b) => records.slice(a, b).map((r, i) => recordCardHtml(r, a + i, opts)).join(''));
}

// ---------- page navigation: hub (page2) → group (page3) → drill (page4) ----------
const ALL_VIEW_IDS = ['hubView','groupView','ageDashView','drillView','searchView','dateView','stockView','qrResultView','defaulterChildrenView','defByAddressView','defByVaccineView','defDetailView','groupByVillageView','groupVillageDetailView'];
function hideAllViews(){
  ALL_VIEW_IDS.forEach(id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
}

function showHubView(){
  ensureResults();
  hideAllViews();
  document.getElementById('hubView').style.display = 'block';
  window.scrollTo(0, 0);
}

let currentGroupFacilityLabel = null;

function showGroupView(type, facilityLabel){
  ensureResults();
  currentGroupType = type;
  currentGroupFacilityLabel = facilityLabel || null;
  // Keep Out From Taluka records included in the OUT OF UC result,
  // and also in this page's Complete Details. Do not remove them anywhere.
  // outUcRecordsGlobal already contains both Out of UC + Out From Taluka records.
  const outRecords = outUcRecordsGlobal;
  const detailRecs = type === 'in' ? inUcRecordsGlobal
    : (type === 'out' ? outRecords
    : inUcRecordsGlobal.concat(outRecords));
  const recs = type === 'in' ? inUcRecordsGlobal
    : (type === 'out' ? outRecords : inUcRecordsGlobal.concat(outRecords));
  // Measles2 must always be counted correctly in the 12-23 and 24+ month
  // boxes — it used to be hidden there (always showing 0) for "IN UC"
  // results specifically, which was wrong: that exclusion only ever made
  // sense for the 0-11 month box (Measles2 isn't part of that schedule —
  // see the unconditional skip in fillDashboard above), not for 12-23/24+.
  const excludeMeasles2FromB = false;
  if (currentGroupFacilityLabel) {
    document.getElementById('groupTitle').textContent = `📋 ${currentGroupFacilityLabel} — Children and Women Results`;
    document.getElementById('groupDetailHeading').innerHTML = `${escapeHtml(currentGroupFacilityLabel)} Complete Details for <span style="font-size:11px;color:var(--muted);">(Name, Father/Husband Name, Address, Vaccine, Date)</span>`;
  } else {
    document.getElementById('groupTitle').textContent = type === 'in'
      ? '📋 IN UC Children and Women Results'
      : (type === 'out' ? '📋 OUT OF UC Children and Women Results' : '📋 In & Out Uc Results');
    document.getElementById('groupDetailHeading').innerHTML = `Complete Details <span style="font-size:11px;color:var(--muted);">(Name, Father/Husband Name, Address, Vaccine, Date)</span>`;
  }
  fillDashboard(document.getElementById('groupDash'), recs, excludeMeasles2FromB,
    (ageKey) => showAgeDashView(ageKey, excludeMeasles2FromB));
  renderDetailTable(detailRecs, 'groupDetailTable');
  hideAllViews();
  document.getElementById('groupView').style.display = 'block';
  window.scrollTo(0, 0);
}

function showAgeDashView(ageKey, excludeMeasles2FromB){
  currentAgeKey = ageKey;
  const recs = currentGroupType === 'in' ? inUcRecordsGlobal
    : (currentGroupType === 'out' ? outUcRecordsGlobal
    : (currentGroupType === 'date' ? dateFilteredRecordsGlobal
    : Array.from(new Map(inUcRecordsGlobal.concat(outUcRecordsGlobal).map(r => [r.id + '|' + (r.vaccDate?.year||'') + '|' + (r.vaccDate?.month||'') + '|' + (r.vaccDate?.day||''), r])).values())));

  const ageLabel = AGE_PAGE_TITLES[ageKey] || ageKey;
  const scope = groupScopeSuffix();
  const title = scope ? `${ageLabel} (${scope})` : ageLabel;
  document.getElementById('ageDashTitle').textContent = '📋 ' + title;

  const dashEl = document.getElementById('ageDash');
  dashEl.innerHTML = ageDashCardsHTML(recs, ageKey, excludeMeasles2FromB);
  dashEl.querySelectorAll('.stat-card.clickable').forEach(el => {
    el.addEventListener('click', () => showDrillView(el.dataset.tag, el.dataset.kind, excludeMeasles2FromB, ageKey));
  });
  // All Category compact tables: each vaccine row opens the child list
  dashEl.querySelectorAll('tr.ct-row-click').forEach(el => {
    el.addEventListener('click', () => {
      const tag = el.dataset.tag;
      const kind = el.dataset.kind;
      const hint = el.dataset.ageHint || ageKey;
      if (!tag || !kind) return;
      showDrillView(tag, kind, excludeMeasles2FromB, hint);
    });
  });

  hideAllViews();
  document.getElementById('ageDashView').style.display = 'block';
  window.scrollTo(0, 0);
}

function showDrillView(tag, kind, excludeMeasles2FromB, ageKeyHint){
  window.__qrChildBack = false;
  const recs = currentGroupType === 'in' ? inUcRecordsGlobal : (currentGroupType === 'out' ? outUcRecordsGlobal : (currentGroupType === 'date' ? dateFilteredRecordsGlobal : Array.from(new Map(inUcRecordsGlobal.concat(outUcRecordsGlobal).map(r => [r.id + '|' + (r.vaccDate?.year||'') + '|' + (r.vaccDate?.month||'') + '|' + (r.vaccDate?.day||''), r])).values())));
  const list = recordsForTag(recs, tag, kind, excludeMeasles2FromB, ageKeyHint || currentAgeKey);
  const label = kind === 'tt' ? (TT_LABELS[tag] || tag) : (EPI_LABELS[tag] || tag);
  currentDrillLabel = label;
  const scope = groupScopeSuffix();
  document.getElementById('drillTitle').textContent = scope
    ? `${label} — Complete List (${list.length}) · ${scope}`
    : `${label} — Complete List (${list.length})`;
  renderDrillTable(list, 'drillDetailTable');
  hideAllViews();
  document.getElementById('drillView').style.display = 'block';
  window.scrollTo(0, 0);
}

// ---------- PAGE 5: Search — filter across every processed vaccinated record ----------

// ---------- Village-wise list for Daily Immunization (In UC / Out of UC / In & Out) ----------
// Uses groupItemsByAddress() from defaulters.js so "Banho Khushk" and "banhu khushak" stay together.
let currentVillageRecords = [];
let currentVillageLabel = '';

function groupRecordsByAddress(records){
  // Same rules as Defaulters by Address (see groupItemsByAddress in defaulters.js).
  return groupItemsByAddress(records);
}

function currentGroupRecordsForVillage(){
  if (currentGroupType === 'in') return inUcRecordsGlobal;
  if (currentGroupType === 'out') return outUcRecordsGlobal;
  return Array.from(new Map(
    inUcRecordsGlobal.concat(outUcRecordsGlobal).map(r =>
      [r.id + '|' + (r.vaccDate?.year||'') + '|' + (r.vaccDate?.month||'') + '|' + (r.vaccDate?.day||''), r]
    )
  ).values());
}

function groupScopeTitleForVillage(){
  if (currentGroupFacilityLabel) return String(currentGroupFacilityLabel);
  if (currentGroupType === 'in') return 'IN UC';
  if (currentGroupType === 'out') return 'OUT OF UC';
  return 'In & Out UC';
}

function showGroupByVillageView(){
  ensureResults();
  const recs = currentGroupRecordsForVillage();
  const scope = groupScopeTitleForVillage();
  document.getElementById('groupByVillageTitle').textContent = `📍 ${scope} — Village-wise List`;
  const groups = groupRecordsByAddress(recs);
  const entries = Object.entries(groups).sort((a, b) => a[0].localeCompare(b[0], undefined, { sensitivity: 'base' }));
  const listEl = document.getElementById('groupByVillageList');
  if (!entries.length) {
    listEl.innerHTML = `<div class="card"><div style="color:var(--muted);">No vaccinated records in this list.</div></div>`;
  } else {
    listEl.innerHTML = `<div class="card">${entries.map(([addr, list], i) => `
      <div class="date-row addr-row">
        <button type="button" class="addr-row-main" data-i="${i}">
          <span class="dname">📍 ${escapeHtml(addr)}</span>
          <span class="dcount">${list.length} ${list.length === 1 ? 'record' : 'records'}</span>
        </button>
        <button type="button" class="age-pdf-btn" data-i="${i}" title="Share / Download PDF for ${escapeHtml(addr)}">📤</button>
      </div>`).join('')}</div>`;
    listEl.querySelectorAll('.addr-row-main').forEach((btn, i) => {
      const [addr, list] = entries[i];
      btn.addEventListener('click', () => showGroupVillageDetailView(list, addr));
    });
    listEl.querySelectorAll('.date-row.addr-row .age-pdf-btn').forEach((btn, i) => {
      const [addr, list] = entries[i];
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const title = `${scope} — ${addr}`;
        const breadcrumb = `${scope} Results → Village: ${addr}`;
        runRecordsExportFlow(title, list, 'village-' + (i + 1), null, breadcrumb);
      });
    });
  }
  hideAllViews();
  document.getElementById('groupByVillageView').style.display = 'block';
  window.scrollTo(0, 0);
}

function showGroupVillageDetailView(list, addr){
  currentVillageRecords = (list || []).slice();
  currentVillageLabel = addr || '';
  const scope = groupScopeTitleForVillage();
  document.getElementById('groupVillageDetailTitle').textContent =
    `📍 ${addr} — ${currentVillageRecords.length} record${currentVillageRecords.length === 1 ? '' : 's'} · ${scope}`;
  renderDrillTable(currentVillageRecords, 'groupVillageDetailTable');
  hideAllViews();
  document.getElementById('groupVillageDetailView').style.display = 'block';
  window.scrollTo(0, 0);
}

document.getElementById('btnGroupByVillage').addEventListener('click', showGroupByVillageView);
document.getElementById('btnPdfVillageDetail').addEventListener('click', () => {
  if (!currentVillageRecords.length) { backupMsg('There is Nothing', true); return; }
  const scope = groupScopeTitleForVillage();
  const title = `${scope} — ${currentVillageLabel}`;
  const breadcrumb = `${scope} Results → Village: ${currentVillageLabel}`;
  runRecordsExportFlow(title, currentVillageRecords, 'village-detail', null, breadcrumb);
});

function showSearchView(){
  ensureResults();
  hideAllViews();
  document.getElementById('searchView').style.display = 'block';
  window.scrollTo(0, 0);
}
