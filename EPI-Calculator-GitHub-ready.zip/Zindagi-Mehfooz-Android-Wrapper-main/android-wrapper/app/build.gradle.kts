plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.zm.calculator"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.zm.calculator"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "1.7.0"
    }

    // One fixed signing key for every build (the key file is epi-signing.jks in this folder).
    // Because the signature never changes, each new APK installs OVER the previous one and the
    // data inside the app is kept. Keep the repository private.
    signingConfigs {
        create("epi") {
            storeFile = file("epi-signing.jks")
            storePassword = "epi-zindagi-2026"
            keyAlias = "epi"
            keyPassword = "epi-zindagi-2026"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("epi")
        }
        release {
            signingConfig = signingConfigs.getByName("epi")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    // Reads QR codes from pictures / photos, offline (model is bundled in the app)
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    // Reads the number printed beside a QR code when the QR itself can't be decoded (offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // A second QR decoder that finds many QR codes in one picture
    implementation("com.google.zxing:core:3.5.3")
}

