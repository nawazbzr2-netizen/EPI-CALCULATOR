package org.zm.calculator

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Log
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import androidx.lifecycle.Lifecycle
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    companion object {
        // Picture shown first when the app opens.
        private const val SPLASH_MS = 3500L

        // Where the SEIR app saves the vaccinator's reports.
        private const val REPORTS_PKG = "org.seir.android.norad"

        private const val PREFS = "epi_picker"
    }

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var splash: ImageView
    private var locHelper: ForegroundLocationHelper? = null
    private val io = Executors.newSingleThreadExecutor()

    // ---- splash / page-start state -------------------------------------
    private var splashTimerDone = false
    private var splashGone = false
    private var pageStarted = false
    private var pageFinished = false

    // "daily" | "defaulters" | "all" — set from the web page just before it
    // opens the file chooser, so each Insert button only takes its own PDFs.
    @Volatile
    var pickerKind: String = "all"

    // "seir" | "download" | "whatsapp" | "storage" — which folder the user chose.
    @Volatile
    var pickerSource: String = "seir"

    // Files that other apps shared into this app (copied into the cache folder).
    private class SharedFile(val name: String, val file: File)
    private val sharedFiles = ArrayList<SharedFile>()

    // The PDFs currently listed in the web page's in-app picker.
    private class Rep(val name: String, val size: Long, val modified: Long, val uri: Uri, val suggested: Boolean)
    private var pendingReps: List<Rep> = emptyList()

    private val treeAskedThisSession = HashSet<String>()
    private var allFilesAskedThisSession = false
    private var pendingTreeKey: String? = null

    // ---- file chooser ---------------------------------------------------
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = mutableListOf<Uri>()
        if (result.resultCode == RESULT_OK && result.data != null) {
            val data = result.data!!
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { uris.add(it) }
                }
            } else {
                data.data?.let { uris.add(it) }
            }
        }
        val arr = if (uris.isEmpty()) null else uris.toTypedArray()
        fileChooserCallback?.onReceiveValue(arr)
        fileChooserCallback = null
    }

    // One-time folder permission (Android 11+ blocks direct access to some
    // folders, so the folder is granted once and remembered per source).
    private val treeLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data
        val key = pendingTreeKey
        var done = false
        if (result.resultCode == RESULT_OK && uri != null && key != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                Log.w("EpiMain", "persist tree permission failed", e)
            }
            prefs().edit().putString(key, uri.toString()).apply()
            val list = listTreeFiles(uri)
            val cfg = sourceConfig(pickerSource)
            if (list != null && cfg != null) {
                showInAppList(list, cfg)
                done = true
            }
        }
        if (!done) openManualPicker(sourceConfig(pickerSource)?.docId)
    }

    // "All files access" (Android 11+): needed once so the app can read the
    // Download and WhatsApp Documents folders by itself.
    private val allFilesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        if (fileChooserCallback != null) {
            // Granted → read the folder now; refused → normal picker in that folder.
            startAutoPick()
        }
    }

    private fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    private fun askAllFilesAccess(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        return try {
            Toast.makeText(
                this,
                "ایپ کو فائلیں خود اٹھانے کی اجازت دیں: EPI Calculator کے آگے سوئچ آن کریں",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")
            )
            allFilesLauncher.launch(intent)
            true
        } catch (e: Exception) {
            try {
                allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                true
            } catch (e2: Exception) {
                Log.w("EpiMain", "all-files settings unavailable", e2)
                false
            }
        }
    }

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun docUri(docId: String): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        docId
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val locOk = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (locOk) {
            PassiveLocationWorker.schedule(this)
            locHelper?.start()
            flushQueueAsync()
        }
        // Whatever the answer, the page can start now (if location was denied
        // the page itself shows its "location required" screen with Retry).
        startPage()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        setContentView(root)

        // The web page sits underneath, the splash picture on top of it.
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(webView)

        splash = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            isClickable = true   // taps must not reach the page under the picture
            var loaded = false
            try {
                assets.open("splash.jpg").use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        setImageBitmap(bmp)
                        loaded = true
                    }
                }
            } catch (_: Exception) { }
            if (!loaded) {
                setBackgroundColor(0xFF1e3a5f.toInt())
            }
        }
        root.addView(splash)

        locHelper = ForegroundLocationHelper(this)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setGeolocationEnabled(true)

        val bridge = WebAppInterface(this)
        webView.addJavascriptInterface(bridge, "AndroidEpi")
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, true, false)
            }

            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                startAutoPick()
                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = false

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectProfileSync(view)
                view?.evaluateJavascript(
                    "if(typeof window.AndroidBridge==='undefined' && window.AndroidEpi){window.AndroidBridge=window.AndroidEpi;}",
                    null
                )
                pageFinished = true
                tryHideSplash()
                if (hasSharedFiles()) notifySharedReady()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!splashGone) {
                    // Picture is still showing — back just leaves the app.
                    finish()
                    return
                }
                webView.evaluateJavascript(
                    """
                    (function(){
                      try {
                        if (typeof goBackOneStep === 'function') {
                          var handled = goBackOneStep();
                          if (handled) return 'js';
                        }
                        if (typeof onNativeBackPressed === 'function') {
                          onNativeBackPressed();
                          return 'js-native';
                        }
                      } catch(e) {}
                      return 'none';
                    })();
                    """.trimIndent()
                ) { result ->
                    val r = result?.trim()?.trim('"') ?: "none"
                    if (r == "js" || r == "js-native") {
                        return@evaluateJavascript
                    }
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                }
            }
        })

        // The page always loads quietly behind the picture, so it is ready the
        // moment the picture goes. Location is NOT needed to open the app.
        startPage()

        Handler(Looper.getMainLooper()).postDelayed({
            splashTimerDone = true
            requestPermissionsFirstTimeOnly()   // first install only
            tryHideSplash()
            // Safety net: never leave the picture stuck on screen.
            Handler(Looper.getMainLooper()).postDelayed({
                if (pageStarted) tryHideSplash(force = true)
            }, 10000)
        }, SPLASH_MS)

        PassiveLocationWorker.schedule(this)

        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun startPage() {
        if (pageStarted) return
        pageStarted = true
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun tryHideSplash(force: Boolean = false) {
        if (splashGone || !splashTimerDone) return
        if (!force && !pageFinished) return
        splashGone = true
        splash.animate().alpha(0f).setDuration(350).withEndAction {
            root.removeView(splash)
        }.start()
    }

    // =====================================================================
    // Picking the report PDFs
    //   SEIR Folder / From Download / From WhatsApp: the folder is read here and
    //   the files are listed INSIDE the app (works with any file app).
    //   If a folder can't be read, or for "Storage" / "Other apps…", the phone's
    //   own chooser opens, where the person can pick any file app.
    // =====================================================================

    private class Source(
        val dirs: List<String>,
        val treeKey: String?,
        val docId: String?,
        val needsAllFiles: Boolean = false
    )

    private fun sourceConfig(src: String): Source? = when (src) {
        "seir" -> Source(
            listOf(
                "Android/data/$REPORTS_PKG/files/Download",
                "Android/data/$REPORTS_PKG/files/download"
            ),
            "tree_seir",
            "primary:Android/data/$REPORTS_PKG/files/Download"
        )
        // Android blocks folder-permission for the Download folder itself, so no tree key.
        "download" -> Source(listOf("Download"), null, "primary:Download", true)
        "whatsapp" -> Source(
            listOf("Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents"),
            "tree_whatsapp",
            "primary:Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents",
            true
        )
        else -> null   // "storage"
    }

    private fun isPdfName(name: String) = name.endsWith(".pdf", ignoreCase = true)

    // Which files are ticked from the start. SEIR's own folder holds only reports,
    // so everything there is ticked; elsewhere only names that look like the report.
    private fun isSuggested(name: String): Boolean {
        if (pickerSource == "seir") {
            val isDef = name.contains("defaulter", ignoreCase = true)
            return if (pickerKind == "defaulters") isDef else !isDef
        }
        return when (pickerKind) {
            "defaulters" -> name.contains("defaulter", ignoreCase = true)
            "daily" -> name.contains("immuniz", ignoreCase = true)
            else -> false
        }
    }

    /** null = folder can't be read directly; empty = readable but no PDF. */
    private fun listDirectFiles(cfg: Source): List<Rep>? {
        val base = Environment.getExternalStorageDirectory()
        var readable = false
        val seen = HashSet<String>()
        val found = ArrayList<Rep>()
        for (rel in cfg.dirs) {
            val dir = File(base, rel)
            val files: Array<File>? = try {
                dir.listFiles()
            } catch (e: Exception) {
                null
            }
            if (files == null) continue
            readable = true
            for (f in files) {
                if (f.isFile && f.canRead() && isPdfName(f.name)) {
                    // Storage is case-insensitive, so "Download" and "download" can be
                    // the same folder — list each file once.
                    if (seen.add(f.name + "|" + f.length())) {
                        found.add(Rep(f.name, f.length(), f.lastModified(), Uri.fromFile(f), isSuggested(f.name)))
                    }
                }
            }
        }
        if (!readable) return null
        // On Android 11+ an empty listing of someone else's files can't be trusted.
        if (found.isEmpty() && !hasAllFilesAccess()) return null
        return found
    }

    /** null = permission lost / unreadable; empty = readable but no PDF. */
    private fun listTreeFiles(treeUri: Uri): List<Rep>? {
        return try {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId)
            val out = ArrayList<Rep>()
            val cursor = contentResolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null, null, null
            ) ?: return null
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: ""
                    if (isPdfName(name)) {
                        val size = if (c.isNull(2)) 0L else c.getLong(2)
                        val mod = if (c.isNull(3)) 0L else c.getLong(3)
                        out.add(
                            Rep(
                                name, size, mod,
                                DocumentsContract.buildDocumentUriUsingTree(treeUri, id),
                                isSuggested(name)
                            )
                        )
                    }
                }
            }
            out
        } catch (e: Exception) {
            Log.w("EpiMain", "tree listing failed", e)
            null
        }
    }

    private fun startAutoPick() {
        val cfg = sourceConfig(pickerSource)
        if (cfg == null) {            // "Storage": the phone's own chooser
            openManualPicker(null)
            return
        }

        // 0) Download / WhatsApp: ask once for "All files access" (Android 11+)
        if (cfg.needsAllFiles && !hasAllFilesAccess() && !allFilesAskedThisSession) {
            allFilesAskedThisSession = true
            if (askAllFilesAccess()) return
        }

        // 1) direct folder read
        val direct = listDirectFiles(cfg)
        if (direct != null) {
            showInAppList(direct, cfg)
            return
        }

        // 2) remembered folder permission
        val key = cfg.treeKey
        if (key != null) {
            val saved = prefs().getString(key, null)
            if (saved != null) {
                val viaTree = listTreeFiles(Uri.parse(saved))
                if (viaTree != null) {
                    showInAppList(viaTree, cfg)
                    return
                }
                // Permission was taken away (or the folder moved) — forget it.
                prefs().edit().remove(key).apply()
            }

            // 3) ask once for the folder (once per app start, so a refusal is not nagging)
            if (treeAskedThisSession.add(key)) {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && cfg.docId != null) {
                            putExtra(DocumentsContract.EXTRA_INITIAL_URI, docUri(cfg.docId))
                        }
                    }
                    Toast.makeText(
                        this,
                        "فولڈر کی اجازت ایک بار دیں: «Use this folder» دبائیں",
                        Toast.LENGTH_LONG
                    ).show()
                    pendingTreeKey = key
                    val chooser = Intent.createChooser(intent, "فولڈر چنیں").apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                    treeLauncher.launch(chooser)
                    return
                } catch (e: Exception) {
                    Log.w("EpiMain", "tree picker unavailable", e)
                }
            }
        }

        // 4) the phone's own chooser (any file app), opened in that folder
        openManualPicker(cfg.docId)
    }

    // Hands the list of PDFs to the web page, which draws it with tick boxes.
    private fun showInAppList(reps: List<Rep>, cfg: Source) {
        val sorted = reps.sortedByDescending { it.modified }.take(400)
        pendingReps = sorted
        val items = JSONArray()
        for (r in sorted) {
            items.put(
                JSONObject()
                    .put("name", r.name)
                    .put("size", r.size)
                    .put("modified", r.modified)
                    .put("suggested", r.suggested)
            )
        }
        val title = when (pickerSource) {
            "seir" -> "SEIR Folder"
            "download" -> "Download"
            "whatsapp" -> "WhatsApp"
            else -> "Files"
        }
        val payload = JSONObject().put("title", title).put("items", items).toString()
        webView.evaluateJavascript("window.__epiShowPicker(" + JSONObject.quote(payload) + ");", null)
    }

    // ---- called from the web page's in-app list (through WebAppInterface) ----
    fun onPickerDone(json: String?) {
        val out = ArrayList<Uri>()
        try {
            val arr = JSONArray(json ?: "[]")
            for (i in 0 until arr.length()) {
                pendingReps.getOrNull(arr.getInt(i))?.let { out.add(it.uri) }
            }
        } catch (e: Exception) {
            Log.w("EpiMain", "picker result", e)
        }
        if (out.isEmpty()) onPickerCancel() else deliverAutoPicked(out)
    }

    fun onPickerCancel() {
        pendingReps = emptyList()
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
    }

    fun onPickerOtherApps() {
        pendingReps = emptyList()
        openManualPicker(sourceConfig(pickerSource)?.docId)
    }

    private fun deliverAutoPicked(uris: List<Uri>) {
        webView.evaluateJavascript("window.__epiAutoPick=true;", null)
        pendingReps = emptyList()
        fileChooserCallback?.onReceiveValue(uris.toTypedArray())
        fileChooserCallback = null
    }

    // The phone's own "choose a file" screen. Shown through a chooser so the person
    // can pick ANY file app installed (Files, Google Files, Cx, ...), not just the default.
    private fun openManualPicker(initialDocId: String?) {
        webView.evaluateJavascript("window.__epiAutoPick=false;", null)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && initialDocId != null) {
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, docUri(initialDocId))
            }
        }
        try {
            val chooser = Intent.createChooser(intent, "فائل چنیں").apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            fileChooserLauncher.launch(chooser)
        } catch (e: Exception) {
            Log.e("EpiMain", "file chooser failed", e)
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = null
        }
    }

    // =====================================================================
    // Files shared into the app from any other app (Share / Open with)
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun collectSharedUris(intent: Intent?): List<Uri> {
        if (intent == null) return emptyList()
        val out = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else intent.getParcelableExtra(Intent.EXTRA_STREAM)
                if (u != null) out.add(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val l: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                if (l != null) out.addAll(l)
            }
            Intent.ACTION_VIEW -> intent.data?.let { out.add(it) }
        }
        val clip = intent.clipData
        if (clip != null && (intent.action == Intent.ACTION_SEND || intent.action == Intent.ACTION_SEND_MULTIPLE)) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out.add(it) }
        }
        return out.distinct()
    }

    private fun displayName(u: Uri): String? {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getString(0)
            }
        } catch (_: Exception) { }
        return u.lastPathSegment?.substringAfterLast('/')
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val uris = collectSharedUris(intent)
        if (uris.isEmpty()) return
        io.execute {
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val added = ArrayList<SharedFile>()
            for (u in uris) {
                try {
                    val name = displayName(u) ?: "shared.pdf"
                    val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val out = File(dir, "${System.currentTimeMillis()}_${added.size}_$safe")
                    contentResolver.openInputStream(u)?.use { input ->
                        out.outputStream().use { input.copyTo(it) }
                    }
                    if (out.length() > 0) added.add(SharedFile(name, out))
                } catch (e: Exception) {
                    Log.w("EpiMain", "shared file copy failed", e)
                }
            }
            if (added.isNotEmpty()) {
                synchronized(sharedFiles) { sharedFiles.addAll(added) }
                runOnUiThread { notifySharedReady() }
            }
        }
    }

    private fun hasSharedFiles(): Boolean = synchronized(sharedFiles) { sharedFiles.isNotEmpty() }

    private fun notifySharedReady() {
        if (pageFinished) {
            webView.evaluateJavascript("if(window.__epiSharedReady)window.__epiSharedReady();", null)
        }
        // otherwise onPageFinished calls this again once the page is ready
    }

    // ---- read by the web page (through WebAppInterface, on the JS thread) ----
    fun sharedCount(): Int = synchronized(sharedFiles) { sharedFiles.size }

    fun sharedName(i: Int): String = synchronized(sharedFiles) { sharedFiles.getOrNull(i)?.name ?: "" }

    fun sharedBase64(i: Int): String {
        val f = synchronized(sharedFiles) { sharedFiles.getOrNull(i)?.file } ?: return ""
        return try {
            android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP)
        } catch (e: Exception) {
            Log.w("EpiMain", "shared read failed", e)
            ""
        }
    }

    fun sharedClear() {
        synchronized(sharedFiles) {
            for (s in sharedFiles) try { s.file.delete() } catch (_: Exception) { }
            sharedFiles.clear()
        }
    }

    // =====================================================================
    // QR codes read from a picture or a photo (Google ML Kit, works offline)
    // =====================================================================

    private var qrPhotoFile: File? = null

    private val qrImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = ArrayList<Uri>()
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
            } else {
                data.data?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) decodeQrFrom(uris)
    }

    private val qrCameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val f = qrPhotoFile
        if (result.resultCode == RESULT_OK && f != null && f.exists() && f.length() > 0) {
            decodeQrFrom(listOf(Uri.fromFile(f)))
        }
    }

    fun startQrFromGallery() {
        try {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            qrImageLauncher.launch(Intent.createChooser(intent, "تصویر چنیں"))
        } catch (e: Exception) {
            Toast.makeText(this, "Picture picker not available", Toast.LENGTH_SHORT).show()
        }
    }

    fun startQrFromCamera() {
        try {
            val dir = File(cacheDir, "qr").apply { mkdirs() }
            val f = File(dir, "qr_photo.jpg")
            if (f.exists()) f.delete()
            qrPhotoFile = f
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            qrCameraLauncher.launch(intent)
        } catch (e: Exception) {
            Log.w("EpiMain", "camera unavailable", e)
            Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show()
        }
    }

    // Reads every QR code in the pictures and sends the texts to the web page.
    private fun decodeQrFrom(uris: List<Uri>) {
        val scanner = BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        )
        val results = ArrayList<String>()
        val left = AtomicInteger(uris.size)
        fun oneDone() {
            if (left.decrementAndGet() == 0) {
                val json = JSONArray(results).toString()
                webView.evaluateJavascript(
                    "if(window.__epiQrScanned)window.__epiQrScanned(" + JSONObject.quote(json) + ");", null
                )
                try { scanner.close() } catch (_: Exception) { }
            }
        }
        for (u in uris) {
            val image = try {
                InputImage.fromFilePath(this, u)
            } catch (e: Exception) {
                Log.w("EpiMain", "image read failed", e)
                null
            }
            if (image == null) {
                oneDone()
                continue
            }
            scanner.process(image)
                .addOnSuccessListener { codes ->
                    for (c in codes) c.rawValue?.let { results.add(it) }
                }
                .addOnCompleteListener { oneDone() }
        }
    }

    // =====================================================================

    // The Android permission box is shown ONLY the first time after install.
    // Afterwards the app never asks again: it just uses whatever was allowed.
    private fun requestPermissionsFirstTimeOnly() {
        val appPrefs = getSharedPreferences("epi_app", Context.MODE_PRIVATE)
        if (appPrefs.getBoolean("perm_asked", false)) {
            startTrackingIfAllowed()
            return
        }
        appPrefs.edit().putBoolean("perm_asked", true).apply()

        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACCESS_COARSE_LOCATION)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        ) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        if (need.isNotEmpty()) {
            permissionLauncher.launch(need.toTypedArray())
        } else {
            startTrackingIfAllowed()
        }
    }

    // Sends location by itself when it is allowed; does nothing (no box, no error)
    // when it is not, or when the phone's GPS is off.
    private fun startTrackingIfAllowed() {
        if (hasLocationPermission()) {
            PassiveLocationWorker.schedule(this)
            locHelper?.start()
        }
    }

    override fun onResume() {
        super.onResume()
        if (splashTimerDone) {
            startTrackingIfAllowed()
            flushQueueAsync()
        }
    }

    override fun onPause() {
        locHelper?.stop()
        super.onPause()
    }

    override fun onDestroy() {
        locHelper?.stop()
        super.onDestroy()
    }

    private fun flushQueueAsync() {
        io.execute {
            try {
                val n = LocationUploader.flushQueue(applicationContext)
                Log.i("EpiMain", "flushed queue on open: $n")
            } catch (_: Exception) {
            }
        }
    }

    private fun injectProfileSync(view: WebView?) {
        val js = """
            (function(){
              try {
                if (window.AndroidEpi) {
                  var n = localStorage.getItem('epi_login_name') || '';
                  var c = localStorage.getItem('epi_login_center') || '';
                  var d = localStorage.getItem('epi_login_district') || '';
                  var t = localStorage.getItem('epi_login_tehsil') || '';
                  var u = localStorage.getItem('epi_login_uc') || '';
                  AndroidEpi.saveProfile(n, c, d, t, u);
                }
              } catch (e) {}
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    fun requestLocationIfNeeded() {
        startTrackingIfAllowed()
    }

    fun ensurePermissionsAndStartTracking() {
        if (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return
        startTrackingIfAllowed()
    }
}
