// NEW FILE: app/src/main/java/<your package>/ReportFinder.kt
// Change the package line to the same package as MainActivity.kt (e.g. org.zm.calculator).
package org.zm.calculator

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Base64
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile

/** Lists PDFs (WhatsApp + WhatsApp Business, or the whole phone) and hands their bytes to the web part. */
class ReportFinder(private val activity: Activity, private val webView: WebView) {

    @Volatile private var scanId = 0
    private val lock = Any()
    private val maxDepth = 14
    private val maxBytes = 12L * 1024 * 1024

    fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else if (Build.VERSION.SDK_INT >= 23)
            activity.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else true

    fun openAccessSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + activity.packageName)))
            } else if (Build.VERSION.SDK_INT >= 23) {
                activity.requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 4711)
            }
        } catch (e: Exception) {
            try { activity.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {}
        }
    }

    fun cancelScan() { synchronized(lock) { scanId++ } }

    /** scope = "whatsapp" or "storage". Result goes to window.__epiPdfScanResult(json). */
    fun startScan(scope: String) {
        val id = synchronized(lock) { ++scanId }
        Thread {
            val out = JSONArray()
            try {
                val seen = HashSet<String>()
                for (root in rootsFor(scope)) walk(root, 0, id, scope == "storage", out, seen)
            } catch (_: Throwable) { }
            if (id == scanId) deliver(out)
        }.start()
    }

    private fun rootsFor(scope: String): List<File> {
        val ext = Environment.getExternalStorageDirectory()
        if (scope == "whatsapp") {
            return listOf(
                "Android/media/com.whatsapp",
                "Android/media/com.whatsapp.w4b",
                "WhatsApp",
                "WhatsApp Business"
            ).map { File(ext, it) }.filter { it.exists() }
        }
        val roots = ArrayList<File>()
        roots.add(ext)
        try {
            File("/storage").listFiles()?.forEach {
                if (it.isDirectory && it.name != "emulated" && it.name != "self" && it.canRead()) roots.add(it)
            }
        } catch (_: Throwable) { }
        return roots
    }

    private fun skipDir(d: File): Boolean {
        val p = d.absolutePath
        if (p.contains("/Android/data/") && !p.contains("org.seir.android.norad")) return true  // other apps' private data
        if (p.contains("/Android/obb")) return true
        return false
    }

    private fun walk(dir: File, depth: Int, id: Int, whole: Boolean, out: JSONArray, seen: HashSet<String>) {
        if (id != scanId || depth > maxDepth) return
        val kids: Array<File>? = try { dir.listFiles() } catch (_: Throwable) { null }
        if (kids == null) return
        for (f in kids) {
            if (id != scanId) return
            val n = f.name
            if (f.isDirectory) {
                if (n.startsWith(".")) continue
                if (whole && skipDir(f)) continue
                walk(f, depth + 1, id, whole, out, seen)
            } else if (n.endsWith(".pdf", ignoreCase = true)) {
                val len = f.length()
                if (len < 1500 || len > maxBytes) continue
                val key = try { f.canonicalPath } catch (_: Exception) { f.absolutePath }
                if (!seen.add(key)) continue
                out.put(JSONObject().put("path", f.absolutePath).put("name", n)
                    .put("size", len).put("modified", f.lastModified()))
            }
        }
    }

    private fun deliver(arr: JSONArray) {
        val js = "window.__epiPdfScanResult && window.__epiPdfScanResult(" + JSONObject.quote(arr.toString()) + ");"
        activity.runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    /** Returns up to 1 MB of the file from [offset] as base64 ("" on any problem). Only .pdf files on shared storage. */
    fun readChunk(path: String, offset: Long, length: Int): String {
        return try {
            val f = File(path)
            val canon = f.canonicalPath
            if (!canon.endsWith(".pdf", ignoreCase = true)) return ""
            val ext = Environment.getExternalStorageDirectory().canonicalPath
            if (!(canon.startsWith(ext) || canon.startsWith("/storage/"))) return ""
            RandomAccessFile(f, "r").use { raf ->
                raf.seek(offset)
                val buf = ByteArray(minOf(maxOf(length, 0), 1024 * 1024))
                val got = raf.read(buf)
                if (got <= 0) "" else Base64.encodeToString(buf, 0, got, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { "" }
    }
}
