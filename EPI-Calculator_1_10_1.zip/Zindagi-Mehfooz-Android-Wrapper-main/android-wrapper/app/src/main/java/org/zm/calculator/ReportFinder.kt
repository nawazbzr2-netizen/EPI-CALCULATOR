// NEW FILE: app/src/main/java/<your package>/ReportFinder.kt
// Change the package line to the same package as MainActivity.kt (e.g. org.zm.calculator).
package org.zm.calculator

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.util.Base64
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile

/** Lists PDFs (WhatsApp + WhatsApp Business, or the whole phone) and hands their bytes to the web part. */
class ReportFinder(private val activity: Activity, private val webView: WebView) {

    @Volatile private var scanId = 0
    private val lock = Any()
    private val maxDepth = 14
    private val maxBytes = 12L * 1024 * 1024
    private val seirPkg = "org.seir.android.norad"
    private fun prefs() = activity.getSharedPreferences("epi_picker", android.content.Context.MODE_PRIVATE)
    private fun savedSeirTree(): Uri? = prefs().getString("tree_seir", null)?.let { Uri.parse(it) }

    fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else if (Build.VERSION.SDK_INT >= 23)
            activity.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        else true

    fun openAccessSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + activity.packageName)))
            } else if (Build.VERSION.SDK_INT >= 23) {
                activity.requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 4711)
            }
        } catch (e: Exception) {
            try { activity.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {}
        }
    }

    fun cancelScan() { synchronized(lock) { scanId++ } }

    /**
     * scope = "seir" | "whatsapp" | "storage".
     * Result goes to window.__epiPdfScanResult({status, sdk, items:[...]}).
     * status: "ok" | "need_tree" (SEIR folder permission must be granted once).
     */
    fun startScan(scope: String) {
        val id = synchronized(lock) { ++scanId }
        Thread {
            val out = JSONArray()
            var status = "ok"
            try {
                if (scope == "seir") {
                    status = scanSeir(id, out)
                } else {
                    val seen = HashSet<String>()
                    for (root in rootsFor(scope)) walk(root, 0, id, scope == "storage", out, seen)
                }
            } catch (_: Throwable) { }
            if (id == scanId) deliver(out, status)
        }.start()
    }

    /** SEIR's own folder: Android/data/org.seir.android.norad/files (everything inside, any sub-folder). */
    private fun scanSeir(id: Int, out: JSONArray): String {
        val dir = File(Environment.getExternalStorageDirectory(), "Android/data/$seirPkg/files")
        val kids: Array<File>? = try { dir.listFiles() } catch (_: Throwable) { null }
        // Android 11+ often answers "empty" for other apps' folders; that answer can't be trusted.
        if (kids != null && !(kids.isEmpty() && Build.VERSION.SDK_INT >= 30)) {
            walk(dir, 0, id, false, out, HashSet())
            return "ok"
        }
        val tree = savedSeirTree() ?: return "need_tree"
        val ok = try {
            walkTree(tree, DocumentsContract.getTreeDocumentId(tree), 0, id, out, HashSet())
        } catch (_: Throwable) { false }
        if (!ok) { prefs().edit().remove("tree_seir").apply(); return "need_tree" }
        return "ok"
    }

    /** Walks a folder that was granted through the system folder picker. false = no access. */
    private fun walkTree(tree: Uri, docId: String, depth: Int, id: Int, out: JSONArray, seen: HashSet<String>): Boolean {
        if (id != scanId || depth > 8) return true
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cursor = activity.contentResolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            ), null, null, null
        ) ?: return false
        val subDirs = ArrayList<String>()
        cursor.use { c ->
            while (c.moveToNext()) {
                val childId = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    if (!name.startsWith(".")) subDirs.add(childId)
                } else if (name.endsWith(".pdf", ignoreCase = true)) {
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (size < 1500 || size > maxBytes) continue
                    if (!seen.add(childId)) continue
                    val modified = if (c.isNull(4)) 0L else c.getLong(4)
                    out.put(JSONObject()
                        .put("path", DocumentsContract.buildDocumentUriUsingTree(tree, childId).toString())
                        .put("name", name).put("size", size).put("modified", modified))
                }
            }
        }
        for (d in subDirs) walkTree(tree, d, depth + 1, id, out, seen)
        return true
    }

    private fun rootsFor(scope: String): List<File> {
        val ext = Environment.getExternalStorageDirectory()
        if (scope == "whatsapp") {
            return listOf(
                "Android/media/com.whatsapp",
                "Android/media/com.whatsapp.w4b",
                "WhatsApp",
                "WhatsApp Business"
            ).map { File(ext, it) }.filter { it.exists() }
        }
        val roots = ArrayList<File>()
        roots.add(ext)
        try {
            File("/storage").listFiles()?.forEach {
                if (it.isDirectory && it.name != "emulated" && it.name != "self" && it.canRead()) roots.add(it)
            }
        } catch (_: Throwable) { }
        return roots
    }

    private fun skipDir(d: File): Boolean {
        val p = d.absolutePath
        if (p.contains("/Android/data/") && !p.contains("org.seir.android.norad")) return true  // other apps' private data
        if (p.contains("/Android/obb")) return true
        return false
    }

    private fun walk(dir: File, depth: Int, id: Int, whole: Boolean, out: JSONArray, seen: HashSet<String>) {
        if (id != scanId || depth > maxDepth) return
        val kids: Array<File>? = try { dir.listFiles() } catch (_: Throwable) { null }
        if (kids == null) return
        for (f in kids) {
            if (id != scanId) return
            val n = f.name
            if (f.isDirectory) {
                if (n.startsWith(".")) continue
                if (whole && skipDir(f)) continue
                walk(f, depth + 1, id, whole, out, seen)
            } else if (n.endsWith(".pdf", ignoreCase = true)) {
                val len = f.length()
                if (len < 1500 || len > maxBytes) continue
                val key = try { f.canonicalPath } catch (_: Exception) { f.absolutePath }
                if (!seen.add(key)) continue
                out.put(JSONObject().put("path", f.absolutePath).put("name", n)
                    .put("size", len).put("modified", f.lastModified()))
            }
        }
    }

    private fun deliver(arr: JSONArray, status: String) {
        val obj = JSONObject().put("status", status).put("sdk", Build.VERSION.SDK_INT).put("items", arr)
        val js = "window.__epiPdfScanResult && window.__epiPdfScanResult(" + JSONObject.quote(obj.toString()) + ");"
        activity.runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    /** Returns up to 1 MB of the file from [offset] as base64 ("" on any problem). Only .pdf files on shared storage. */
    fun readChunk(path: String, offset: Long, length: Int): String {
        if (path.startsWith("content://")) return readTreeChunk(path, offset, length)
        return try {
            val f = File(path)
            val canon = f.canonicalPath
            if (!canon.endsWith(".pdf", ignoreCase = true)) return ""
            val ext = Environment.getExternalStorageDirectory().canonicalPath
            if (!(canon.startsWith(ext) || canon.startsWith("/storage/"))) return ""
            RandomAccessFile(f, "r").use { raf ->
                raf.seek(offset)
                val buf = ByteArray(minOf(maxOf(length, 0), 1024 * 1024))
                val got = raf.read(buf)
                if (got <= 0) "" else Base64.encodeToString(buf, 0, got, Base64.NO_WRAP)
            }
        } catch (_: Throwable) { "" }
    }

    /** Reads a PDF inside the SEIR folder that was granted through the folder picker. */
    private fun readTreeChunk(path: String, offset: Long, length: Int): String {
        return try {
            val saved = savedSeirTree() ?: return ""
            val uri = Uri.parse(path)
            // only files inside the folder the person granted
            if (DocumentsContract.getTreeDocumentId(uri) != DocumentsContract.getTreeDocumentId(saved)) return ""
            activity.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).use { fis ->
                    fis.channel.position(offset)
                    val buf = ByteArray(minOf(maxOf(length, 0), 1024 * 1024))
                    val got = fis.read(buf)
                    if (got <= 0) "" else Base64.encodeToString(buf, 0, got, Base64.NO_WRAP)
                }
            } ?: ""
        } catch (_: Throwable) { "" }
    }
}
