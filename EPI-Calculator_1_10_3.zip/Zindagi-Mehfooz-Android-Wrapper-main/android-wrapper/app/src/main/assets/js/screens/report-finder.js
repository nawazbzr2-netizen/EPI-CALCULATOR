// Report Finder (v1.10.0)
// "From WhatsApp" and "Storage" buttons: the Android side lists every PDF it can see
// (WhatsApp + WhatsApp Business, or the whole phone). This file opens each PDF, decides
// from its CONTENT (not its name) whether it is a Daily Immunization Report or a Children
// Defaulters Report, shows the finds with tick boxes, and adds only what the user ticks.
(function () {
  'use strict';

  var MAX_FILE = 12 * 1024 * 1024;     // bigger PDFs are never one of these reports
  var CHUNK = 512 * 1024;              // bytes per bridge call
  var CACHE_KEY = 'epi_finder_cache_v1';

  function bridge() { return window.AndroidEpi; }
  function available() {
    var a = bridge();
    return !!(a && typeof a.startPdfScan === 'function' && typeof a.readFileBase64 === 'function');
  }
  window.hasReportFinder = available;

  // ---------- small helpers ----------
  function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }
  function esc(s) { return (typeof escapeHtml === 'function') ? escapeHtml(String(s)) : String(s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }
  function fmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function fmtDate(ms) { try { return new Date(ms).toLocaleDateString('en-GB'); } catch (e) { return ''; } }
  function placeOf(path) {
    var p = String(path).toLowerCase();
    if (p.indexOf('com.whatsapp.w4b') >= 0 || p.indexOf('whatsapp business') >= 0) return 'WhatsApp Business';
    if (p.indexOf('whatsapp') >= 0) return 'WhatsApp';
    if (p.indexOf('org.seir.android.norad') >= 0) return 'SEIR';
    if (p.indexOf('/download') >= 0) return 'Download';
    var parts = String(path).split('/'); parts.pop();
    return parts.length ? parts[parts.length - 1] : '';
  }
  function loadCache() { try { return JSON.parse(localStorage.getItem(CACHE_KEY) || '{}') || {}; } catch (e) { return {}; } }
  function saveCache(c) {
    try {
      var keys = Object.keys(c);
      if (keys.length > 4000) { keys.slice(0, keys.length - 3000).forEach(function (k) { delete c[k]; }); }
      localStorage.setItem(CACHE_KEY, JSON.stringify(c));
    } catch (e) {}
  }
  function fnv(bytes) {
    var h = 0x811c9dc5;
    for (var i = 0; i < bytes.length; i++) { h ^= bytes[i]; h = Math.imul(h, 16777619) >>> 0; }
    return h.toString(16) + '-' + bytes.length;
  }

  // ---------- native bridge ----------
  function scanNative(scope, state) {
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () { window.__epiPdfScanResult = null; reject(new Error('Scan took too long')); }, 240000);
      state.abortScan = function () { clearTimeout(timer); window.__epiPdfScanResult = null; try { if (bridge().cancelPdfScan) bridge().cancelPdfScan(); } catch (e) {} reject(new Error('cancelled')); };
      window.__epiPdfScanResult = function (json) {
        clearTimeout(timer); window.__epiPdfScanResult = null;
        try { var o = JSON.parse(json) || {}; resolve(Array.isArray(o) ? { status: 'ok', items: o } : o); } catch (e) { reject(e); }
      };
      try { bridge().startPdfScan(scope); } catch (e) { clearTimeout(timer); reject(e); }
    });
  }
  async function readFile(path, size) {
    var out = new Uint8Array(size), off = 0;
    while (off < size) {
      var b64 = bridge().readFileBase64(path, off, CHUNK);
      if (!b64) throw new Error('read failed');
      var bin = atob(b64);
      if (off + bin.length > size) throw new Error('size changed');
      for (var i = 0; i < bin.length; i++) out[off + i] = bin.charCodeAt(i);
      off += bin.length;
      await tick();
    }
    return out;
  }

  // Asks the phone (once) for access to SEIR's own folder; resolves true/false.
  function requestTree() {
    return new Promise(function (resolve) {
      var timer = setTimeout(function () { window.__epiTreeGranted = null; resolve(false); }, 180000);
      window.__epiTreeGranted = function (ok) { clearTimeout(timer); window.__epiTreeGranted = null; resolve(!!ok); };
      try { bridge().requestSeirTree(); } catch (e) { clearTimeout(timer); window.__epiTreeGranted = null; resolve(false); }
    });
  }

  // Looks inside the PDF with the app's own report readers.
  async function classify(bytes) {
    var text = bytesToLatin1(bytes);
    if (text.slice(0, 5) !== '%PDF-') return 'none';
    var pages = await Promise.race([
      getAllPageTextRuns(bytes, text),
      new Promise(function (_, rej) { setTimeout(function () { rej(new Error('timeout')); }, 30000); })
    ]);
    if (pages.some(isValidDailyRegistryRuns)) return 'daily';
    if (pages.some(isValidDefaulterRuns)) return 'defaulters';
    return 'none';
  }

  // ---------- dialog ----------
  function openBox() {
    var back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = '<div class="modal-box" role="dialog" aria-modal="true" style="max-height:88vh;display:flex;flex-direction:column;"></div>';
    document.body.appendChild(back);
    var box = back.firstChild;
    var api = { box: box, onClose: null, closed: false };
    api.close = function () {
      if (api.closed) return; api.closed = true;
      back.remove();
      var i = openModalStack.indexOf(api.cancel); if (i !== -1) openModalStack.splice(i, 1);
      if (api.onClose) api.onClose();
    };
    api.cancel = function () { api.close(); };
    openModalStack.push(api.cancel);
    return api;
  }

  function showProgress(ui, title, line, onCancel) {
    ui.box.innerHTML = '<div class="modal-msg" style="font-weight:700;">' + esc(title) + '</div>' +
      '<div style="margin:10px 0;font-size:.9rem;word-break:break-all;"><span class="spinner"></span> ' + esc(line) + '</div>' +
      '<div class="modal-actions"><button type="button" class="go secondary" data-x="cancel">Cancel</button></div>';
    ui.box.querySelector('[data-x="cancel"]').onclick = onCancel;
  }

  function showResults(ui, scopeLabel, found, onAdd) {
    var daily = found.filter(function (f) { return f.type === 'daily'; });
    var defs = found.filter(function (f) { return f.type === 'defaulters'; });
    function rows(list) {
      return list.map(function (f) {
        var i = found.indexOf(f);
        return '<label style="display:flex;gap:8px;align-items:flex-start;padding:7px 4px;border-bottom:1px solid var(--border);">' +
          '<input type="checkbox" data-i="' + i + '"' + (f.pre && !f.saved ? ' checked' : '') + ' style="margin-top:3px;">' +
          '<span style="min-width:0;flex:1;"><span style="display:block;font-size:.88rem;word-break:break-all;">' + esc(f.name) + '</span>' +
          '<span style="display:block;font-size:.74rem;color:var(--muted);">' + esc(f.place) + ' · ' + esc(fmtDate(f.modified)) + ' · ' + esc(fmtSize(f.size)) +
          (f.saved ? ' · <b>already added before</b>' : '') + '</span></span></label>';
      }).join('');
    }
    var html = '<div class="modal-msg" style="font-weight:700;">' + esc(scopeLabel) + ': ' + found.length + ' report(s) found</div>' +
      '<div style="overflow:auto;flex:1;margin:8px 0;min-height:60px;">';
    if (daily.length) html += '<div style="font-weight:700;font-size:.82rem;margin:6px 0 2px;">📋 Daily Immunization Reports (' + daily.length + ')</div>' + rows(daily);
    if (defs.length) html += '<div style="font-weight:700;font-size:.82rem;margin:10px 0 2px;">⚠ Children Defaulters Reports (' + defs.length + ')</div>' + rows(defs);
    html += '</div><div class="modal-actions" style="flex-direction:column;gap:8px;">' +
      '<div style="display:flex;gap:8px;"><button type="button" class="go secondary" data-x="all">Select All</button><button type="button" class="go secondary" data-x="none">Clear</button></div>' +
      '<button type="button" class="go" data-x="add">Add Selected</button>' +
      '<button type="button" class="go secondary" data-x="cancel" style="background:transparent;border:none;color:var(--muted);margin-top:0;">Cancel</button></div>';
    ui.box.innerHTML = html;
    var boxes = function () { return Array.prototype.slice.call(ui.box.querySelectorAll('input[type=checkbox]')); };
    var addBtn = ui.box.querySelector('[data-x="add"]');
    function refresh() { var n = boxes().filter(function (b) { return b.checked; }).length; addBtn.textContent = 'Add Selected (' + n + ')'; addBtn.disabled = !n; }
    ui.box.addEventListener('change', refresh);
    ui.box.querySelector('[data-x="all"]').onclick = function () { boxes().forEach(function (b) { b.checked = true; }); refresh(); };
    ui.box.querySelector('[data-x="none"]').onclick = function () { boxes().forEach(function (b) { b.checked = false; }); refresh(); };
    ui.box.querySelector('[data-x="cancel"]').onclick = function () { ui.close(); };
    addBtn.onclick = function () {
      var chosen = boxes().filter(function (b) { return b.checked; }).map(function (b) { return found[+b.getAttribute('data-i')]; });
      ui.close();
      onAdd(chosen);
    };
    refresh();
  }

  // ---------- adding to the app ----------
  async function addChosen(chosen) {
    if (!chosen.length) return;
    if (typeof window.__epiBusy === 'function') window.__epiBusy(true, 'Adding reports…');
    var dailyFiles = [], defFiles = [];
    try {
      for (var k = 0; k < chosen.length; k++) {
        var it = chosen[k];
        var bytes = await readFile(it.path, it.size);
        var file = new File([bytes], it.addName, { type: 'application/pdf', lastModified: it.modified });
        (it.type === 'daily' ? dailyFiles : defFiles).push(file);
      }
    } catch (e) {
      try { if (typeof window.__epiBusy === 'function') window.__epiBusy(false); } catch (e2) {}
      if (typeof alertDialog === 'function') await alertDialog('A file could not be read: ' + (e && e.message || e));
      return;
    }
    try { if (typeof window.__epiBusy === 'function') window.__epiBusy(false); } catch (e) {}
    var beforeD = selectedFiles.length, beforeF = selectedDefaulterFiles.length;
    window.__epiSuppressAuto = true;
    try {
      if (dailyFiles.length) { window.__epiAutoPick = true; await addFiles(dailyFiles); }
      if (defFiles.length) { window.__epiAutoPick = true; await addDefaulterFiles(defFiles); }
    } finally { window.__epiSuppressAuto = false; window.__epiAutoPick = false; }
    if (selectedFiles.length === beforeD && selectedDefaulterFiles.length === beforeF) {
      if (typeof alertDialog === 'function') await alertDialog('These reports were already added earlier, so nothing new was added.');
      return;
    }
    await autoProcessAndOpenResults();
  }

  // ---------- main entry ----------
  // scope: 'whatsapp' | 'storage'
  // kind: 'daily' | 'defaulters' = the Insert button that was pressed (its reports are ticked first).
  // From the SEIR button both kinds are ticked.
  window.findReportsOnPhone = async function (scope, kind, retried) {
    var a = bridge();
    var label = scope === 'whatsapp' ? 'WhatsApp / WhatsApp Business' : scope === 'seir' ? 'SEIR app folder' : 'Phone storage';

    if (scope !== 'seir' && typeof a.hasFileAccess === 'function' && !a.hasFileAccess()) {
      var go = await confirmDialog('To look for reports in ' + label + ', the app needs "All files access". Open the permission screen now? After allowing it, come back and press the button again.', 'Open settings');
      if (go && typeof a.openFileAccessSettings === 'function') a.openFileAccessSettings();
      return;
    }

    var state = { cancelled: false, abortScan: null };
    var ui = openBox();
    ui.onClose = function () { state.cancelled = true; if (state.abortScan) state.abortScan(); };
    showProgress(ui, label, 'Looking for PDF files…', function () { ui.close(); });

    var list, res;
    try { res = await scanNative(scope, state); list = res.items || []; }
    catch (e) {
      if (!ui.closed) { ui.close(); if (!state.cancelled && typeof alertDialog === 'function') await alertDialog('Could not search the phone: ' + (e && e.message || e)); }
      return;
    }
    state.abortScan = null;

    // SEIR's folder is private to the SEIR app: Android lets us in only after the person allows it once.
    if (res.status === 'need_tree') {
      ui.close();
      var granted = false;
      if (!retried && typeof a.requestSeirTree === 'function') {
        var go2 = await confirmDialog('SEIR کی رپورٹیں پڑھنے کے لیے فولڈر کی اجازت ایک بار دیں۔ اگلی اسکرین پر Android ← data کھولیں (یا SEIR کا فولڈر) اور نیچے "Use this folder" پھر "Allow" دبائیں۔', 'Continue');
        if (!go2) return;
        granted = await requestTree();
        if (granted) return window.findReportsOnPhone(scope, kind, true);
      }
      // Android did not give the folder: let the person pick the reports with their own file manager (e.g. Cx)
      var viaFm = await confirmDialog('فون نے SEIR فولڈر کی اجازت نہیں دی (Android ' + (res.sdk || '?') + ')۔ اپنے فائل مینیجر (مثلاً Cx) سے رپورٹیں چنیں؟', 'File manager');
      if (viaFm) return 'legacy';
      var fb = await confirmDialog('پورے فون میں رپورٹیں تلاش کر لیں؟', 'Search phone');
      if (fb) return window.findReportsOnPhone('storage', kind);
      return;
    }

    list = list.filter(function (f) { return f && f.path && f.size > 0 && f.size <= MAX_FILE; })
               .sort(function (x, y) { return (y.modified || 0) - (x.modified || 0); });

    var cache = loadCache(), found = [], seenHash = {};
    var saved = {}, savedDef = {};
    try { saved = deriveFileList(loadStore()) || {}; } catch (e) {}
    try { savedDef = deriveDefaulterFileList(loadDefaultersStore()) || {}; } catch (e) {}

    for (var i = 0; i < list.length; i++) {
      if (state.cancelled) return;
      var f = list[i];
      if (i % 3 === 0) showProgress(ui, label, 'Checking ' + (i + 1) + ' / ' + list.length + ': ' + f.name, function () { ui.close(); });
      var key = f.path + '|' + f.size + '|' + f.modified;
      var c = cache[key];
      try {
        if (!c) {
          var bytes = await readFile(f.path, f.size);
          c = { t: await classify(bytes), h: fnv(bytes) };
          cache[key] = c;
        }
      } catch (e) { continue; }       // unreadable / not a normal PDF: skip quietly
      if (c.t === 'none') continue;
      if (seenHash[c.h]) continue;    // same file received twice (e.g. "name (1).pdf")
      seenHash[c.h] = 1;
      var addName = c.t === 'daily' ? f.name.replace(/defaulters?/ig, 'Report') : f.name;
      var isSaved = c.t === 'daily'
        ? !!saved[sourceKey(addName, f.size)]
        : !!savedDef[sourceKey(addName, f.size)];
      found.push({ path: f.path, name: f.name, addName: addName, size: f.size, modified: f.modified, type: c.t, place: scope === 'seir' ? 'SEIR' : placeOf(f.path), saved: isSaved, pre: scope === 'seir' || !kind || c.t === kind });
      await tick();
    }
    saveCache(cache);
    if (state.cancelled) return;

    if (!found.length) {
      ui.close();
      if (typeof alertDialog === 'function') await alertDialog('No Daily Immunization Report or Children Defaulters Report was found in ' + label + '.');
      return;
    }
    showResults(ui, label, found, addChosen);
  };
})();
