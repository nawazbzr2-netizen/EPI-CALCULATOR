// ============================================================
// analytics.js
// Sends a lightweight, best-effort login entry (Name, Center,
// District, Tehsil, UC, time) to Formspree, whenever the device
// has internet. This NEVER blocks or breaks the app — the app stays
// fully usable offline. A failed/skipped send stays queued and is
// retried the next time the app opens with a connection.
//
// ONE-TIME SETUP (3 steps, no coding needed):
//   1. Go to https://formspree.io  →  sign in with your Gmail.
//   2. Click "New Form", give it any name (e.g. "EPI Login Log"),
//      then click "Create Form".
//   3. Copy the Endpoint shown (looks like:
//        https://formspree.io/f/xyzabcde )
//      and paste it below as ENDPOINT_URL.
//
// After that: every login goes to your Gmail inbox AND is visible in
// the Formspree dashboard. No extra setup, no Apps Script, no server.
// ============================================================

const EPI_ANALYTICS_CONFIG = {
  // PASTE your Formspree endpoint here, e.g.:
  // "https://formspree.io/f/xyzabcde"
  ENDPOINT_URL: 'https://formspree.io/f/moevwbge',
  QUEUE_KEY: 'epi_analytics_queue'
};

function epiAnalyticsReadQueue(){
  try { return JSON.parse(localStorage.getItem(EPI_ANALYTICS_CONFIG.QUEUE_KEY) || '[]'); }
  catch (e) { return []; }
}

function epiAnalyticsWriteQueue(q){
  try { localStorage.setItem(EPI_ANALYTICS_CONFIG.QUEUE_KEY, JSON.stringify(q)); } catch (e) { /* ignore */ }
}

function epiAnalyticsSendOne(entry){
  if (!EPI_ANALYTICS_CONFIG.ENDPOINT_URL) return Promise.resolve(false);
  return fetch(EPI_ANALYTICS_CONFIG.ENDPOINT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify(entry)
  }).then(function(r){ return r.ok; }).catch(function(){ return false; });
}

function epiAnalyticsLogLogin(info){
  var entry = {
    Center: info.center || '',
    District: info.district || '',
    Tehsil: info.tehsil || '',
    UC: info.uc || '',
    Latitude: info.latitude != null ? String(info.latitude) : '',
    Longitude: info.longitude != null ? String(info.longitude) : '',
    Accuracy_m: info.accuracy != null ? String(Math.round(info.accuracy)) : '',
    Event: info.suggestion || 'Login',
    Time: new Date().toLocaleString()
  };
  var q = epiAnalyticsReadQueue();
  q.push(entry);
  epiAnalyticsWriteQueue(q);
  epiAnalyticsFlushQueue();
}

function epiAnalyticsFlushQueue(){
  if (!EPI_ANALYTICS_CONFIG.ENDPOINT_URL) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  var remaining = epiAnalyticsReadQueue();
  if (!remaining.length) return;
  function sendNext(){
    if (!remaining.length){ epiAnalyticsWriteQueue([]); return; }
    var entry = remaining[0];
    epiAnalyticsSendOne(entry).then(function(ok){
      if (ok){
        remaining = remaining.slice(1);
        epiAnalyticsWriteQueue(remaining);
        sendNext();
      }
    });
  }
  sendNext();
}

window.epiAnalyticsLogLogin = epiAnalyticsLogLogin;
window.epiAnalyticsFlushQueue = epiAnalyticsFlushQueue;
