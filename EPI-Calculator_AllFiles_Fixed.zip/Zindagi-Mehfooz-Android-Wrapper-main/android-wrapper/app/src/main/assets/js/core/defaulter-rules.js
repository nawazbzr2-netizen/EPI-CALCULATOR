// ============================================================
// defaulter-rules.js — how Children Defaulters are counted, covered and kept up to date.
//
//  1. One QR code = one defaulter child. The vaccines listed for him stay exactly as
//     the report wrote them (shown in EPI schedule order).
//  2. Coverage:  - the LAST vaccine of his list given (or his only one) -> covered;
//                - only an earlier one given        -> still a defaulter, for the
//                  vaccine(s) that were not given.
//  3. A newer Children Defaulters Report REPLACES the data of a child already saved
//     (same QR code). Older reports never overwrite newer ones. Deleting a report
//     brings back the data from the reports that are left.
//  4. Auto update: when no newer report is loaded, children who were covered become
//     defaulters again for the NEXT dose of the EPI schedule once its due date has
//     passed (worked out from the cover date / date of birth). Nothing is saved for
//     this; it is recalculated every time a defaulters screen opens.
// ============================================================

const DEF_EPI_ORDER = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2','TT1','TT2','TT3','TT4','TT5'];

function defSortTags(tags){
  const uniq = Array.from(new Set(tags || []));
  return uniq.sort((a, b) => {
    const ia = DEF_EPI_ORDER.indexOf(a), ib = DEF_EPI_ORDER.indexOf(b);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });
}

// ---------- small date helpers (dates are {day, month, year}) ----------
function defDateMs(d){ return d ? Date.UTC(d.year, d.month - 1, d.day, 12) : null; }
function defMsToDate(ms){ const x = new Date(ms); return { day: x.getUTCDate(), month: x.getUTCMonth() + 1, year: x.getUTCFullYear() }; }
function defAddDays(d, n){ return defMsToDate(defDateMs(d) + n * 86400000); }
function defAddMonths(d, n){
  const x = new Date(Date.UTC(d.year, d.month - 1 + n, 1, 12));
  const last = new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth() + 1, 0, 12)).getUTCDate();
  return { day: Math.min(d.day, last), month: x.getUTCMonth() + 1, year: x.getUTCFullYear() };
}
function defTodayMs(){ const n = new Date(); return Date.UTC(n.getFullYear(), n.getMonth(), n.getDate(), 12); }

// "DD/MM/YYYY-DD/MM/YYYY" (report period) -> the END of the period in ms, or null
function defReportEndMs(rangeText){
  if (!rangeText) return null;
  const parts = String(rangeText).split('-');
  const last = parts[parts.length - 1];
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(last.trim());
  return m ? defDateMs({ day: +m[1], month: +m[2], year: +m[3] }) : null;
}

// ---------- 3. newer report replaces older data (same QR code) ----------
// A record keeps `versions`: one entry per report it appeared in. The record you see
// is built from the NEWEST report (by report period; if unknown, the latest loaded).
function defStripVersionData(rec){
  const c = Object.assign({}, rec);
  delete c.versions; delete c.sources;
  return c;
}

function defRebuildFromVersions(versions){
  let bestIdx = 0;
  versions.forEach((v, i) => {
    const a = v.reportEnd == null ? -1 : v.reportEnd;
    const b = versions[bestIdx].reportEnd == null ? -1 : versions[bestIdx].reportEnd;
    if (a >= b) bestIdx = i;          // newer (or equal / unknown -> the one loaded later) wins
  });
  const best = versions[bestIdx];
  const rec = Object.assign({}, best.data);
  rec.defaultedVaccines = defSortTags(best.data.defaultedVaccines);
  // details that only an older report had are kept (gender, EPI No, phone ...)
  for (let i = versions.length - 1; i >= 0; i--) {
    const d = versions[i].data;
    ['gender', 'epiNo', 'phone', 'fatherName', 'dob', 'enrollmentCenter', 'enrollmentVaccinator'].forEach(k => {
      if (rec[k] == null || rec[k] === '') { if (d[k] != null && d[k] !== '') rec[k] = d[k]; }
    });
  }
  const sources = [];
  versions.forEach(v => (v.srcs || []).forEach(s => {
    if (!sources.some(x => sourceEntryMatches(x, sourceEntryName(s), sourceEntrySize(s)))) sources.push(s);
  }));
  rec.sources = sources;
  rec.versions = versions;
  rec.reportEnd = best.reportEnd == null ? null : best.reportEnd;
  return rec;
}

// existing = the record saved so far for this QR code (or null); incoming = the child as read
// from the newly loaded report (incoming.sources = [that report file]).
function applyDefaulterReport(existing, incoming, reportEndMs){
  let versions = [];
  if (existing) {
    versions = (existing.versions && existing.versions.length)
      ? existing.versions.slice()
      : [{ srcs: (existing.sources || []).slice(), reportEnd: existing.reportEnd == null ? null : existing.reportEnd, data: defStripVersionData(existing) }];
  }
  const src = (incoming.sources || [])[0];
  // the same report loaded again just refreshes its own entry
  versions = versions.filter(v => !(v.srcs && v.srcs.length === 1 && src && sourceEntryMatches(v.srcs[0], sourceEntryName(src), sourceEntrySize(src))));
  versions.push({ srcs: src ? [src] : [], reportEnd: reportEndMs == null ? null : reportEndMs, data: defStripVersionData(incoming) });
  return defRebuildFromVersions(versions);
}

// Deleting a report file: its data goes; if older reports still list the child, THEIR
// data comes back; with nothing left the child is removed. Returns the record or null.
function removeReportFromDefaulter(rec, name, size){
  if (rec.versions && rec.versions.length) {
    const kept = [];
    rec.versions.forEach(v => {
      const srcs = (v.srcs || []).filter(s => !sourceEntryMatches(s, name, size));
      if (srcs.length) kept.push(Object.assign({}, v, { srcs }));
    });
    return kept.length ? defRebuildFromVersions(kept) : null;
  }
  const sources = (rec.sources || []).filter(s => !sourceEntryMatches(s, name, size));
  if (!sources.length) return null;
  return Object.assign({}, rec, { sources });
}

// ---------- 2. coverage ----------
// Tags a child's own record shows as given. A higher dose level also means the lower
// ones came first (Penta3 -> Penta1, Penta2 ...).
function defGivenTagsFromDoses(doses){
  const set = new Set(classifyEpi(doses || {}));
  if (set.has('Penta3')) { set.add('Penta2'); set.add('Penta1'); }
  if (set.has('Penta2')) set.add('Penta1');
  if (set.has('Measles2')) set.add('Measles1');
  return set;
}
function defGivenTagsFromTT(doses){
  const set = new Set(classifyTT(doses || {}));
  TT_ORDER.forEach((t, i) => { if (set.has(t)) for (let j = 0; j < i; j++) set.add(TT_ORDER[j]); });
  return set;
}
function defGivenTags(rec){
  if (!rec) return new Set();
  return isTtRecord(rec.doses || {}) ? defGivenTagsFromTT(rec.doses) : defGivenTagsFromDoses(rec.doses);
}

// -> { found, listed:[...in EPI order], givenTags:[...], remainingTags:[...], allCovered }
function defCoverageTags(def, store){
  const listed = defSortTags(def.defaultedVaccines);
  const rec = store[def.id];
  if (!rec || !listed.length) return { found: !!rec, listed, givenTags: [], remainingTags: listed.slice(), allCovered: false, rec };
  const given = defGivenTags(rec);
  const givenTags = listed.filter(t => given.has(t));
  const last = listed[listed.length - 1];
  const remainingTags = listed.filter(t => !given.has(t));
  // the LAST vaccine of the list given = covered, whatever came before
  const allCovered = given.has(last) || remainingTags.length === 0;
  return { found: true, listed, givenTags, remainingTags: allCovered ? [] : remainingTags, allCovered, rec };
}

// ---------- 4. auto update: the next EPI dose after a cover ----------
const DEF_MAX_AGE_MONTHS = 24;     // the EPI childhood schedule ends at 2 years

function defAgeMonthsAt(dob, ms){
  const d = defMsToDate(ms);
  let mo = (d.year - dob.year) * 12 + (d.month - dob.month);
  if (d.day < dob.day) mo -= 1;
  return mo;
}

function defVisitDateOfTag(rec, tag){
  // date of the earliest visit that gave this dose (or a higher level of the same series)
  const visits = (rec.visits && rec.visits.length) ? rec.visits : [{ vaccDate: rec.vaccDate, doses: rec.doses }];
  let best = null;
  visits.forEach(v => {
    if (!v.vaccDate || isTtRecord(v.doses || {})) return;
    if (defGivenTagsFromDoses(v.doses).has(tag)) {
      if (!best || compareDateObjs(v.vaccDate, best) < 0) best = v.vaccDate;
    }
  });
  return best || rec.vaccDate || null;
}

// Defaulters the EPI schedule creates for a child who was covered: the next Penta/OPV dose
// 28 days after the last one, Measles 1 at 9 months and Measles 2 at 15 months of age.
function defNextScheduleDefaults(def, rec, todayMs){
  if (!rec || !def.dob) return null;
  if (isTtRecord(rec.doses || {})) return null;           // women (TT) follow another schedule
  const dob = def.dob;
  const ageNow = defAgeMonthsAt(dob, todayMs);
  if (ageNow >= DEF_MAX_AGE_MONTHS) return null;
  const given = defGivenTags(rec);
  const tags = [];
  let due = null, from = null;
  function consider(tag, dueDate, fromDate){
    if (!dueDate) return;
    if (defDateMs(dueDate) < todayMs) {          // the due date has passed
      tags.push(tag);
      if (!due || defDateMs(dueDate) < defDateMs(due)) { due = dueDate; from = fromDate || null; }
    }
  }
  // Penta / OPV series: each dose 28 days after the previous one
  if (given.has('Penta3')) { /* series complete */ }
  else if (given.has('Penta2')) { if (ageNow < 12) consider('Penta3', defAddDays(defVisitDateOfTag(rec, 'Penta2'), 28), defVisitDateOfTag(rec, 'Penta2')); }
  else if (given.has('Penta1')) { if (ageNow < 12) consider('Penta2', defAddDays(defVisitDateOfTag(rec, 'Penta1'), 28), defVisitDateOfTag(rec, 'Penta1')); }
  else if (ageNow < 12) { consider('Penta1', defAddDays(dob, 42), null); }          // 6 weeks of age
  // Measles by age
  if (!given.has('Measles1')) consider('Measles1', defAddMonths(dob, 9), null);
  else if (!given.has('Measles2')) consider('Measles2', defAddMonths(dob, 15), defVisitDateOfTag(rec, 'Measles1'));
  if (!tags.length) return null;
  return { tags: defSortTags(tags), dueDate: due, coverDate: from };
}

// Defaulters made by the schedule for children that are covered. Not saved.
function deriveScheduleDefaulters(defStore, store){
  const out = [];
  const today = defTodayMs();
  Object.values(defStore || {}).forEach(def => {
    const cov = defCoverageTags(def, store);
    if (!cov.found || !cov.allCovered) return;
    const next = defNextScheduleDefaults(def, cov.rec, today);
    if (!next) return;
    const nd = Object.assign({}, def);
    nd.defaultedVaccines = next.tags;
    nd.dueDate = next.dueDate;
    nd.defaultedDate = defAddDays(next.dueDate, 1);
    nd.status = 'AUTO (EPI schedule)';
    nd.derived = true;
    nd.derivedFrom = next.coverDate;
    delete nd.versions;
    out.push(nd);
  });
  return out;
}
