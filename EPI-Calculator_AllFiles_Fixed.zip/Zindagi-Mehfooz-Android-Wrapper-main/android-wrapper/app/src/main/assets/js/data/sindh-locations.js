/* sindh-locations.js
   District → Tehsil → UC list. Each UC is either a string (legacy) or
   { name, centres: [...] }. App code normalizes to UC names; login page
   uses centres for the Centre dropdown.
*/
window.SINDH_LOCATIONS = {
  "Badin": {
    "Badin": [
      {
        "name": "Abdullah Shah (UC-46)",
        "centres": [
          "BHU Abdullah shah",
          "GD Gul Muhammad Jamali"
        ]
      },
      {
        "name": "Behdemi (UC-45)",
        "centres": [
          "Behdemi (UC-45)"
        ]
      },
      {
        "name": "Bhugra Memon (UC-51)",
        "centres": [
          "BHU Bedhmi",
          "GD Bhugra Memon"
        ]
      },
      {
        "name": "Chakar Panhwer (UC-49)",
        "centres": [
          "Chakar Panhwer (UC-49)"
        ]
      },
      {
        "name": "Dargah Yousif Shah Bukhari (UC-40)",
        "centres": [
          "Dargah Yousif Shah Bukhari (UC-40)"
        ]
      },
      {
        "name": "Dr. Abdullah Soomro (UC-41)",
        "centres": [
          "Dr. Abdullah Soomro (UC-41)"
        ]
      },
      {
        "name": "Kadi Kazia (UC-39)",
        "centres": [
          "BHU Ghulam Hussain Perhyar",
          "GD Allahabad"
        ]
      },
      {
        "name": "Luari Sharif (UC-44)",
        "centres": [
          "Fazal Muhammad Talpur"
        ]
      },
      {
        "name": "MC-1 Badin",
        "centres": [
          "BHU Yousif Shah"
        ]
      },
      {
        "name": "MC-2 Badin",
        "centres": [
          "BHU Yousif Shah"
        ]
      },
      {
        "name": "MC-3 Badin",
        "centres": [
          "BHU Yousif Shah"
        ]
      },
      {
        "name": "MC-4 Badin",
        "centres": [
          "BHU Yousif Shah"
        ]
      },
      {
        "name": "Mithi - III (UC-48)",
        "centres": [
          "Mithi - III (UC-48)"
        ]
      },
      {
        "name": "Mitho Khan Chandio (UC-47)",
        "centres": [
          "Mitho Khan Chandio (UC-47)"
        ]
      },
      {
        "name": "Muhammad Khan Bhurgari (UC-42)",
        "centres": [
          "GD Yousif Soomro"
        ]
      },
      {
        "name": "Nindo Shahar (UC-43)",
        "centres": [
          "RHC Nindo"
        ]
      },
      {
        "name": "Pir Fateh Shah (UC-53)",
        "centres": [
          "Pir Fateh Shah (UC-53)"
        ]
      },
      {
        "name": "Seerani (UC-52)",
        "centres": [
          "GD Seerani"
        ]
      },
      {
        "name": "Shaheed Dodo Soomro (UC-50)",
        "centres": [
          "Shaheed Dodo Soomro (UC-50)"
        ]
      },
      {
        "name": "Siyal (UC-54)",
        "centres": [
          "Siyal (UC-54)"
        ]
      },
      {
        "name": "TC-7 Kadhan",
        "centres": [
          "RHC Kadhan"
        ]
      },
      {
        "name": "TC-8 Nindo",
        "centres": [
          "RHC Nindo"
        ]
      }
    ],
    "Matli": [
      {
        "name": "Budho Qambrani (UC-11)",
        "centres": [
          "BHU Haji Nizamuddin",
          "BHU Sohradi",
          "GD Murtaza Arain"
        ]
      },
      {
        "name": "Chatto Mandhrani (UC-10)",
        "centres": [
          "Chatto Mandhrani (UC-10)"
        ]
      },
      {
        "name": "Dumbalo (UC-9)",
        "centres": [
          "BHU Haji Dodo Khan Gishkori",
          "BHU Haji Ramzan Chandio",
          "GD New Dumbalo"
        ]
      },
      {
        "name": "Ghazi Khan Chang (UC-7)",
        "centres": [
          "Ghazi Khan Chang (UC-7)"
        ]
      },
      {
        "name": "Ghulam Muhammad Halepoto (UC-1)",
        "centres": [
          "Ghulam Muhammad Halepoto (UC-1)"
        ]
      },
      {
        "name": "Ghulam Shah Laghari (UC-5)",
        "centres": [
          "GD Mohib Laghari"
        ]
      },
      {
        "name": "Haji Allah Dino Sirewal (UC-6)",
        "centres": [
          "Haji Allah Dino Sirewal (UC-6)"
        ]
      },
      {
        "name": "Haji Muhammad Hashim Panhwer (UC-2)",
        "centres": [
          "Haji Muhammad Hashim Panhwer (UC-2)"
        ]
      },
      {
        "name": "Haji Sawan (UC-15)",
        "centres": [
          "ED Ali Akbar Nizamani"
        ]
      },
      {
        "name": "Halepota (UC-8)",
        "centres": [
          "BHU Chodri Fateh Muhammad",
          "BHU Kapri Mori"
        ]
      },
      {
        "name": "Malhan (UC-16)",
        "centres": [
          "BHU Beero Lanjwani",
          "BHU Meer Muhammad Nizamani",
          "BHU Nabi Bux Punjabi"
        ]
      },
      {
        "name": "Manik Laghari (UC-3)",
        "centres": [
          "BHU Gulab Laghari",
          "GD Manik Laghari"
        ]
      },
      {
        "name": "MC-1 Matli",
        "centres": [
          "Kashmiri Hospital Matli-II"
        ]
      },
      {
        "name": "MC-2 Matli",
        "centres": [
          "Kashmiri Hospital Matli-II"
        ]
      },
      {
        "name": "MC-3 Matli",
        "centres": [
          "Kashmiri Hospital Matli-II"
        ]
      },
      {
        "name": "Nabi Bux Kamboh (UC-14)",
        "centres": [
          "Nabi Bux Kamboh (UC-14)"
        ]
      },
      {
        "name": "Phalkara (UC-4)",
        "centres": [
          "BHU Baaran Laghari",
          "BHU Phalkara",
          "GD Gaheno Laghari"
        ]
      },
      {
        "name": "TC-1 Tando Ghulam Ali",
        "centres": [
          "RHC Tando Ghulam Ali"
        ]
      },
      {
        "name": "Thari (UC-13)",
        "centres": [
          "GD Allahdad Bhurgri",
          "RHC Thaari"
        ]
      },
      {
        "name": "Tharo Kot (UC-12)",
        "centres": [
          "Tharo Kot (UC-12)"
        ]
      }
    ],
    "Shaheed Fazil Rahu": [
      {
        "name": "Dargah Ahmad Rajo (UC-62)",
        "centres": [
          "Dargah Ahmad Rajo (UC-62)"
        ]
      },
      {
        "name": "Dubi (UC-67)",
        "centres": [
          "Dubi (UC-67)"
        ]
      },
      {
        "name": "Fatehabad (UC-60)",
        "centres": [
          "Fatehabad (UC-60)"
        ]
      },
      {
        "name": "Gharo (UC-56)",
        "centres": [
          "Gharo (UC-56)"
        ]
      },
      {
        "name": "Jhol (UC-68)",
        "centres": [
          "Jhol (UC-68)"
        ]
      },
      {
        "name": "Kandiyari (UC-59)",
        "centres": [
          "Kandiyari (UC-59)"
        ]
      },
      {
        "name": "Kario Ganhwer (UC-55)",
        "centres": [
          "Kario Ganhwer (UC-55)"
        ]
      },
      {
        "name": "Khorwah (UC-66)",
        "centres": [
          "Khorwah (UC-66)"
        ]
      },
      {
        "name": "Khorwah Chowk (UC-63)",
        "centres": [
          "Khorwah Chowk (UC-63)"
        ]
      },
      {
        "name": "Makhdoom Pur (UC-65)",
        "centres": [
          "Makhdoom Pur (UC-65)"
        ]
      },
      {
        "name": "Muhammad Shah Girhari (UC-61)",
        "centres": [
          "Muhammad Shah Girhari (UC-61)"
        ]
      },
      {
        "name": "Rahooki (UC-57)",
        "centres": [
          "Rahooki (UC-57)"
        ]
      },
      {
        "name": "Shaheed Fazil Rahu (UC-64)",
        "centres": [
          "Shaheed Fazil Rahu (UC-64)"
        ]
      },
      {
        "name": "Tarai (UC-58)",
        "centres": [
          "Tarai (UC-58)"
        ]
      },
      {
        "name": "TC-10 Kario Ghanwar",
        "centres": [
          "TC-10 Kario Ghanwar"
        ]
      },
      {
        "name": "TC-9 Shaheed Fazil Rahu",
        "centres": [
          "TC-9 Shaheed Fazil Rahu"
        ]
      }
    ],
    "Talhar": [
      {
        "name": "Haji Muhammad Ashraf Thebo (UC-22)",
        "centres": [
          "Haji Muhammad Ashraf Thebo (UC-22)"
        ]
      },
      {
        "name": "Mir Ahsan Talpur (UC-18)",
        "centres": [
          "Mir Ahsan Talpur (UC-18)"
        ]
      },
      {
        "name": "Mir Sahib Khan Talpur (UC-19)",
        "centres": [
          "Mir Sahib Khan Talpur (UC-19)"
        ]
      },
      {
        "name": "Peeru Lashari (UC-21)",
        "centres": [
          "BHU Rip",
          "DC Dispansery Ach Sharif"
        ]
      },
      {
        "name": "Pir Ali Bahadur Shah (UC-20)",
        "centres": [
          "Pir Ali Bahadur Shah (UC-20)"
        ]
      },
      {
        "name": "TC-2 Talhar",
        "centres": [
          "RHC Talhar"
        ]
      },
      {
        "name": "TC-3 Rajo Khanani",
        "centres": [
          "BHU Ghulam Muhammad Nizamani",
          "BHU Gulam Shah Mori",
          "GD Boro Sahib Khan",
          "RHC Rajo Khanani"
        ]
      },
      {
        "name": "Wasi Adil (UC-17)",
        "centres": [
          "Wasi Adil (UC-17)"
        ]
      }
    ],
    "Tando Bago": [
      {
        "name": "Adhoori (UC-37)",
        "centres": [
          "Adhoori (UC-37)"
        ]
      },
      {
        "name": "Bahadur Khan Chandio (UC-26)",
        "centres": [
          "Bahadur Khan Chandio (UC-26)"
        ]
      },
      {
        "name": "Dadah (UC-25)",
        "centres": [
          "BHU Dadah",
          "DCD Sangi Pharo",
          "GD Hafeez Pirzada"
        ]
      },
      {
        "name": "Dei (UC-24)",
        "centres": [
          "Dei (UC-24)"
        ]
      },
      {
        "name": "Gaad @ Hayat Khaskheli (UC-27)",
        "centres": [
          "Gaad @ Hayat Khaskheli (UC-27)"
        ]
      },
      {
        "name": "Khadehro (UC-23)",
        "centres": [
          "RHC Dei"
        ]
      },
      {
        "name": "Khairpur Ghambo (UC-28)",
        "centres": [
          "BHU Wali Mohammad Malkani"
        ]
      },
      {
        "name": "Khalifo Qasim (UC-32)",
        "centres": [
          "BHU Khalifo Qasim",
          "BHU Saeed Khan Bhurgari",
          "BHU Turk Farum"
        ]
      },
      {
        "name": "Khan Bahadur Mir Ghulam Muhammad Talpur UC-36",
        "centres": [
          "Khan Bahadur Mir Ghulam Muhammad Talpur UC-36"
        ]
      },
      {
        "name": "Oliya Jarkas (UC-30)",
        "centres": [
          "BHU Ishaque Dero",
          "GD Choudry Deen Muhammad",
          "Indus Shadi Large EPI Site"
        ]
      },
      {
        "name": "Oliya Khan Shah (UC-33)",
        "centres": [
          "Oliya Khan Shah (UC-33)"
        ]
      },
      {
        "name": "Pahar Mari (UC-35)",
        "centres": [
          "BHU Ali Bux Shah"
        ]
      },
      {
        "name": "Pir Bodlo (UC-31)",
        "centres": [
          "Pir Bodlo (UC-31)"
        ]
      },
      {
        "name": "Saeed Khan Bhurgari (UC-34)",
        "centres": [
          "Saeed Khan Bhurgari (UC-34)"
        ]
      },
      {
        "name": "Saman Shah Sarkar (UC-29)",
        "centres": [
          "Saman Shah Sarkar (UC-29)"
        ]
      },
      {
        "name": "Sarang Faqeer (UC-38)",
        "centres": [
          "Sarang Faqeer (UC-38)"
        ]
      },
      {
        "name": "TC-4 Tando Bago",
        "centres": [
          "THQ Tando Bago"
        ]
      },
      {
        "name": "TC-5 Pangrio",
        "centres": [
          "RHC Pangrio"
        ]
      },
      {
        "name": "TC-6 Khoski",
        "centres": [
          "DC Dispansery Chodri Iqbal",
          "RHC Khoski"
        ]
      }
    ]
  },
  "Dadu": {
    "Dadu": [
      {
        "name": "Allahabad",
        "centres": [
          "BHU Ibrahim Panhwar",
          "BHU Khera",
          "BHU Piaro Goth"
        ]
      },
      {
        "name": "DADU-1",
        "centres": [
          "Civil Hospital Dadu-1"
        ]
      },
      {
        "name": "DADU-2",
        "centres": [
          "Outreach UC-02"
        ]
      },
      {
        "name": "DADU-3",
        "centres": [
          "GD Bagri Colony",
          "MCH Mallah Chowk",
          "Police Line Dadu"
        ]
      },
      {
        "name": "DADU-4",
        "centres": [
          "Outreach UC-4"
        ]
      },
      {
        "name": "KHUDABAD",
        "centres": [
          "BHU Aminani",
          "MCH Center Khudabad"
        ]
      },
      {
        "name": "MAKHDOOM BILAWAL",
        "centres": [
          "BHU Makhdoom Bilawal"
        ]
      },
      {
        "name": "MOUNDER",
        "centres": [
          "BHU Mounder"
        ]
      },
      {
        "name": "PATT",
        "centres": [
          "BHU Patt",
          "BHU Sita Village"
        ]
      },
      {
        "name": "PHULJI STATION",
        "centres": [
          "BHU Phulji Station",
          "BHU Purano Dero"
        ]
      },
      {
        "name": "PIARO STATION",
        "centres": [
          "Exp Dispensary Piaro Station",
          "GD Jat Shadad"
        ]
      },
      {
        "name": "PIPRI",
        "centres": [
          "BHU Pipri",
          "Exp Dispensary Shahnawaz Mastoi"
        ]
      },
      {
        "name": "YAR MOHD KALHORA",
        "centres": [
          "BHU Phaka",
          "BHU Samtani"
        ]
      },
      {
        "name": "SIYAL",
        "centres": [
          "BHU Jhallo"
        ]
      },
      {
        "name": "Muradabaad",
        "centres": [
          "Exp Dispensary Ahmed Khan Jatoi"
        ]
      },
      {
        "name": "Ameenani",
        "centres": [
          "Ameenani"
        ]
      },
      {
        "name": "Jabeerjee",
        "centres": [
          "Jabeerjee"
        ]
      },
      {
        "name": "Pako Sita",
        "centres": [
          "Exp Dispensary Piaro Station",
          "GD Jat Shadad"
        ]
      },
      {
        "name": "Pir Tarho",
        "centres": [
          "Exp Dispensary Piaro Station",
          "GD Jat Shadad"
        ]
      },
      {
        "name": "Pir Shahnawaz",
        "centres": [
          "Pir Shahnawaz"
        ]
      },
      {
        "name": "Ripp",
        "centres": [
          "Ripp"
        ]
      }
    ],
    "Johi": [
      {
        "name": "BAHAWALPUR",
        "centres": [
          "BHU Allahyarani",
          "BHU Bawalpur"
        ]
      },
      {
        "name": "CHHINI",
        "centres": [
          "GD Pir Gaji Shah",
          "GD Sijawal Khan Alkhani",
          "KB Chaker Khan Shahni"
        ]
      },
      {
        "name": "DRIGH BALLA",
        "centres": [
          "BHU Haji Khan",
          "Health Center Drigh Bala"
        ]
      },
      {
        "name": "JOHI UC",
        "centres": [
          "TH Johi"
        ]
      },
      {
        "name": "KAMAL KHAN",
        "centres": [
          "BHU Kamal Khan"
        ]
      },
      {
        "name": "PAT GUL MOHD",
        "centres": [
          "GD Mureed Babar"
        ]
      },
      {
        "name": "PHULJI VILLAGE",
        "centres": [
          "BHU Phulji Village"
        ]
      },
      {
        "name": "SAWRO",
        "centres": [
          "BHU Sawaro"
        ]
      },
      {
        "name": "TANDO RAHIM KHAN",
        "centres": [
          "BHU Wahi Pandhi",
          "GD Murad Khan Jamali",
          "GD Paryo Jamali",
          "GD TR Khan"
        ]
      },
      {
        "name": "TOURE",
        "centres": [
          "BHU Qasbo"
        ]
      },
      {
        "name": "PIR MASHAIK",
        "centres": [
          "PIR MASHAIK"
        ]
      },
      {
        "name": "THARARI JADO SHAHEED",
        "centres": [
          "THARARI JADO SHAHEED"
        ]
      },
      {
        "name": "SHAH HASSAN",
        "centres": [
          "SHAH HASSAN"
        ]
      },
      {
        "name": "KHOOH MANO",
        "centres": [
          "KHOOH MANO"
        ]
      },
      {
        "name": "WAHI PANDHI",
        "centres": [
          "WAHI PANDHI"
        ]
      },
      {
        "name": "JOHI-2",
        "centres": [
          "TH Johi"
        ]
      }
    ],
    "Khairpur Nathan Shah": [
      {
        "name": "BURIRA",
        "centres": [
          "BHU Burira"
        ]
      },
      {
        "name": "CHHORE",
        "centres": [
          "BHU Chore"
        ]
      },
      {
        "name": "D.B BUGHIO",
        "centres": [
          "BHU DB Bughia"
        ]
      },
      {
        "name": "GOZO",
        "centres": [
          "BHU Gozo"
        ]
      },
      {
        "name": "K.N SHAH",
        "centres": [
          "MCH Center Jeejal Maa",
          "TH KN Shah"
        ]
      },
      {
        "name": "KAKAR",
        "centres": [
          "BHU Boriri",
          "GD Kakar"
        ]
      },
      {
        "name": "KANDI CHUKKI",
        "centres": [
          "BHU Baid"
        ]
      },
      {
        "name": "MITHO BABAR",
        "centres": [
          "BHU Khanpur",
          "BHU Mitho Baber",
          "GD Gul Muhammad Chandio"
        ]
      },
      {
        "name": "PERYA",
        "centres": [
          "BHU Dougar"
        ]
      },
      {
        "name": "SINDHI BUTTRA",
        "centres": [
          "BHU Essa Khan Thebo"
        ]
      },
      {
        "name": "SITA ROAD",
        "centres": [
          "HC Sita Road"
        ]
      },
      {
        "name": "THALHO",
        "centres": [
          "BHU Rawat Khan Leghari",
          "BHU Thalho"
        ]
      },
      {
        "name": "fathpur",
        "centres": [
          "fathpur"
        ]
      },
      {
        "name": "Rahoja",
        "centres": [
          "Rahoja"
        ]
      },
      {
        "name": "Chandan",
        "centres": [
          "Chandan"
        ]
      },
      {
        "name": "Gadhi",
        "centres": [
          "Gadhi"
        ]
      },
      {
        "name": "Boriri",
        "centres": [
          "BHU Burira"
        ]
      }
    ],
    "Mehar": [
      {
        "name": "TH MUHABAT",
        "centres": [
          "BHU But Serai",
          "BHU Thariri Muhabat"
        ]
      },
      {
        "name": "SHAH PANJO SULTAN",
        "centres": [
          "BHU Aghmani",
          "MCH Shah Panjo Sultan"
        ]
      },
      {
        "name": "RADHAN",
        "centres": [
          "HC Radhan"
        ]
      },
      {
        "name": "QAZI ARIF",
        "centres": [
          "BHU Qazi Arif"
        ]
      },
      {
        "name": "NAU GOTH",
        "centres": [
          "BHU Nau Goth",
          "GD Taj Muhammed Zardari"
        ]
      },
      {
        "name": "MEHAR UC",
        "centres": [
          "TH Mehar"
        ]
      },
      {
        "name": "MANGWANI",
        "centres": [
          "BHU Kolachi-UC Mangwani"
        ]
      },
      {
        "name": "KOLACHI",
        "centres": [
          "BHU Kolachi-1"
        ]
      },
      {
        "name": "KHAN JO GOTH",
        "centres": [
          "BHU Saeedpur",
          "GD Gul Muhammad Jatoi"
        ]
      },
      {
        "name": "GAHI MAHESAR",
        "centres": [
          "TH Mehar- (UC Gahi Mahessar)"
        ]
      },
      {
        "name": "FARIDABAD",
        "centres": [
          "BHU Faridabad",
          "GD Qadir Bux Rind"
        ]
      },
      {
        "name": "BOTHRO",
        "centres": [
          "GD Bothro",
          "GD Nawab Jo Pat"
        ]
      },
      {
        "name": "BETTO",
        "centres": [
          "BHU Betto"
        ]
      },
      {
        "name": "BALI SHAH",
        "centres": [
          "BHU Bali Shah"
        ]
      },
      {
        "name": "BALEDAI",
        "centres": [
          "GD Baledai",
          "GD Loung Tunio"
        ]
      },
      {
        "name": "Butt Serai",
        "centres": [
          "Butt Serai"
        ]
      },
      {
        "name": "Charo",
        "centres": [
          "Charo"
        ]
      },
      {
        "name": "Litan",
        "centres": [
          "Litan"
        ]
      },
      {
        "name": "MEHAR2",
        "centres": [
          "TH Mehar"
        ]
      },
      {
        "name": "Mureed Lakhier",
        "centres": [
          "Mureed Lakhier"
        ]
      },
      {
        "name": "Poracho",
        "centres": [
          "BHU Kolachi-1"
        ]
      },
      {
        "name": "Syedpur",
        "centres": [
          "Syedpur"
        ]
      },
      {
        "name": "Sojhro Gorar",
        "centres": [
          "Sojhro Gorar"
        ]
      },
      {
        "name": "Sobho Khan Magsi",
        "centres": [
          "Sobho Khan Magsi"
        ]
      }
    ]
  },
  "Ghotki": {
    "Daharki": [
      {
        "name": "Beroota",
        "centres": [
          "G.D Yaqoob Mahar"
        ]
      },
      {
        "name": "Dad Laghari",
        "centres": [
          "B.H.U Dad laghari",
          "B.H.U Gulam Hyder Laghari"
        ]
      },
      {
        "name": "Daharki- Daharki",
        "centres": [
          "THQ Daharki"
        ]
      },
      {
        "name": "Kenjhur",
        "centres": [
          "B.H.U Ahmed Ali Pitafi"
        ]
      },
      {
        "name": "Daharki-Raharki",
        "centres": [
          "BHU Bago bhutto"
        ]
      },
      {
        "name": "Sain Dino Malik",
        "centres": [
          "B.H.U Soomro Khambhro"
        ]
      }
    ],
    "Ghotki": [
      {
        "name": "Ali Bagh",
        "centres": [
          "BHU Jahan Pur"
        ]
      },
      {
        "name": "Berirri",
        "centres": [
          "GD Changlani",
          "MHU Mathelo"
        ]
      },
      {
        "name": "Ghotki-1",
        "centres": [
          "THQ Ghotki 1"
        ]
      },
      {
        "name": "Hussain Beli",
        "centres": [
          "BHU HUSSAIN BELI"
        ]
      },
      {
        "name": "Khunhara",
        "centres": [
          "GD Sijawal Dhandhu"
        ]
      },
      {
        "name": "MK Ghoto",
        "centres": [
          "EPI CENTER MK GHOTO"
        ]
      },
      {
        "name": "Qadir pur",
        "centres": [
          "BHU Qadir Pur"
        ]
      },
      {
        "name": "Adil Pur",
        "centres": [
          "RHC Adil Pur"
        ]
      },
      {
        "name": "Bago Daho",
        "centres": [
          "BHU Bago Daho"
        ]
      },
      {
        "name": "Bandh",
        "centres": [
          "BHU Ayub Lakhan"
        ]
      },
      {
        "name": "Ghotki- Ruk",
        "centres": [
          "BHU Taj Muhammad Ruk"
        ]
      },
      {
        "name": "Umar Daho",
        "centres": [
          "BHU Singhrri",
          "BHU Umar Daho"
        ]
      },
      {
        "name": "Ghotki-2",
        "centres": [
          "THQ Ghotki 2"
        ]
      },
      {
        "name": "Ghotki-3",
        "centres": [
          "THQ Ghotki 3"
        ]
      }
    ],
    "Khan Garh": [
      {
        "name": "Khanpur Mahar",
        "centres": [
          "SHBM HOSPITAL KHANPUR"
        ]
      },
      {
        "name": "Lohi",
        "centres": [
          "BHU lohi"
        ]
      },
      {
        "name": "Mithri",
        "centres": [
          "BHU Ali Mahar",
          "BHU Salih Mahar",
          "GD Qazi Badal"
        ]
      },
      {
        "name": "Bhetoor",
        "centres": [
          "EPI Center at UC office"
        ]
      }
    ],
    "Mirpur Mathelo": [
      {
        "name": "Dhangro",
        "centres": [
          "BHU Ghulam Hussain Laghari"
        ]
      },
      {
        "name": "Wahi Ghoto",
        "centres": [
          "BHU Laandhiyon Mahar"
        ]
      },
      {
        "name": "Garhi Chakar",
        "centres": [
          "BHU Darwaish Naich",
          "BHU Garhi chakar"
        ]
      },
      {
        "name": "Jarwar",
        "centres": [
          "GD Hayat Pitafi",
          "RHC Jarwar"
        ]
      },
      {
        "name": "Mirpur Mathelo- Mirpur Mathelo 01",
        "centres": [
          "Sant Raja Ram hospital"
        ]
      },
      {
        "name": "Mirpur Mathelo 02",
        "centres": [
          "BHU Kaoro Laghari",
          "DHQ Mirpur Mathelo",
          "MCH DHQ Mirpur Mathelo"
        ]
      },
      {
        "name": "Sono Pitafi",
        "centres": [
          "BHU Sono Pitafi"
        ]
      },
      {
        "name": "Yaro Lund",
        "centres": [
          "BHU Noor Abad"
        ]
      }
    ],
    "Ubauro": [
      {
        "name": "Chandiya",
        "centres": [
          "BHU Mureed Shakh",
          "BHU Punhoo Khan Mazari"
        ]
      },
      {
        "name": "Jhangal Malik",
        "centres": [
          "RHC Retti"
        ]
      },
      {
        "name": "Kamoo Shaheed",
        "centres": [
          "BHU Kamoo Shaheed"
        ]
      },
      {
        "name": "Khambhra",
        "centres": [
          "BHU Khambhra"
        ]
      },
      {
        "name": "Lagho",
        "centres": [
          "BHU Hasoo Daho"
        ]
      },
      {
        "name": "Ranwti",
        "centres": [
          "BHU Ranwati",
          "BHU Syed Pur"
        ]
      },
      {
        "name": "Ubaro- Ubaro-",
        "centres": [
          "THQ Ubaro"
        ]
      },
      {
        "name": "Ubaro- Wasti Jeewan Shah",
        "centres": [
          "BHU Haji Abdul Sattar",
          "BHU Soi Shareef",
          "Jam Khan Samejo"
        ]
      }
    ]
  },
  "Hyderabad": {
    "Hyderabad City": [
      {
        "name": "Hyderabad-uc1",
        "centres": [
          "Agha Khan Dispensery - Mubarak Colony",
          "Trauma Center-1"
        ]
      },
      {
        "name": "Hyderabad-uc2",
        "centres": [
          "Aiwan-e-Quresh"
        ]
      },
      {
        "name": "Hyderabad-3",
        "centres": [
          "L.U.H O.P.D"
        ]
      },
      {
        "name": "Hyderabad-4",
        "centres": [
          "G.G Jagrani Hospital"
        ]
      },
      {
        "name": "Hyderabad-5",
        "centres": [
          "Dr. Musrat Abdul Manan Clinic"
        ]
      },
      {
        "name": "Hyderabad-6",
        "centres": [
          "Memon Hospital Hyderabad"
        ]
      },
      {
        "name": "Hyderabad-7",
        "centres": [
          "Tara Chand Hospital"
        ]
      },
      {
        "name": "Hyderabad-8",
        "centres": [
          "Abu Illahi Hospital"
        ]
      },
      {
        "name": "Hyderabad-9",
        "centres": [
          "CDF Hospital"
        ]
      },
      {
        "name": "Hyderabad-10",
        "centres": [
          "BHU Liaquat Colony"
        ]
      },
      {
        "name": "Hyderabad-12",
        "centres": [
          "HMC Dispensary Bakra Mandi"
        ]
      },
      {
        "name": "Hyderabad-13",
        "centres": [
          "Muslim Marwar Hospital"
        ]
      },
      {
        "name": "Hyderabad-14",
        "centres": [
          "Mehran Hospital",
          "SESSI Dispensery Tando Agha"
        ]
      },
      {
        "name": "Hyderabad-15",
        "centres": [
          "KKF Dispensery Nazir Hussain Hospital",
          "SESSI Hospital Odeon Cinema"
        ]
      },
      {
        "name": "Hyderabad-16",
        "centres": [
          "Agha Khan Dispensery - Aliabad",
          "Agha Khan Dispensery - Ameenabad",
          "DGH Paretabad",
          "Experimental DispenceryQuetta Town"
        ]
      },
      {
        "name": "Hyderabad-17",
        "centres": [
          "HMC Dispensary ZachaKhana"
        ]
      },
      {
        "name": "Hyderabad-19",
        "centres": [
          "NH Children Hospital Tanga Stand"
        ]
      },
      {
        "name": "Hyderabad-20",
        "centres": [
          "NH Children Hospital"
        ]
      },
      {
        "name": "Hyderabad-11",
        "centres": [
          "Outreach UC - 11"
        ]
      },
      {
        "name": "Hyderabad-18",
        "centres": [
          "Outreach Uc - 18"
        ]
      }
    ],
    "Hyderabad": [
      {
        "name": "Masu Bhurgri",
        "centres": [
          "Masu Bhurgri"
        ]
      },
      {
        "name": "Moosa Khatiyan",
        "centres": [
          "Moosa Khatiyan"
        ]
      },
      {
        "name": "Tando Hyder",
        "centres": [
          "Tando Hyder"
        ]
      },
      {
        "name": "Tando Fazal",
        "centres": [
          "Tando Fazal"
        ]
      },
      {
        "name": "Sawan Gopang",
        "centres": [
          "Sawan Gopang"
        ]
      },
      {
        "name": "Seri",
        "centres": [
          "Seri"
        ]
      },
      {
        "name": "Husri",
        "centres": [
          "Husri"
        ]
      },
      {
        "name": "Tando Jam",
        "centres": [
          "Tando Jam"
        ]
      },
      {
        "name": "Tando Qaisar",
        "centres": [
          "Tando Qaisar"
        ]
      },
      {
        "name": "Moolan",
        "centres": [
          "Moolan"
        ]
      },
      {
        "name": "Hattri",
        "centres": [
          "Hattri"
        ]
      }
    ],
    "Latifabad": [
      {
        "name": "Latifabad-1",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-2",
        "centres": [
          "Al Shifa Medical Center"
        ]
      },
      {
        "name": "Latifabad-3",
        "centres": [
          "Majee Hospital Unit No 8",
          "St Eliz Hospital Unit No 7"
        ]
      },
      {
        "name": "Latifabad-4",
        "centres": [
          "Hilal Ahmer Unit No 6"
        ]
      },
      {
        "name": "Latifabad-6",
        "centres": [
          "BHU Unit No 10"
        ]
      },
      {
        "name": "Latifabad-7",
        "centres": [
          "UHU Latifabad No:11"
        ]
      },
      {
        "name": "Latifabad-9",
        "centres": [
          "Akhtar Medicare Center"
        ]
      },
      {
        "name": "Latifabad-10",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-11",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-12",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-13",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-14",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-15",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-16",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-17",
        "centres": [
          "GD Hussainabad",
          "HMC Dispensary Unit No 4"
        ]
      },
      {
        "name": "Latifabad-8",
        "centres": [
          "Youth Welfare Society Charitable Hospital"
        ]
      },
      {
        "name": "Latifabad-5",
        "centres": [
          "Government Hospital Shah Bhittai"
        ]
      }
    ],
    "Qasimabad": [
      {
        "name": "Qasimabad-2",
        "centres": [
          "Hilal-e-Ahmar Dispensery",
          "Services Hospital"
        ]
      },
      {
        "name": "Qasimabad-3",
        "centres": [
          "Jeejal Maa Hospital",
          "Sindh Govt. Hospital Qasimabad"
        ]
      },
      {
        "name": "Qasimabad-4",
        "centres": [
          "G.D Karan Khan Shoro",
          "MCHC Marvi Dispensary Garden"
        ]
      },
      {
        "name": "Qasimabad-5",
        "centres": [
          "Aga Khan Hospital",
          "DCD Noor Khan Chang",
          "Isra Hospital",
          "Rajputana Hospital"
        ]
      },
      {
        "name": "Cantt",
        "centres": [
          "Cantt General Hospital",
          "CMH Hospital",
          "Hajani Day and Night Hospital",
          "Police Hospital"
        ]
      },
      {
        "name": "Qasimabad-1",
        "centres": [
          "BHU Sehrish Nagar"
        ]
      }
    ]
  },
  "Jacobabad": {
    "Garhi Khairo": [
      {
        "name": "Allah Abad",
        "centres": [
          "G.D Allah Abad"
        ]
      },
      {
        "name": "KOUR KHAIRO",
        "centres": [
          "THQ Garhi Khairo"
        ]
      },
      {
        "name": "GARHI KHAIRO-1",
        "centres": [
          "THQ Garhi Khairo"
        ]
      },
      {
        "name": "Khuda Abad",
        "centres": [
          "BHU Dodapur"
        ]
      },
      {
        "name": "Miran Pur",
        "centres": [
          "DCD Miranpur"
        ]
      },
      {
        "name": "Mohammadpur Odho",
        "centres": [
          "BHU Muhammad Pur",
          "GD Ali Sher Jakhrani",
          "MCH Sheran Pur"
        ]
      },
      {
        "name": "SHER KHAN",
        "centres": [
          "SHER KHAN"
        ]
      },
      {
        "name": "JAHANPUR",
        "centres": [
          "BHU Hashmatabad"
        ]
      },
      {
        "name": "GARHI KHAIRO -2",
        "centres": [
          "THQ Garhi Khairo"
        ]
      },
      {
        "name": "DODAPUR",
        "centres": [
          "DODAPUR"
        ]
      },
      {
        "name": "SHERANPUR",
        "centres": [
          "DCD Miranpur"
        ]
      }
    ],
    "Jacobabad": [
      {
        "name": "BAQAPUR JCD",
        "centres": [
          "BAQAPUR JCD"
        ]
      },
      {
        "name": "JCD-8",
        "centres": [
          "JCD-8"
        ]
      },
      {
        "name": "Dashti",
        "centres": [
          "BHU Abdullah Lashari",
          "GD Jumo Khan Dasti"
        ]
      },
      {
        "name": "JCD-4",
        "centres": [
          "JCD-4"
        ]
      },
      {
        "name": "Garhi Chand",
        "centres": [
          "BHU Banglow Sydan",
          "GD Abad",
          "GD Adam Khan Panhwar"
        ]
      },
      {
        "name": "JCD-7",
        "centres": [
          "JCD-7"
        ]
      },
      {
        "name": "JCD-2",
        "centres": [
          "JCD-2"
        ]
      },
      {
        "name": "JCD-5",
        "centres": [
          "JCD-5"
        ]
      },
      {
        "name": "DADPUR JAGIR",
        "centres": [
          "DADPUR JAGIR"
        ]
      },
      {
        "name": "Jacobabad-5 (Phool Bagh)",
        "centres": [
          "Airbase Hospital"
        ]
      },
      {
        "name": "Qadir Pur",
        "centres": [
          "RHC Qadir Pur"
        ]
      },
      {
        "name": "Ramzan Pur",
        "centres": [
          "Ramzanpur"
        ]
      },
      {
        "name": "Rind Wahi",
        "centres": [
          "BHU Noor Muhammad Pathan"
        ]
      },
      {
        "name": "JCD-3",
        "centres": [
          "JCD-3"
        ]
      },
      {
        "name": "JCD-1",
        "centres": [
          "JCD-1"
        ]
      },
      {
        "name": "ALI PUR",
        "centres": [
          "RHC Qadir Pur"
        ]
      },
      {
        "name": "JCD -6",
        "centres": [
          "JCD -6"
        ]
      },
      {
        "name": "MOULA DAD",
        "centres": [
          "MOULA DAD"
        ]
      },
      {
        "name": "SHAH PUR",
        "centres": [
          "BHU Sunhno Khan Rind"
        ]
      },
      {
        "name": "JANI DERO",
        "centres": [
          "JANI DERO"
        ]
      },
      {
        "name": "Mehar Shah Jcd",
        "centres": [
          "Mehar Shah Jcd"
        ]
      }
    ],
    "Thul": [
      {
        "name": "Bachro",
        "centres": [
          "MCHC Bachro"
        ]
      },
      {
        "name": "Balochabad",
        "centres": [
          "DCD Abdul Rasool Khoso",
          "MCH Imam Bux Kehar",
          "MCH Madad Pur"
        ]
      },
      {
        "name": "Deenpur",
        "centres": [
          "BHU Bangul Khoso"
        ]
      },
      {
        "name": "Garhi Hassan",
        "centres": [
          "GD Nasir khan Bhangar",
          "RHC Garhi Hassan"
        ]
      },
      {
        "name": "Joungal",
        "centres": [
          "BHU Joungal"
        ]
      },
      {
        "name": "Karim Bux",
        "centres": [
          "BHU Bahadur Pur",
          "BHU karim bux"
        ]
      },
      {
        "name": "Kot Jangu",
        "centres": [
          "koat jangu"
        ]
      },
      {
        "name": "Logi",
        "centres": [
          "BHU Azizabaad",
          "Ghulam M Jakhrani"
        ]
      },
      {
        "name": "Mir Pur",
        "centres": [
          "RHC Mirpur Burriro"
        ]
      },
      {
        "name": "DIN GARH",
        "centres": [
          "DIN GARH"
        ]
      },
      {
        "name": "Mubarak Pur",
        "centres": [
          "BHU Mubarak Pur"
        ]
      },
      {
        "name": "Ranjha Pur",
        "centres": [
          "Lal Bhatti"
        ]
      },
      {
        "name": "Sardo Kot",
        "centres": [
          "OTP Site Village Balach Banglani"
        ]
      },
      {
        "name": "Sherwah",
        "centres": [
          "BHU Jumo Dakhan"
        ]
      },
      {
        "name": "Tajo Khoso",
        "centres": [
          "BHU Bahu Khoso"
        ]
      },
      {
        "name": "KANRANI",
        "centres": [
          "KANRANI"
        ]
      },
      {
        "name": "Thull I",
        "centres": [
          "MCH Center Thul",
          "THQ Thul"
        ]
      },
      {
        "name": "Thull II",
        "centres": [
          "MCH Center Thul",
          "THQ Thul"
        ]
      },
      {
        "name": "Toj",
        "centres": [
          "BHU Buxan Pahore"
        ]
      },
      {
        "name": "MADADPUR",
        "centres": [
          "BHU Mubarak Pur"
        ]
      },
      {
        "name": "TC SOHRAB KHAN",
        "centres": [
          "TC SOHRAB KHAN"
        ]
      },
      {
        "name": "BAHADURPUR",
        "centres": [
          "Lal Bhatti"
        ]
      },
      {
        "name": "MALOI",
        "centres": [
          "BHU Azizabaad",
          "Ghulam M Jakhrani"
        ]
      },
      {
        "name": "TC MIRPUR",
        "centres": [
          "RHC Mirpur Burriro"
        ]
      },
      {
        "name": "TANWRI",
        "centres": [
          "TANWRI"
        ]
      },
      {
        "name": "MOOSA WAH",
        "centres": [
          "MOOSA WAH"
        ]
      },
      {
        "name": "KARIMABAD",
        "centres": [
          "BHU Bahadur Pur",
          "BHU karim bux"
        ]
      },
      {
        "name": "THULL III",
        "centres": [
          "MCH Center Thul",
          "THQ Thul"
        ]
      },
      {
        "name": "BAKHTIYARPUR",
        "centres": [
          "BAKHTIYARPUR"
        ]
      }
    ]
  },
  "Jamshoro": {
    "Kotri": [
      {
        "name": "Nango Line",
        "centres": [
          "THQ KOTRI"
        ]
      },
      {
        "name": "Haji Manghi Shoro",
        "centres": [
          "GD CC Kotri"
        ]
      },
      {
        "name": "Allah Bachayo Shoro",
        "centres": [
          "BHU KARO KHAHO",
          "Social Security Hospital (Priv"
        ]
      },
      {
        "name": "Sono Walhaar-1",
        "centres": [
          "Bhu Khado",
          "GD BEHAR COLONY",
          "Khursheed colony"
        ]
      },
      {
        "name": "Sono Walhaar-2",
        "centres": [
          "BHU KHUDA KI BASTI"
        ]
      },
      {
        "name": "Sono Walhaar-3",
        "centres": [
          "EPI Center LUMHS (Civil Hospit",
          "GD SINDH UNIVERISTY COLONY"
        ]
      },
      {
        "name": "Jamshoro Town",
        "centres": [
          "GD LSB Dispensary Jamshoro"
        ]
      },
      {
        "name": "Petaro",
        "centres": [
          "DCD Petaro"
        ]
      },
      {
        "name": "Morho Jabal",
        "centres": [
          "GD TPS"
        ]
      },
      {
        "name": "Kotri UC",
        "centres": [
          "Outreach-Kotri city"
        ]
      }
    ],
    "Sehwan": [
      {
        "name": "Sehwan-1",
        "centres": [
          "THQ Sehwan Sharif-1"
        ]
      },
      {
        "name": "Sehwan-2",
        "centres": [
          "Outreach UC-2"
        ]
      },
      {
        "name": "Channa",
        "centres": [
          "GD Karampur",
          "HC ARAZI",
          "JST IHN - Hospital"
        ]
      },
      {
        "name": "Bhan",
        "centres": [
          "RHC BHAN"
        ]
      },
      {
        "name": "Bubak",
        "centres": [
          "BHU BUBAK",
          "GD Band Machar"
        ]
      },
      {
        "name": "Talti",
        "centres": [
          "BHU Talti",
          "RHC TALTI"
        ]
      },
      {
        "name": "Dall",
        "centres": [
          "BHU TAJUJI",
          "BHU WAHUR"
        ]
      },
      {
        "name": "Jhangara",
        "centres": [
          "GD Bajara",
          "HC JHANGARA"
        ]
      }
    ],
    "Manjhand": [
      {
        "name": "Manjhand UC",
        "centres": [
          "GD Saharabad",
          "RHC UNARPUR",
          "THQ Manjhand"
        ]
      },
      {
        "name": "Lakha",
        "centres": [
          "BHU Lakha"
        ]
      },
      {
        "name": "Manzoorabad",
        "centres": [
          "BHU KHANOTH"
        ]
      },
      {
        "name": "Sann",
        "centres": [
          "HC SANN"
        ]
      },
      {
        "name": "Amri",
        "centres": [
          "BHU AMRI",
          "BHU LAKI"
        ]
      }
    ],
    "Thana Bulla Khan": [
      {
        "name": "Thano bula Khan UC",
        "centres": [
          "TH TB KHAN"
        ]
      },
      {
        "name": "Toung",
        "centres": [
          "BHU TOUNG",
          "BHU Wali dad Gabol"
        ]
      },
      {
        "name": "Mole",
        "centres": [
          "BHU MOLE"
        ]
      },
      {
        "name": "Sarri",
        "centres": [
          "BHU SARRI",
          "GH NORIABAD"
        ]
      },
      {
        "name": "Thano Arab Khan",
        "centres": [
          "BHU Thano Ahmed Khan",
          "Bhu Thano Arab Khan",
          "GD Karchat"
        ]
      }
    ]
  },
  "Kambar Shahdadkot": {
    "Mirokhan": [
      {
        "name": "Bahram",
        "centres": [
          "Bahram"
        ]
      },
      {
        "name": "Karira",
        "centres": [
          "Karira"
        ]
      },
      {
        "name": "Khabar",
        "centres": [
          "Khabar"
        ]
      },
      {
        "name": "Mirokhan",
        "centres": [
          "Mirokhan"
        ]
      }
    ],
    "Nasirabad": [
      {
        "name": "Dera",
        "centres": [
          "Dera"
        ]
      },
      {
        "name": "Nasirabad- Lakha",
        "centres": [
          "Nasirabad- Lakha"
        ]
      },
      {
        "name": "Miandad Chinjni",
        "centres": [
          "Miandad Chinjni"
        ]
      },
      {
        "name": "Muradi",
        "centres": [
          "Muradi"
        ]
      },
      {
        "name": "Naseerabad",
        "centres": [
          "Naseerabad"
        ]
      }
    ],
    "Qambar": [
      {
        "name": "Ber",
        "centres": [
          "Ber"
        ]
      },
      {
        "name": "Boohar",
        "centres": [
          "Boohar"
        ]
      },
      {
        "name": "Dost Ali",
        "centres": [
          "Dost Ali"
        ]
      },
      {
        "name": "Gaibi Dero",
        "centres": [
          "Gaibi Dero"
        ]
      },
      {
        "name": "Jean Abro",
        "centres": [
          "Jean Abro"
        ]
      },
      {
        "name": "Kalar",
        "centres": [
          "Kalar"
        ]
      },
      {
        "name": "Qambar-1",
        "centres": [
          "Qambar-1"
        ]
      },
      {
        "name": "Qambar-2",
        "centres": [
          "Qambar-2"
        ]
      },
      {
        "name": "Qambar-3",
        "centres": [
          "Qambar-3"
        ]
      },
      {
        "name": "Khairpur Juiso",
        "centres": [
          "Khairpur Juiso"
        ]
      },
      {
        "name": "Ranwati",
        "centres": [
          "Ranwati"
        ]
      }
    ],
    "Qubo Saeed Khan": [
      {
        "name": "Bago Daro",
        "centres": [
          "Bago Daro"
        ]
      },
      {
        "name": "Hazarwah",
        "centres": [
          "Hazarwah"
        ]
      },
      {
        "name": "Qubo Saeed Khan",
        "centres": [
          "Qubo Saeed Khan"
        ]
      }
    ],
    "Shahdadkot": [
      {
        "name": "Aitbar Khan",
        "centres": [
          "Aitbar Khan"
        ]
      },
      {
        "name": "Jamali",
        "centres": [
          "Jamali"
        ]
      },
      {
        "name": "Seelra",
        "centres": [
          "Seelra"
        ]
      },
      {
        "name": "Shahdadkot-1",
        "centres": [
          "Shahdadkot-1"
        ]
      },
      {
        "name": "Shahdadkot-2",
        "centres": [
          "Shahdadkot-2"
        ]
      },
      {
        "name": "Shahdadkot-3",
        "centres": [
          "Shahdadkot-3"
        ]
      }
    ],
    "Sijawal Junejo": [
      {
        "name": "Dhinghano Mahessar",
        "centres": [
          "Dhinghano Mahessar"
        ]
      },
      {
        "name": "Mastoi",
        "centres": [
          "Mastoi"
        ]
      },
      {
        "name": "Sijawal- Sijawal",
        "centres": [
          "Sijawal- Sijawal"
        ]
      },
      {
        "name": "Thoof chosool",
        "centres": [
          "Thoof chosool"
        ]
      }
    ],
    "Warah": [
      {
        "name": "Abad",
        "centres": [
          "Abad"
        ]
      },
      {
        "name": "Gaji Khuhawar",
        "centres": [
          "Gaji Khuhawar"
        ]
      },
      {
        "name": "Khandoo",
        "centres": [
          "Khandoo"
        ]
      },
      {
        "name": "Lalu raunk",
        "centres": [
          "Lalu raunk"
        ]
      },
      {
        "name": "Meerpur",
        "centres": [
          "Meerpur"
        ]
      },
      {
        "name": "Waggan",
        "centres": [
          "Waggan"
        ]
      },
      {
        "name": "Warah- Warah",
        "centres": [
          "Warah- Warah"
        ]
      }
    ]
  },
  "Karachi Central": {
    "Gulberg Town": [
      {
        "name": "Samnabad-2",
        "centres": [
          "Samanabad Dispensary"
        ]
      },
      {
        "name": "Naseerabad-4",
        "centres": [
          "AKHSP Rahimabad",
          "AKHSP Slimabad",
          "Naseerabad Dispensary"
        ]
      },
      {
        "name": "Yaseenabad-5",
        "centres": [
          "Goharabad Dispensary"
        ]
      },
      {
        "name": "Water Pump- 3",
        "centres": [
          "Al-Khidmat Medical Center Gulberg Town"
        ]
      },
      {
        "name": "Shafiq Colony-1",
        "centres": [
          "Shafiq Colony-1"
        ]
      },
      {
        "name": "Azizabad-6",
        "centres": [
          "AKHSP Alyabad",
          "AKHSP Blk-7 Kareemabad",
          "B and R Center",
          "Trimex Hospital"
        ]
      },
      {
        "name": "Karimabad-7",
        "centres": [
          "AKHSP Karimabad",
          "UC Office Hussainabad"
        ]
      },
      {
        "name": "Gulberg-8",
        "centres": [
          "Rafah-e-Aam Medical Centre"
        ]
      }
    ],
    "Liaquatabad Town": [
      {
        "name": "Moosa Colony -1",
        "centres": [
          "Moosa Colony Dispensary"
        ]
      },
      {
        "name": "Dakhana - 6",
        "centres": [
          "B Road Dispensary"
        ]
      },
      {
        "name": "Bandhani -3",
        "centres": [
          "Bantwanagar UC Office"
        ]
      },
      {
        "name": "Shrifabad - 2",
        "centres": [
          "S.G.H Liaquatabad",
          "SGD Gharibabad"
        ]
      },
      {
        "name": "Commercial - 5",
        "centres": [
          "Main Road Dispensary"
        ]
      },
      {
        "name": "C- Area -7",
        "centres": [
          "Federal Dispensary"
        ]
      },
      {
        "name": "IBN E SINA - 4",
        "centres": [
          "Abdus Samad Hospital",
          "Amjad Sabri Dispensary"
        ]
      }
    ],
    "New Karachi Town": [
      {
        "name": "Kalyana-12",
        "centres": [
          "Al - Khidmat Center Sector - 1"
        ]
      },
      {
        "name": "Godhra -10",
        "centres": [
          "Godhra Muslim Medical Center"
        ]
      },
      {
        "name": "Abu Zar -9",
        "centres": [
          "Ghousia Medical center"
        ]
      },
      {
        "name": "Hakim Ahsan-11",
        "centres": [
          "Sind Govt Hospital New karachi"
        ]
      },
      {
        "name": "Madina Colony-7",
        "centres": [
          "UCD Dispensary Sec-5G"
        ]
      },
      {
        "name": "Faisal -8",
        "centres": [
          "Muslim Khatri Hopsital"
        ]
      },
      {
        "name": "Khamiso -6",
        "centres": [
          "MAP Medical Center",
          "Umer Clinic"
        ]
      },
      {
        "name": "Mustafa Colony -5",
        "centres": [
          "Amir Shaheed Dispensary",
          "Sindh Govt Hospital Sector 5-D"
        ]
      },
      {
        "name": "Ajmer Nagri -3",
        "centres": [
          "Urban Health Centre/5C3"
        ]
      },
      {
        "name": "Gushan-E-Saeed-2",
        "centres": [
          "MYM Medical Center"
        ]
      },
      {
        "name": "Shahnawaz Bhutto -1",
        "centres": [
          "Akeela Latif Hospital",
          "Sina Welfare Center Zareena"
        ]
      },
      {
        "name": "Kala School -4",
        "centres": [
          "Life Care Hospital"
        ]
      },
      {
        "name": "Muhammad Shah-13",
        "centres": [
          "Muhammad Shah-13"
        ]
      }
    ],
    "North Nazimabad Town": [
      {
        "name": "Sir Syed -1",
        "centres": [
          "Sir Syed -1"
        ]
      },
      {
        "name": "Siddiq e Akbar -3",
        "centres": [
          "Siddiq e Akbar -3"
        ]
      },
      {
        "name": "0ahar Ganj -9",
        "centres": [
          "Shahbbir Memorial Hospital Block P"
        ]
      },
      {
        "name": "Hyderi -7",
        "centres": [
          "Dr. Essa Laboratory North Nazimabad",
          "Mariyum Hospital"
        ]
      },
      {
        "name": "Sakhi Hassan -6",
        "centres": [
          "KMDC"
        ]
      },
      {
        "name": "Farooq-e-azam -2",
        "centres": [
          "Al-Khidmat Sakhi Hassan",
          "Farooq-e-Azam Medical Center",
          "Imam Clinic"
        ]
      },
      {
        "name": "Mustafaabad-10",
        "centres": [
          "Mustafabad Govt. Medical Dispensary Nusrat Bhutto Colony"
        ]
      },
      {
        "name": "Bufferzone -4",
        "centres": [
          "Ali Medical Center"
        ]
      },
      {
        "name": "Taimooria-5",
        "centres": [
          "Taimooria-5"
        ]
      },
      {
        "name": "Alfalah -8",
        "centres": [
          "AKHSP Nizari",
          "Sindh Rangers Hospital"
        ]
      }
    ],
    "Nazimabad": [
      {
        "name": "Rizviq Society -5",
        "centres": [
          "B.H.U Dodha Goth"
        ]
      },
      {
        "name": "Nazimabad -4",
        "centres": [
          "S.G.D Nazimabad"
        ]
      },
      {
        "name": "Abbasi Shaheed -2",
        "centres": [
          "Abbasi Shaheed Hospital",
          "AKHSP Nazimabad",
          "Naimat Begum Hamdard Hospital"
        ]
      },
      {
        "name": "Paposh Nagar -1",
        "centres": [
          "Sina Health Education and Welfare trust"
        ]
      },
      {
        "name": "GulBahar -7",
        "centres": [
          "Pirabad Dispensary"
        ]
      },
      {
        "name": "Firdos Colony -6",
        "centres": [
          "Firdos Colony -6"
        ]
      },
      {
        "name": "Hadi Market -3",
        "centres": [
          "Chiniot Mother and Child Hospital",
          "M.C.H Nazimabad"
        ]
      }
    ]
  },
  "Karachi East": {
    "Jamshed Town": [
      {
        "name": "Akhtar Colony-01",
        "centres": [
          "MCH Center Akhter Colony"
        ]
      },
      {
        "name": "Manzoor Colony-02",
        "centres": [
          "Ashiq Memorial Hospital",
          "Jamila Sultana Welfare",
          "KMC Dispensary Manzoor Colony"
        ]
      },
      {
        "name": "Azam Basti-03",
        "centres": [
          "Bakhtbari Chiniot Hospital",
          "MEVE Trust",
          "UHC Azam Basti"
        ]
      },
      {
        "name": "Chanesar Goth-04",
        "centres": [
          "Behbood Welfare",
          "MCH Mehmoodabad"
        ]
      },
      {
        "name": "Mehmoodabad-05",
        "centres": [
          "Green Belt Dispensary"
        ]
      },
      {
        "name": "P.E.C.H.S. I-06",
        "centres": [
          "Abesynia Line",
          "MCH SINDHI MUSLIM",
          "Pasha Clinic"
        ]
      },
      {
        "name": "P.E.C.H.S. II-07",
        "centres": [
          "Family Care Hospital",
          "SGD Umar Colony"
        ]
      },
      {
        "name": "Jat Line-08",
        "centres": [
          "BHU Jat Line"
        ]
      },
      {
        "name": "Central Jacob Lines-09",
        "centres": [
          "Hashmani Hospital",
          "SRSC Jacob Line",
          "Taj Medical Complex"
        ]
      },
      {
        "name": "Jamshed Quarters-10",
        "centres": [
          "MCH Muslimabad"
        ]
      },
      {
        "name": "Garden East-11",
        "centres": [
          "AKHSP Garden Center",
          "Khalid Jamil Dispensary"
        ]
      },
      {
        "name": "Soldier Bazar-12",
        "centres": [
          "AKHSP Garden Al-Zehra",
          "Fatmiya Hospital",
          "Holy Family",
          "Maternity Home Soldier Bazar",
          "Zainab Panjawani Hospital"
        ]
      },
      {
        "name": "Pakistan Quarters",
        "centres": [
          "AKHSP Platinum FHC",
          "AKHSP Rehmani Hospital",
          "Kanwal Clinic"
        ]
      }
    ],
    "Gulshan-e-Iqbal": [
      {
        "name": "Delhi Mercantile Society-01",
        "centres": [
          "Jamal Noor Hospital",
          "Zubaida Medical Center"
        ]
      },
      {
        "name": "Civic Centre-02",
        "centres": [
          "AKHSP Noorabad",
          "AKUH Stadium Road",
          "Liaquat National Hospital 2",
          "Medicare Hospital"
        ]
      },
      {
        "name": "PIB Colony-03",
        "centres": [
          "AKHSP Amynabad",
          "PIB Maternity Home"
        ]
      },
      {
        "name": "Essa Nagri-04",
        "centres": [
          "Edhi Centre",
          "SG 100 Bedded",
          "UHU Ghousia Colony"
        ]
      },
      {
        "name": "Gulshan-e-Iqbal I-05",
        "centres": [
          "Dr. Farah Essa Acadmey",
          "Hajira Memorial Hospital"
        ]
      },
      {
        "name": "Gillani-06",
        "centres": [
          "Al-Mustafa MC",
          "Ashfaq Memorial Hospital",
          "Essa Lab and Diagnostic Center"
        ]
      },
      {
        "name": "Dalmia-07",
        "centres": [
          "AKHSP Evershine",
          "DC Dispensary - 1",
          "DC Dispensary - 2"
        ]
      },
      {
        "name": "Jamali Colony-08",
        "centres": [
          "Usama Maternity Home"
        ]
      },
      {
        "name": "Gulshan-e-Iqbal II-09",
        "centres": [
          "IBN-E-SINA Hospital",
          "Patel Hospital",
          "The Modern Hospital"
        ]
      },
      {
        "name": "Pehlwan Goth-10",
        "centres": [
          "Darul Sehat Hospital",
          "MCH Rotary Pehlwan Goth",
          "Seha Medical Centre",
          "SGD Hussain Hazara Goth"
        ]
      },
      {
        "name": "Metroville",
        "centres": [
          "Essa Lab and Diagnostic Center-11",
          "Rajput Hospital"
        ]
      },
      {
        "name": "Gulzar-e-Hijri-12",
        "centres": [
          "Al-Khair Hospital",
          "PHC Bakhar Goth",
          "PHC Muhammad Khan Goth",
          "SGD Sachal Goth"
        ]
      },
      {
        "name": "Safooran Goth-13",
        "centres": [
          "AKHSP Al Azhar Garden",
          "DUHS Hospital",
          "MMI Hospital",
          "SGD Bilawal Goth"
        ]
      },
      {
        "name": "Faisal Cant-14",
        "centres": [
          "BHU Pehlwan Goth",
          "CWC PNS Rahat",
          "Essa Lab and Diagnostic Centre",
          "FWC Majeed SRE"
        ]
      }
    ],
    "East - Gadap": [
      {
        "name": "Gujro Zone A",
        "centres": [
          "BHU Lasi Goth",
          "Exp Dispensary Faqeera Goth",
          "Exp Dispensary Gareebabad",
          "Exp Dispensary Junejo Colony",
          "Exp Dispensary Junjar Goth",
          "Exp Dispensary Machar Colony",
          "Exp Dispensary Yasrab Goth",
          "Imam Basri Hospital",
          "Insaaf Medical Center",
          "Jannat Gul Dispensary",
          "Koohi Goth Hospital",
          "Nisa Maternity Home",
          "SINA Clinic Hassan Noman",
          "SINA Clinic Jamali Goth",
          "SINA Clinic Machar Colony",
          "SINA Clinic Saindad Goth",
          "SINA Clinic Yousuf Goth",
          "SINA Hingora Goth",
          "SINA Sukhia Goth"
        ]
      },
      {
        "name": "Gujro Zone B",
        "centres": [
          "BHU Lasi Goth",
          "Exp Dispensary Faqeera Goth",
          "Exp Dispensary Gareebabad",
          "Exp Dispensary Junejo Colony",
          "Exp Dispensary Junjar Goth",
          "Exp Dispensary Machar Colony",
          "Exp Dispensary Yasrab Goth",
          "Imam Basri Hospital",
          "Insaaf Medical Center",
          "Jannat Gul Dispensary",
          "Koohi Goth Hospital",
          "Nisa Maternity Home",
          "SINA Clinic Hassan Noman",
          "SINA Clinic Jamali Goth",
          "SINA Clinic Machar Colony",
          "SINA Clinic Saindad Goth",
          "SINA Clinic Yousuf Goth",
          "SINA Hingora Goth",
          "SINA Sukhia Goth"
        ]
      },
      {
        "name": "Gujro Zone C",
        "centres": [
          "BHU Lasi Goth",
          "Exp Dispensary Faqeera Goth",
          "Exp Dispensary Gareebabad",
          "Exp Dispensary Junejo Colony",
          "Exp Dispensary Junjar Goth",
          "Exp Dispensary Machar Colony",
          "Exp Dispensary Yasrab Goth",
          "Imam Basri Hospital",
          "Insaaf Medical Center",
          "Jannat Gul Dispensary",
          "Koohi Goth Hospital",
          "Nisa Maternity Home",
          "SINA Clinic Hassan Noman",
          "SINA Clinic Jamali Goth",
          "SINA Clinic Machar Colony",
          "SINA Clinic Saindad Goth",
          "SINA Clinic Yousuf Goth",
          "SINA Hingora Goth",
          "SINA Sukhia Goth"
        ]
      },
      {
        "name": "Gujro Zone D",
        "centres": [
          "BHU Lasi Goth",
          "Exp Dispensary Faqeera Goth",
          "Exp Dispensary Gareebabad",
          "Exp Dispensary Junejo Colony",
          "Exp Dispensary Junjar Goth",
          "Exp Dispensary Machar Colony",
          "Exp Dispensary Yasrab Goth",
          "Imam Basri Hospital",
          "Insaaf Medical Center",
          "Jannat Gul Dispensary",
          "Koohi Goth Hospital",
          "Nisa Maternity Home",
          "SINA Clinic Hassan Noman",
          "SINA Clinic Jamali Goth",
          "SINA Clinic Machar Colony",
          "SINA Clinic Saindad Goth",
          "SINA Clinic Yousuf Goth",
          "SINA Hingora Goth",
          "SINA Sukhia Goth"
        ]
      },
      {
        "name": "Gujro Zone E",
        "centres": [
          "BHU Lasi Goth",
          "Exp Dispensary Faqeera Goth",
          "Exp Dispensary Gareebabad",
          "Exp Dispensary Junejo Colony",
          "Exp Dispensary Junjar Goth",
          "Exp Dispensary Machar Colony",
          "Exp Dispensary Yasrab Goth",
          "Imam Basri Hospital",
          "Insaaf Medical Center",
          "Jannat Gul Dispensary",
          "Koohi Goth Hospital",
          "Nisa Maternity Home",
          "SINA Clinic Hassan Noman",
          "SINA Clinic Jamali Goth",
          "SINA Clinic Machar Colony",
          "SINA Clinic Saindad Goth",
          "SINA Clinic Yousuf Goth",
          "SINA Hingora Goth",
          "SINA Sukhia Goth"
        ]
      }
    ]
  },
  "Karachi Korangi": {
    "Korangi Town": [
      {
        "name": "Bilal Colony-1",
        "centres": [
          "Jinnah Medical Hospital (Pvt)",
          "SGD Bilal Colony",
          "SINA Medical Centre Bilal Colony",
          "SINA Medical Centre Mehran Town"
        ]
      },
      {
        "name": "Nasir Colony-2",
        "centres": [
          "Fazil.e.Ilahi Hospital",
          "Sir Syed"
        ]
      },
      {
        "name": "Chakra Goth-3",
        "centres": [
          "BHU 48E",
          "Creek General Hospital",
          "SINA Clinic Chakra Goth"
        ]
      },
      {
        "name": "Silvar Town-4",
        "centres": [
          "Chiniot General Hospital",
          "Emergency Center Korangi 11/2",
          "MCH Center"
        ]
      },
      {
        "name": "100-Quarters-5",
        "centres": [
          "BHU 50-A",
          "BHU Ward Unit-76"
        ]
      },
      {
        "name": "Gulzar Colony-6",
        "centres": [
          "Unani Shifa Dawa khana"
        ]
      },
      {
        "name": "Korangi 33-7",
        "centres": [
          "Baldia Maternity Home",
          "BHU 33-C"
        ]
      },
      {
        "name": "Zaman Town-8",
        "centres": [
          "Govt Homeopathic Center Zaman Town"
        ]
      },
      {
        "name": "Hasrat Mohani-9",
        "centres": [
          "AK Ali Akbar Shah",
          "BHU 51B"
        ]
      },
      {
        "name": "Bhittai Colony-10",
        "centres": [
          "Indus Hospital",
          "International Medical Educational Trust",
          "Shaikh Saeed Memorial Korangi"
        ]
      }
    ],
    "Landhi Town": [
      {
        "name": "Bhutto Nagar-6",
        "centres": [
          "Bhutto Nagar-6"
        ]
      },
      {
        "name": "Khawaja Ajmeer Colony-7",
        "centres": [
          "Khawaja Ajmeer Colony-7"
        ]
      },
      {
        "name": "Landhi-8",
        "centres": [
          "Landhi-8"
        ]
      },
      {
        "name": "Awani Colony-9",
        "centres": [
          "Awani Colony-9"
        ]
      },
      {
        "name": "Burmi Colony-10",
        "centres": [
          "Burmi Colony-10"
        ]
      },
      {
        "name": "Korangi-11",
        "centres": [
          "Korangi-11"
        ]
      },
      {
        "name": "Sherabad-12",
        "centres": [
          "Sherabad-12"
        ]
      }
    ],
    "Shah Faisal Town": [
      {
        "name": "Natha Khan-1",
        "centres": [
          "KMC Maternity Home"
        ]
      },
      {
        "name": "Pak Sadat Colony-2",
        "centres": [
          "KMC Muhammad Ali Shah"
        ]
      },
      {
        "name": "Drigh Colony-3",
        "centres": [
          "Bhu Shah Faisal-1",
          "SGD Shah Faisal Colony",
          "Shoukat Omar Memorial"
        ]
      },
      {
        "name": "Reta Plot-4",
        "centres": [
          "Al-Mustafa Medical Center"
        ]
      },
      {
        "name": "Moria Khan-5",
        "centres": [
          "KMC MCH Moria Khan"
        ]
      },
      {
        "name": "Rafa e Aam-6",
        "centres": [
          "Shamsi Hospital"
        ]
      },
      {
        "name": "Al-Falah-7",
        "centres": [
          "GD Jumma Goth",
          "MCH Alfalah"
        ]
      },
      {
        "name": "PAF-8",
        "centres": [
          "PAF Base Hospital"
        ]
      },
      {
        "name": "Drigh Road/Airport-9",
        "centres": [
          "CAA Medical Center",
          "Cant. General Hospital"
        ]
      }
    ],
    "Model Colony": [
      {
        "name": "Model Colony-1",
        "centres": [
          "Model Colony-1"
        ]
      },
      {
        "name": "Kala Board-2",
        "centres": [
          "Kala Board-2"
        ]
      },
      {
        "name": "Saudabad-3",
        "centres": [
          "Saudabad-3"
        ]
      },
      {
        "name": "Khokhrapar-4",
        "centres": [
          "Khokhrapar-4"
        ]
      }
    ]
  },
  "Karachi Malir": {
    "Bin Qasim": [
      {
        "name": "Ibrahim Hyderi - 1",
        "centres": [
          "Ibrahim Hyderi - 1"
        ]
      },
      {
        "name": "Rehri - 2",
        "centres": [
          "Rehri - 2"
        ]
      },
      {
        "name": "Cattle Colony - 3",
        "centres": [
          "Cattle Colony - 3"
        ]
      },
      {
        "name": "Qaidabad-4",
        "centres": [
          "Qaidabad-4"
        ]
      },
      {
        "name": "Landhi - 5",
        "centres": [
          "Landhi - 5"
        ]
      },
      {
        "name": "Gulshan-e-Hadeed - 6",
        "centres": [
          "Gulshan-e-Hadeed - 6"
        ]
      },
      {
        "name": "Ghaghar - 7",
        "centres": [
          "Ghaghar - 7"
        ]
      }
    ],
    "Gadap Town": [
      {
        "name": "Memon Goth - 1",
        "centres": [
          "Darul Sehat Hospital",
          "MCH Rotary Pehlwan Goth",
          "Seha Medical Centre",
          "SGD Hussain Hazara Goth"
        ]
      },
      {
        "name": "Darsano - 2",
        "centres": [
          "Darsano - 2"
        ]
      },
      {
        "name": "Gadap - 3",
        "centres": [
          "Gadap - 3"
        ]
      }
    ],
    "Landhi": [
      {
        "name": "Muzafrabad-1",
        "centres": [
          "Muzafrabad-1"
        ]
      },
      {
        "name": "Muslimabad-2",
        "centres": [
          "Muslimabad-2"
        ]
      },
      {
        "name": "Dawood Chorangi-3",
        "centres": [
          "Dawood Chorangi-3"
        ]
      },
      {
        "name": "Moniabad-4",
        "centres": [
          "Moniabad-4"
        ]
      },
      {
        "name": "Sharafi Goth-5",
        "centres": [
          "Sharafi Goth-5"
        ]
      }
    ],
    "Malir": [
      {
        "name": "Jaffer Tayyar-5",
        "centres": [
          "Jaffer Tayyar-5"
        ]
      },
      {
        "name": "Gharibabad- 6",
        "centres": [
          "Gharibabad- 6"
        ]
      },
      {
        "name": "Ghazi Brohi-7",
        "centres": [
          "Ghazi Brohi-7"
        ]
      },
      {
        "name": "UC 08 Malir Cantt",
        "centres": [
          "UC 08 Malir Cantt"
        ]
      }
    ]
  },
  "Karachi South": {
    "Lyari Town": [
      {
        "name": "Agra Taj-1",
        "centres": [
          "Family Welfare Center",
          "Family Welfare Center Navy"
        ]
      },
      {
        "name": "Daryabad-2",
        "centres": [
          "Women And Child Welfare Center"
        ]
      },
      {
        "name": "Nayabad-3",
        "centres": [
          "Memon Community Center"
        ]
      },
      {
        "name": "Khada Memon-4",
        "centres": [
          "AKHSP Kharadar",
          "Kharadar General Hospital"
        ]
      },
      {
        "name": "Baghdadi-5",
        "centres": [
          "Bilqees Edhi Centre",
          "GHAZI ABDUL QAYOOM DISPENSARY",
          "Miran Pir Maternity Home"
        ]
      },
      {
        "name": "Shah Baig Lane-6",
        "centres": [
          "Primary Health Care Centre",
          "Shahrukh Clinic"
        ]
      },
      {
        "name": "Bihar Colony-7",
        "centres": [
          "Behar Colony Dispesnary"
        ]
      },
      {
        "name": "Rangi Wara-8",
        "centres": [
          "Lyari General Hospital",
          "Mera Naka Dispensary"
        ]
      },
      {
        "name": "Singu Lane-9",
        "centres": [
          "Zohra Medical Center"
        ]
      },
      {
        "name": "Chakiwara-10",
        "centres": [
          "Ikhlas Medical Center",
          "SGD Chakiwara"
        ]
      },
      {
        "name": "Alama Iaqbal Colony -11",
        "centres": [
          "Lyari Maternity Home",
          "Usman Medical Center"
        ]
      }
    ],
    "Saddar Town": [
      {
        "name": "Old Haji Camp-1",
        "centres": [
          "Zaibun Nisa Hospital"
        ]
      },
      {
        "name": "Garden-2",
        "centres": [
          "Halar General Hospial"
        ]
      },
      {
        "name": "Kharadar-3",
        "centres": [
          "Bantva Hospital",
          "Kutiyana Memon Hospital"
        ]
      },
      {
        "name": "City Railway Colony",
        "centres": [
          "Burhani",
          "MCH Center Buneri"
        ]
      },
      {
        "name": "Nanak Wara-5",
        "centres": [
          "Bilquess Edhi Center",
          "Civil Hospital (Gyne Opd)",
          "Civil Hospital (Gyne Ward)",
          "Civil Hospital (Peads OPD)",
          "E.N Maternity Home",
          "Lady Dufferin Hospital",
          "Public Health School",
          "SG Services Hospital"
        ]
      },
      {
        "name": "Gazadarabad-6",
        "centres": [
          "Sindh Govt Police Hospital"
        ]
      },
      {
        "name": "Milat Nagar-7",
        "centres": [
          "KMC Gazdarabad General Hospital"
        ]
      },
      {
        "name": "Saddar-8",
        "centres": [
          "KMC E.D Dispensary Saddar",
          "Memon Hospital",
          "Mowloo Jumma Maternity Hospital",
          "Sobhraj Hospital"
        ]
      },
      {
        "name": "Civil Line",
        "centres": [
          "KMC MCH Center Hijrat Colony",
          "Naval Surgery (N.C.S)"
        ]
      },
      {
        "name": "Clifton-10",
        "centres": [
          "Hilal-e-Ahmar Hospital"
        ]
      },
      {
        "name": "Kehkashan-11",
        "centres": [
          "AKHSP Clifton",
          "AKU Clifton",
          "Altamash Hospital",
          "Dr Ziauddin Hospital Clifton Campus",
          "KMC Maternity Home Gizri",
          "South City Hosp"
        ]
      },
      {
        "name": "CCB.1",
        "centres": [
          "PNS SHIFA HOSPITAL"
        ]
      },
      {
        "name": "Karachi Cant",
        "centres": [
          "JPMC Hospital",
          "Karachi Adventist Hospital",
          "NICH HOSPITAL",
          "OMI Hospital"
        ]
      },
      {
        "name": "CCB.2",
        "centres": [
          "BHU Jamiat",
          "Sindh Govt Dispensary Dehli Punjab"
        ]
      },
      {
        "name": "CCB.3",
        "centres": [
          "PNS SHIFA HOSPITAL"
        ]
      },
      {
        "name": "CCB.4",
        "centres": [
          "Help Center Neelam Colony"
        ]
      }
    ]
  },
  "Karachi West": {
    "Orangi Town": [
      {
        "name": "Mominabad-1",
        "centres": [
          "KMC Bijli Nagar Dispensary",
          "Mominabad Hospital"
        ]
      },
      {
        "name": "Haryana Colony-2",
        "centres": [
          "Unique Hospital"
        ]
      },
      {
        "name": "Hanifabad-3",
        "centres": [
          "Al Razi Dispensary",
          "Uraban Health Centre-10"
        ]
      },
      {
        "name": "Muhammad Nagar-4",
        "centres": [
          "Dr. Umer Clinic"
        ]
      },
      {
        "name": "Madina Colony-5",
        "centres": [
          "Al-Mustafa Trust",
          "DUA E FATIMAHOSPITAL",
          "KMC Maternity Home(OutReach)"
        ]
      },
      {
        "name": "Ghaziabad-6",
        "centres": [
          "Good Smartian Hospital"
        ]
      },
      {
        "name": "Chishti Nagar-7",
        "centres": [
          "Govt. Dispensary Raja Tanveer Colony",
          "Sina Clinic.",
          "Sindh Govt Mansoor Nager Hospital"
        ]
      },
      {
        "name": "Bilal Colony-8",
        "centres": [
          "Khuwaja Gareeb Nawaz Dispensary"
        ]
      },
      {
        "name": "Islam Chowk-9",
        "centres": [
          "Dil-e-Zindagi Hospital"
        ]
      },
      {
        "name": "Gabol Colony-10",
        "centres": [
          "Urban Health Centre-15",
          "Well Check Health Center"
        ]
      },
      {
        "name": "Data Nagar-11",
        "centres": [
          "Qatar Hospital Old"
        ]
      },
      {
        "name": "Mujahidabad",
        "centres": [
          "Urban Health unit Aligarh"
        ]
      },
      {
        "name": "Baloch Goth-13",
        "centres": [
          "Al-Shifa Hospital",
          "BHU Baloch Goth",
          "PHC Khoso Chowk"
        ]
      }
    ],
    "West - Gadap": [
      {
        "name": "Songal - 5",
        "centres": [
          "36 Bedded Hospital Taisar Town",
          "Baqai Medical Center (Songal)",
          "BHU Tharo mengal Goth",
          "HELP MCH Center",
          "LERP DISPENSARI",
          "MALC",
          "Maymmar Dispensary",
          "MCH Abdullah Gabool Goth",
          "Mulla Hussain Dispensary",
          "SGD Khuda Ki Basti",
          "Sina Welfare-Khair muhammd Goth"
        ]
      },
      {
        "name": "Mymarabad-6",
        "centres": [
          "SGD 5/D Dispensary",
          "Sindh Govt Hospital"
        ]
      },
      {
        "name": "Yousif Goth - 7",
        "centres": [
          "Sina Welfare"
        ]
      },
      {
        "name": "Mangopir - 8",
        "centres": [
          "D.C. Dispensary Gul Muhammad",
          "MCH Manghopir",
          "RHC Manghopir",
          "SINA Clinic Pashtoon abad",
          "Sina Welfare-Khair Abad"
        ]
      }
    ]
  },
  "Karachi Keamari": {
    "Keamari Town": [
      {
        "name": "Bhutta Village-1",
        "centres": [
          "Bhutta Village-1"
        ]
      },
      {
        "name": "Sultanabad-2",
        "centres": [
          "Sultanabad-2"
        ]
      },
      {
        "name": "Kemari-3",
        "centres": [
          "Kemari-3"
        ]
      },
      {
        "name": "Baba Bhit-4",
        "centres": [
          "Baba Bhit-4"
        ]
      },
      {
        "name": "Machar Colony-5",
        "centres": [
          "MCH Center Akhter Colony"
        ]
      },
      {
        "name": "Maripur-6",
        "centres": [
          "Maripur-6"
        ]
      },
      {
        "name": "Sher Shah-7",
        "centres": [
          "Sher Shah-7"
        ]
      },
      {
        "name": "Gabopat-8",
        "centres": [
          "Gabopat-8"
        ]
      }
    ],
    "Baldia Town": [
      {
        "name": "Gulshan-e-Ghazi-1",
        "centres": [
          "Gulshan-e-Ghazi-1"
        ]
      },
      {
        "name": "Ittehad Town-2",
        "centres": [
          "Ittehad Town-2"
        ]
      },
      {
        "name": "Islam Nagar-3",
        "centres": [
          "Islam Nagar-3"
        ]
      },
      {
        "name": "Nai Abadi-4",
        "centres": [
          "Nai Abadi-4"
        ]
      },
      {
        "name": "Saeedabad-5",
        "centres": [
          "Green Belt Dispensary"
        ]
      },
      {
        "name": "Muslim Mujahid Colony",
        "centres": [
          "Muslim Mujahid Colony"
        ]
      },
      {
        "name": "Muhajir Camp-7",
        "centres": [
          "Muhajir Camp-7"
        ]
      },
      {
        "name": "Rasheedabad-8",
        "centres": [
          "Rasheedabad-8"
        ]
      }
    ],
    "S.I.T.E. Town": [
      {
        "name": "Pak Colony-1",
        "centres": [
          "MCH Center Akhter Colony"
        ]
      },
      {
        "name": "Old Golimar-2",
        "centres": [
          "AKHSP Garden Al-Zehra",
          "Fatmiya Hospital",
          "Holy Family",
          "Maternity Home Soldier Bazar",
          "Zainab Panjawani Hospital"
        ]
      },
      {
        "name": "Jananabad-3",
        "centres": [
          "Jananabad-3"
        ]
      },
      {
        "name": "Metrovil-4",
        "centres": [
          "Metrovil-4"
        ]
      },
      {
        "name": "Bawani Chali-5",
        "centres": [
          "Bawani Chali-5"
        ]
      }
    ]
  },
  "Kashmore": {
    "Kandhkot": [
      {
        "name": "Akhero",
        "centres": [
          "BHU Jihan Khan"
        ]
      },
      {
        "name": "Dari",
        "centres": [
          "BHU Dari"
        ]
      },
      {
        "name": "Daulatpur",
        "centres": [
          "BHU Ali Muhammad Khoso"
        ]
      },
      {
        "name": "Ghouspur",
        "centres": [
          "RHC Ghouspur"
        ]
      },
      {
        "name": "HAIBAT",
        "centres": [
          "Sherlabad"
        ]
      },
      {
        "name": "KAJILI",
        "centres": [
          "BHU M.Usman Khoso"
        ]
      },
      {
        "name": "Kandhkot-1",
        "centres": [
          "Outreach UC-1"
        ]
      },
      {
        "name": "Kandhkot-2",
        "centres": [
          "THQ Kandhkot-2"
        ]
      },
      {
        "name": "Kandhkot-3",
        "centres": [
          "THQ Kandhkot-3"
        ]
      },
      {
        "name": "Kandhkot-4",
        "centres": [
          "MCH kandhkot",
          "THQ Kandhkot-4"
        ]
      },
      {
        "name": "Kandhkot- Malir",
        "centres": [
          "BHU Abdul Qadir Chachar",
          "MALC Kandhkot"
        ]
      }
    ],
    "Kashmore": [
      {
        "name": "Badani",
        "centres": [
          "BHU Badani"
        ]
      },
      {
        "name": "Buxapur",
        "centres": [
          "RHC Buxapur"
        ]
      },
      {
        "name": "Kashmore Colony",
        "centres": [
          "GD Colony"
        ]
      },
      {
        "name": "GEEHALPUR",
        "centres": [
          "BHU Deen Muhammad Koash",
          "BHU Muhammad Khan Mazari"
        ]
      },
      {
        "name": "GOBLOW",
        "centres": [
          "GD Muhammad Akram"
        ]
      },
      {
        "name": "GUDDU",
        "centres": [
          "Wapda Hospital Guddo"
        ]
      },
      {
        "name": "GULANPUR",
        "centres": [
          "BHU Gullanpur",
          "GD sardaroo khoso"
        ]
      },
      {
        "name": "K S Ali Bilawal",
        "centres": [
          "GD Mando Khan Jakhrani",
          "GD Saif Din Jakhrani"
        ]
      },
      {
        "name": "KASHMORE 1",
        "centres": [
          "MCH Kashmore",
          "THQ Kashmore"
        ]
      },
      {
        "name": "KASHMORE 2",
        "centres": [
          "GD Mehrab Mazari"
        ]
      },
      {
        "name": "KHEWALI",
        "centres": [
          "BHU khewali"
        ]
      },
      {
        "name": "KUMB",
        "centres": [
          "BHU Kumb"
        ]
      },
      {
        "name": "R B CHACHER",
        "centres": [
          "GD khahi"
        ]
      },
      {
        "name": "SODHI",
        "centres": [
          "BHU Gull Muhammad",
          "GD M.Azeem Golo"
        ]
      },
      {
        "name": "ZORGARH",
        "centres": [
          "GD Ghous Bux",
          "MCH Malguzar suhriyani"
        ]
      }
    ],
    "Tangwani": [
      {
        "name": "CHEEL",
        "centres": [
          "GD ILLAHI BUX KHOSO"
        ]
      },
      {
        "name": "DUNIAPUR",
        "centres": [
          "GD Nawab Khan Dahani"
        ]
      },
      {
        "name": "GULWALI",
        "centres": [
          "BHU Pir Jan Bajkani",
          "RHC Tangwani"
        ]
      },
      {
        "name": "JAMAL",
        "centres": [
          "GD Rahmat Khan Bijarani"
        ]
      },
      {
        "name": "KARAMPUR",
        "centres": [
          "BHU Diyani",
          "GD Nasrullah Khan Bijarani",
          "RHC Karampur"
        ]
      },
      {
        "name": "Lalao",
        "centres": [
          "BHU ABDUL QADIR BHAYO"
        ]
      },
      {
        "name": "Lashari UC",
        "centres": [
          "BHU Saeed Khan Rind"
        ]
      },
      {
        "name": "RESALDAR",
        "centres": [
          "BHU Rasaldar",
          "GD 27 Mile"
        ]
      },
      {
        "name": "SAIFAL",
        "centres": [
          "Abdul Razzaque Suhandro",
          "BHU Sher Muhammad Bijarani",
          "GD Shabeer Abad"
        ]
      },
      {
        "name": "SOHLYANI",
        "centres": [
          "BHU Ghulam Serwer Sarki",
          "GD Hafeezullah Khoso",
          "GD Kajlo Khoso"
        ]
      },
      {
        "name": "Tangwani UC",
        "centres": [
          "BHU Bijar Khan Bijarani"
        ]
      }
    ]
  },
  "Khairpur": {
    "Faiz Ganj": [
      {
        "name": "Akri",
        "centres": [
          "BHU Khush Khair Mohammad",
          "BHU Plus Akri"
        ]
      },
      {
        "name": "Bhangu Behan",
        "centres": [
          "BHU Bhangu Behan"
        ]
      },
      {
        "name": "Karoondi",
        "centres": [
          "GD Karoondi"
        ]
      },
      {
        "name": "Kindyari",
        "centres": [
          "BHU Baseero",
          "BHU Zafar Abad"
        ]
      },
      {
        "name": "Kot laloo",
        "centres": [
          "BHU Plus Ghulam Nabi Rajpar"
        ]
      },
      {
        "name": "Pacca Chang",
        "centres": [
          "BHU Araro",
          "BHU Niaz Abad",
          "RHC Faiz Ganj"
        ]
      },
      {
        "name": "Raza abad",
        "centres": [
          "BHU Mohammad Ramzan Mullo"
        ]
      },
      {
        "name": "KHUSH KHAIR MOHAMMAD",
        "centres": [
          "KHUSH KHAIR MOHAMMAD"
        ]
      },
      {
        "name": "NAGAR KHAN SHAR",
        "centres": [
          "NAGAR KHAN SHAR"
        ]
      },
      {
        "name": "PUNHAL KHAN",
        "centres": [
          "PUNHAL KHAN"
        ]
      },
      {
        "name": "SHOUKAT KHAN",
        "centres": [
          "SHOUKAT KHAN"
        ]
      },
      {
        "name": "UMMAN",
        "centres": [
          "UMMAN"
        ]
      }
    ],
    "Gambat": [
      {
        "name": "Agra",
        "centres": [
          "BHU Razi Dero",
          "RHC Agra"
        ]
      },
      {
        "name": "Belharo",
        "centres": [
          "BHU Belharo"
        ]
      },
      {
        "name": "Gambat-1",
        "centres": [
          "GD Arab Phull"
        ]
      },
      {
        "name": "Gambat-2",
        "centres": [
          "GIMS Gambat"
        ]
      },
      {
        "name": "Kamaldero",
        "centres": [
          "BHU Kamal Dero",
          "BHU Saidi Lower"
        ]
      },
      {
        "name": "Khemtia",
        "centres": [
          "BHU Kharal Abad"
        ]
      },
      {
        "name": "Khuhra",
        "centres": [
          "BHU Plus Khuhra",
          "BHULarrhi"
        ]
      },
      {
        "name": "Ripri",
        "centres": [
          "BHU Ripri"
        ]
      },
      {
        "name": "Jado Wahan",
        "centres": [
          "BHU Jado Wahan",
          "GD Faqeer Muhammad lakho",
          "GD Ghulam Jaffar Jamro"
        ]
      },
      {
        "name": "DARAZA",
        "centres": [
          "BHU Razi Dero",
          "RHC Agra"
        ]
      },
      {
        "name": "MUNWERABAD",
        "centres": [
          "MUNWERABAD"
        ]
      },
      {
        "name": "SALEEM KHARAL",
        "centres": [
          "SALEEM KHARAL"
        ]
      },
      {
        "name": "RAZI DERO",
        "centres": [
          "BHU Kamal Dero",
          "BHU Saidi Lower"
        ]
      }
    ],
    "Khairpur": [
      {
        "name": "Babarloi",
        "centres": [
          "BHU Babarloi",
          "BHU Ubhri"
        ]
      },
      {
        "name": "Bhurgri",
        "centres": [
          "City Hospital",
          "Lady Willington"
        ]
      },
      {
        "name": "Bukhari",
        "centres": [
          "GD Dabbar"
        ]
      },
      {
        "name": "JELLANI",
        "centres": [
          "GD Faizabad"
        ]
      },
      {
        "name": "Khairpur- Khanpur",
        "centres": [
          "BHU Bago Matilo",
          "BHU T.Nazir Ali",
          "GD Kanpur"
        ]
      },
      {
        "name": "LUQMAN",
        "centres": [
          "MH Luqman"
        ]
      },
      {
        "name": "W.MASHYION",
        "centres": [
          "BHU Gagrri",
          "BHU Wada Machyoon"
        ]
      },
      {
        "name": "Mehar Ali",
        "centres": [
          "BHU Pir Mangio",
          "GD Auteri"
        ]
      },
      {
        "name": "GHARI MORI",
        "centres": [
          "BHU Shahladhani",
          "RHC Ghari Mori"
        ]
      },
      {
        "name": "Nizamani",
        "centres": [
          "BHU Phatt",
          "GD Mitho Mari",
          "MCHC Kausar"
        ]
      },
      {
        "name": "Shah Latif",
        "centres": [
          "Civil Hospital"
        ]
      },
      {
        "name": "Tando Masti",
        "centres": [
          "BHU Lal Bux Mangi",
          "BHU Tando Masti"
        ]
      },
      {
        "name": "Therhi",
        "centres": [
          "BHU Therhi"
        ]
      },
      {
        "name": "SHADI SHAHEED",
        "centres": [
          "Loung Fakeer",
          "Manghi Khan"
        ]
      },
      {
        "name": "Bugaro",
        "centres": [
          "City Hospital",
          "Lady Willington"
        ]
      },
      {
        "name": "Pir Mangio",
        "centres": [
          "BHU Phatt",
          "GD Mitho Mari",
          "MCHC Kausar"
        ]
      },
      {
        "name": "Shah ladhani",
        "centres": [
          "Civil Hospital"
        ]
      },
      {
        "name": "Tando Nazar Ali",
        "centres": [
          "BHU Lal Bux Mangi",
          "BHU Tando Masti"
        ]
      },
      {
        "name": "Ubhri",
        "centres": [
          "City Hospital",
          "Lady Willington"
        ]
      }
    ],
    "Kingri": [
      {
        "name": "Ahmedpur",
        "centres": [
          "BHU Mahesar Wada",
          "BHU Plus Ahmed Pur"
        ]
      },
      {
        "name": "Drib Mehar Shah",
        "centres": [
          "BHU Plus Drib Mehar Shah"
        ]
      },
      {
        "name": "Hadal Shah",
        "centres": [
          "BHU Hadal Shah"
        ]
      },
      {
        "name": "Kolab Jial",
        "centres": [
          "BHU Kolab Jial"
        ]
      },
      {
        "name": "Kot Mir Mohammed",
        "centres": [
          "BHU Plus Kot Mir Mohammed"
        ]
      },
      {
        "name": "Manghan Wari",
        "centres": [
          "BHU Manghan Wari",
          "BHU Plus Rahooja"
        ]
      },
      {
        "name": "Noorpur",
        "centres": [
          "BHU Bahar Larik",
          "BHU Phori Chandio"
        ]
      },
      {
        "name": "Pirjogoth",
        "centres": [
          "MCHC Pir jo goath",
          "RHC Pir Jo Goth"
        ]
      },
      {
        "name": "Piryalo",
        "centres": [
          "BHU Plus Piryalo"
        ]
      },
      {
        "name": "Sadar Ji Bhatyoon",
        "centres": [
          "BHU Sadar Ji Bhatyoon"
        ]
      },
      {
        "name": "LAL BUX KANDHRO",
        "centres": [
          "LAL BUX KANDHRO"
        ]
      },
      {
        "name": "PIR BADAL SHER",
        "centres": [
          "BHU Hadal Shah"
        ]
      },
      {
        "name": "RAHOOJA KINGRI",
        "centres": [
          "RAHOOJA KINGRI"
        ]
      },
      {
        "name": "ULRA",
        "centres": [
          "ULRA"
        ]
      },
      {
        "name": "WADA MAHESAR",
        "centres": [
          "WADA MAHESAR"
        ]
      }
    ],
    "Kot Diji": [
      {
        "name": "BAFHO",
        "centres": [
          "BHU Amir Ali Shah"
        ]
      },
      {
        "name": "DEH SOHOO",
        "centres": [
          "BHU Mithri Center"
        ]
      },
      {
        "name": "Faqeerabad",
        "centres": [
          "BHU Imam Bux Palh",
          "GD Faqeerabad"
        ]
      },
      {
        "name": "Fatehpur",
        "centres": [
          "BHU Karam Ali"
        ]
      },
      {
        "name": "Jhando Mashakh",
        "centres": [
          "Jan Muhammad Wandiar",
          "MCHC Saeed Nangraja"
        ]
      },
      {
        "name": "Jiskani",
        "centres": [
          "BHU Jiskani",
          "BHU Nawab wasan"
        ]
      },
      {
        "name": "Kot Diji UC",
        "centres": [
          "MCHC Kot Diji",
          "THQ Kotdiji"
        ]
      },
      {
        "name": "Kumb UC",
        "centres": [
          "BHU Arab Machi",
          "BHU Kumb Center"
        ]
      },
      {
        "name": "Layari",
        "centres": [
          "BHU Hussain Abad",
          "BHU Layari"
        ]
      },
      {
        "name": "Mohbat wah",
        "centres": [
          "GD Bakhar Kansera",
          "RHC Atta Muhammad hami"
        ]
      },
      {
        "name": "Naseer Fakeer",
        "centres": [
          "BHU Babar Wada",
          "BHU Bago Daro",
          "GD Naseer Faqeer"
        ]
      },
      {
        "name": "ALI MOHD MACHI",
        "centres": [
          "ALI MOHD MACHI"
        ]
      },
      {
        "name": "ATTA MOHD HAMI",
        "centres": [
          "ATTA MOHD HAMI"
        ]
      },
      {
        "name": "GOONDAHIRO",
        "centres": [
          "GOONDAHIRO"
        ]
      },
      {
        "name": "MALHAR KHASKHALI",
        "centres": [
          "MALHAR KHASKHALI"
        ]
      },
      {
        "name": "RAHEEM BUX WASSAN",
        "centres": [
          "RAHEEM BUX WASSAN"
        ]
      },
      {
        "name": "TALPUR WADA",
        "centres": [
          "TALPUR WADA"
        ]
      }
    ],
    "Nara": [
      {
        "name": "Chundiko",
        "centres": [
          "BHU Bachal Bhanbroo",
          "MCH Choundiko",
          "RHC Choundiko",
          "RHC Nara Gate"
        ]
      },
      {
        "name": "Khanwari",
        "centres": [
          "BHU Pir Bux Gaho",
          "DCD Suleeman Aradin",
          "DCD Khanwari"
        ]
      },
      {
        "name": "Kot Jubo",
        "centres": [
          "GD Padheryo"
        ]
      },
      {
        "name": "Sikanderabad",
        "centres": [
          "BHU Sikanderabad"
        ]
      },
      {
        "name": "Tajjal",
        "centres": [
          "BHU Kathore",
          "BHU Tajjal",
          "GD M.V Tajjal"
        ]
      },
      {
        "name": "ABDUL QADIR SHAH",
        "centres": [
          "ABDUL QADIR SHAH"
        ]
      },
      {
        "name": "DODO FAKIR ARADIN",
        "centres": [
          "DODO FAKIR ARADIN"
        ]
      },
      {
        "name": "RABNAWAZ WASAN",
        "centres": [
          "RABNAWAZ WASAN"
        ]
      }
    ],
    "Sobho Dero": [
      {
        "name": "Gadeji",
        "centres": [
          "BHU Bhellar Wada",
          "BHU Plus Gadeji",
          "GD Satharja"
        ]
      },
      {
        "name": "Hingorja",
        "centres": [
          "RHC Hingorja"
        ]
      },
      {
        "name": "Madd",
        "centres": [
          "BHU Lakha Wada",
          "BHU Razal Memon"
        ]
      },
      {
        "name": "Pir Hayat Shah",
        "centres": [
          "BHU Pir Hayat Shah",
          "BHU Tando Mir Karam"
        ]
      },
      {
        "name": "Ranipur",
        "centres": [
          "RHC Rani Pur"
        ]
      },
      {
        "name": "Rasoolabad",
        "centres": [
          "BHU Bachal Bhambhro",
          "BHU Rukrani"
        ]
      },
      {
        "name": "Sami",
        "centres": [
          "BHU Plus Sami",
          "BHU Khaleefo Hurriyah",
          "BHU New Goth Sahito"
        ]
      },
      {
        "name": "Sobhodero UC",
        "centres": [
          "RHC Sobhodero"
        ]
      },
      {
        "name": "Saghyoon",
        "centres": [
          "BHU Plus Saghyoon"
        ]
      },
      {
        "name": "ABDUL KAREEM KHURAL",
        "centres": [
          "ABDUL KAREEM KHURAL"
        ]
      },
      {
        "name": "MUHAMMAD TAHIR KHURO",
        "centres": [
          "MUHAMMAD TAHIR KHURO"
        ]
      },
      {
        "name": "SETHARJA BALA",
        "centres": [
          "SETHARJA BALA"
        ]
      },
      {
        "name": "THATTI",
        "centres": [
          "THATTI"
        ]
      }
    ],
    "Thari Mirwah": [
      {
        "name": "Baki Khan",
        "centres": [
          "BHU Kharrah"
        ]
      },
      {
        "name": "Bozdar Wada",
        "centres": [
          "BHU Bozdar Wada"
        ]
      },
      {
        "name": "Deparja UC",
        "centres": [
          "GD Deparja"
        ]
      },
      {
        "name": "Handyari",
        "centres": [
          "GD Muhammad Daud",
          "MCHC Handyari"
        ]
      },
      {
        "name": "Mandan",
        "centres": [
          "BHU Tarko",
          "GD Sutyaro"
        ]
      },
      {
        "name": "Mehar Vesar",
        "centres": [
          "BHU Dhoro"
        ]
      },
      {
        "name": "MOOSAN SHAH",
        "centres": [
          "BHU Kabir Khan Siyal"
        ]
      },
      {
        "name": "Sabar Khan Rind",
        "centres": [
          "BHU Dubi",
          "GD Mangho Fakir Sher"
        ]
      },
      {
        "name": "Setharja",
        "centres": [
          "MCHC Setharja"
        ]
      },
      {
        "name": "Thari Mir Wah",
        "centres": [
          "RHC Thari Mir wah"
        ]
      },
      {
        "name": "TANDO MIR ALI",
        "centres": [
          "BHU Tando Mir Ali"
        ]
      },
      {
        "name": "FAKIR GHULAM HYDER",
        "centres": [
          "FAKIR GHULAM HYDER"
        ]
      },
      {
        "name": "JAFFAR KHAN JALALANI",
        "centres": [
          "BHU Dubi",
          "GD Mangho Fakir Sher"
        ]
      },
      {
        "name": "KHARIRAH",
        "centres": [
          "RHC Thari Mir wah"
        ]
      },
      {
        "name": "PIR ABDUL QADIR SHAH",
        "centres": [
          "PIR ABDUL QADIR SHAH"
        ]
      },
      {
        "name": "RAEES HUSSAIN BUX",
        "centres": [
          "RAEES HUSSAIN BUX"
        ]
      },
      {
        "name": "SERI/HABIB PHULL",
        "centres": [
          "SERI/HABIB PHULL"
        ]
      },
      {
        "name": "SUTYARO",
        "centres": [
          "SUTYARO"
        ]
      }
    ]
  },
  "Larkana": {
    "Bakrani": [
      {
        "name": "Areeja",
        "centres": [
          "Maternity Home Bakrani",
          "RHC Areeja"
        ]
      },
      {
        "name": "Gerello",
        "centres": [
          "RHC Gerello"
        ]
      },
      {
        "name": "Mad Bahoo",
        "centres": [
          "BHU Mad Bahoo"
        ]
      },
      {
        "name": "Mahar Wada",
        "centres": [
          "BHU Sono Jatoi"
        ]
      },
      {
        "name": "Bakrani- Mehrab Pur",
        "centres": [
          "EPI Center Bakhar Karira"
        ]
      },
      {
        "name": "Naich",
        "centres": [
          "GD Heesib Chandio"
        ]
      },
      {
        "name": "Pathan",
        "centres": [
          "BHU Pathan"
        ]
      },
      {
        "name": "Purano Abad",
        "centres": [
          "BHU New Gud"
        ]
      },
      {
        "name": "Rasheed Wagan",
        "centres": [
          "GD Rasheed Wagan"
        ]
      }
    ],
    "Dokri": [
      {
        "name": "Badah-I",
        "centres": [
          "RHC Badeh"
        ]
      },
      {
        "name": "Badah-II",
        "centres": [
          "RHC Badeh"
        ]
      },
      {
        "name": "Baghi",
        "centres": [
          "BHU Moen-Jo-Daro"
        ]
      },
      {
        "name": "Dokri UC",
        "centres": [
          "GD Gujhar",
          "THQ Dokri"
        ]
      },
      {
        "name": "Karani",
        "centres": [
          "BHU Karani"
        ]
      },
      {
        "name": "Seehar",
        "centres": [
          "BHU Seehar"
        ]
      },
      {
        "name": "Tatri",
        "centres": [
          "BHU Veehar"
        ]
      },
      {
        "name": "Yaroo Lakhair",
        "centres": [
          "BHU Usman Kalhoro"
        ]
      }
    ],
    "Larkana": [
      {
        "name": "Akil",
        "centres": [
          "BHU Akil",
          "GD Agani"
        ]
      },
      {
        "name": "Bero Chandio",
        "centres": [
          "BHU Bero Chandio"
        ]
      },
      {
        "name": "Dhamrah",
        "centres": [
          "BHU Dhamrah"
        ]
      },
      {
        "name": "Larkano- Fateh Pur",
        "centres": [
          "BHU Fatehpur",
          "GD Kanga",
          "GD Mahota"
        ]
      },
      {
        "name": "Larkano- Kothi",
        "centres": [
          "BHU Kothi"
        ]
      },
      {
        "name": "Larkano- Phull",
        "centres": [
          "BHU Shahabad"
        ]
      },
      {
        "name": "Ratokot",
        "centres": [
          "GD Ratokot"
        ]
      },
      {
        "name": "Larkano-1",
        "centres": [
          "GD Gajan Pur"
        ]
      },
      {
        "name": "Larkano-2",
        "centres": [
          "CMC Children hosiptal EPI",
          "Hilal Ahmar shaikhzaid colony",
          "Shaikh zaid women hospital"
        ]
      },
      {
        "name": "Larkana-4",
        "centres": [
          "GD Nazar Mohalla"
        ]
      },
      {
        "name": "Larkana-3",
        "centres": [
          "Latif Colony EPI Center"
        ]
      },
      {
        "name": "Larkano-5",
        "centres": [
          "Civil Hospital OPD EPI center",
          "Old DHO EPI center"
        ]
      },
      {
        "name": "Larkano-6",
        "centres": [
          "Abbasi Medical center"
        ]
      },
      {
        "name": "Larkano-7",
        "centres": [
          "Social Security Disp"
        ]
      },
      {
        "name": "Larkano-8",
        "centres": [
          "Pakistani Chowk"
        ]
      },
      {
        "name": "Larkano-9",
        "centres": [
          "GD Murad Wahan"
        ]
      },
      {
        "name": "Larkano-10",
        "centres": [
          "GD Gajan Pur"
        ]
      },
      {
        "name": "Larkano-11",
        "centres": [
          "GD Gajan Pur"
        ]
      }
    ],
    "Ratodero": [
      {
        "name": "Bahman",
        "centres": [
          "BHU Izzat ji wandh"
        ]
      },
      {
        "name": "Banguldero",
        "centres": [
          "RHC Banguldero"
        ]
      },
      {
        "name": "Jumo Aghum",
        "centres": [
          "BHU Jumo Agham"
        ]
      },
      {
        "name": "Lashari",
        "centres": [
          "BHU-Lashari"
        ]
      },
      {
        "name": "Ratedero- Naudero",
        "centres": [
          "RHC Naudero"
        ]
      },
      {
        "name": "Pir Bux Bhutto",
        "centres": [
          "BHU khanwah",
          "MCHC Pir Bux Bhutto",
          "RHC Garhi khuda Bux bhutto"
        ]
      },
      {
        "name": "Ratodero-I",
        "centres": [
          "Outreach Center"
        ]
      },
      {
        "name": "Ratodero-II",
        "centres": [
          "Outreach Center"
        ]
      },
      {
        "name": "Saidu Dero",
        "centres": [
          "BHU Saidudero"
        ]
      },
      {
        "name": "Tayyab",
        "centres": [
          "BHU Masoo Dero"
        ]
      },
      {
        "name": "Waris Dino Machi",
        "centres": [
          "BHU Waris Dino Machi"
        ]
      }
    ]
  },
  "Matiari": {
    "Hala": [
      {
        "name": "Hala UC-1",
        "centres": [
          "Hala UC-1"
        ]
      },
      {
        "name": "Hala Old",
        "centres": [
          "Hala Old"
        ]
      },
      {
        "name": "Bhit Shah",
        "centres": [
          "Bhit Shah"
        ]
      },
      {
        "name": "Karam Khan Nizamani",
        "centres": [
          "Karam Khan Nizamani"
        ]
      },
      {
        "name": "Bhanoth",
        "centres": [
          "Bhanoth"
        ]
      },
      {
        "name": "10-Bhit Shah",
        "centres": [
          "10-Bhit Shah"
        ]
      },
      {
        "name": "11-Ajjan Shah",
        "centres": [
          "11-Ajjan Shah"
        ]
      },
      {
        "name": "12- Khandoo",
        "centres": [
          "12- Khandoo"
        ]
      },
      {
        "name": "13-Makhdoom Jo Landhiyon",
        "centres": [
          "13-Makhdoom Jo Landhiyon"
        ]
      },
      {
        "name": "14-Fateh Muhammad Shah Ajanani",
        "centres": [
          "14-Fateh Muhammad Shah Ajanani"
        ]
      }
    ],
    "Matiari": [
      {
        "name": "UC Matiari",
        "centres": [
          "UC Matiari"
        ]
      },
      {
        "name": "Sekhat",
        "centres": [
          "Sekhat"
        ]
      },
      {
        "name": "Bhao Khan Pathan",
        "centres": [
          "Bhao Khan Pathan"
        ]
      },
      {
        "name": "Oderolal Station",
        "centres": [
          "Oderolal Station"
        ]
      },
      {
        "name": "Oderolal Village",
        "centres": [
          "SGD Bhutta Village"
        ]
      },
      {
        "name": "Taj Pure",
        "centres": [
          "Taj Pure"
        ]
      },
      {
        "name": "Shah Aalam Shah Je Wasi",
        "centres": [
          "Shah Aalam Shah Je Wasi"
        ]
      },
      {
        "name": "Faqeer Nothiani",
        "centres": [
          "Faqeer Nothiani"
        ]
      },
      {
        "name": "TC Khyber",
        "centres": [
          "TC Khyber"
        ]
      },
      {
        "name": "16-Muhammad Hussain Hingoro",
        "centres": [
          "16-Muhammad Hussain Hingoro"
        ]
      },
      {
        "name": "17-Oderolal Station",
        "centres": [
          "17-Oderolal Station"
        ]
      },
      {
        "name": "20-Shahpur",
        "centres": [
          "20-Shahpur"
        ]
      },
      {
        "name": "21-Palijani",
        "centres": [
          "21-Palijani"
        ]
      },
      {
        "name": "22-Jeandal Kot",
        "centres": [
          "22-Jeandal Kot"
        ]
      },
      {
        "name": "24-Matiari",
        "centres": [
          "24-Matiari"
        ]
      },
      {
        "name": "25-Bau Dero/Shah Orangzaib Shah",
        "centres": [
          "25-Bau Dero/Shah Orangzaib Shah"
        ]
      },
      {
        "name": "27-Sher Muhammad Thora",
        "centres": [
          "27-Sher Muhammad Thora"
        ]
      },
      {
        "name": "30-Arzi Hakra",
        "centres": [
          "30-Arzi Hakra"
        ]
      }
    ],
    "Saeedabad": [
      {
        "name": "Zair Pir",
        "centres": [
          "Zair Pir"
        ]
      },
      {
        "name": "Saeedabad UC",
        "centres": [
          "Saeedabad UC"
        ]
      },
      {
        "name": "Bhale Dino Kaka",
        "centres": [
          "Bhale Dino Kaka"
        ]
      },
      {
        "name": "Shahmir Rahu",
        "centres": [
          "Shahmir Rahu"
        ]
      },
      {
        "name": "2-Abdul Wahid Burira",
        "centres": [
          "2-Abdul Wahid Burira"
        ]
      },
      {
        "name": "3-Old Saeedabad",
        "centres": [
          "3-Old Saeedabad"
        ]
      },
      {
        "name": "4-Faqeerabad",
        "centres": [
          "4-Faqeerabad"
        ]
      },
      {
        "name": "6-Sikandarabad",
        "centres": [
          "6-Sikandarabad"
        ]
      },
      {
        "name": "8-Muhammad Ramzan Unnar",
        "centres": [
          "8-Muhammad Ramzan Unnar"
        ]
      }
    ]
  },
  "Mirpur Khas": {
    "Digri": [
      {
        "name": "Digri- Digri",
        "centres": [
          "Taluka Hospital Digri City"
        ]
      },
      {
        "name": "Kangoro",
        "centres": [
          "BHU Village Kangoro"
        ]
      },
      {
        "name": "Mir Khuda Bux",
        "centres": [
          "BHU Vlge Abdullah khan jarwar"
        ]
      },
      {
        "name": "Pabban",
        "centres": [
          "BHU Village Paban Deh 160",
          "BHU Village Ramzan Junejo"
        ]
      },
      {
        "name": "Soofan Shah",
        "centres": [
          "BHU Village Abdul Qayoom Khari",
          "BHU Village Fakir Bashir Laghari"
        ]
      },
      {
        "name": "Tando Jan Muhammad",
        "centres": [
          "RHC Tando Jan Muhammad City"
        ]
      }
    ],
    "Hussain Bux Mari": [
      {
        "name": "Hussain Bux Mari- Khan",
        "centres": [
          "BHU Khan City",
          "BHU Village Patoyoon",
          "GD Muhammad Hassan Mari"
        ]
      },
      {
        "name": "Mirpur Old",
        "centres": [
          "BHU Lalchand Bungalow",
          "GD Village Imtiaz Panhwer"
        ]
      },
      {
        "name": "Turk Ali Mari",
        "centres": [
          "DCD Zahidabad",
          "GD Ratnabad",
          "Mohammad Medical collage Hospt"
        ]
      }
    ],
    "Jhuddo": [
      {
        "name": "Ahori",
        "centres": [
          "BHU Village Tando Kolachi",
          "GD Village Ahori"
        ]
      },
      {
        "name": "Dilawar Hussain",
        "centres": [
          "BHU Village Karam Ali Lehgari",
          "GD Ali Murad Bhatti"
        ]
      },
      {
        "name": "Fazal Bhambro",
        "centres": [
          "BHU Faiz Muhammad Bilalani",
          "BHU Village Fazal Bambhro"
        ]
      },
      {
        "name": "UC Jhudo",
        "centres": [
          "MCH Jhudo City",
          "RHC Jhudo City"
        ]
      },
      {
        "name": "Naukot",
        "centres": [
          "BHU Village Kot Mir Jan Muhd",
          "RHC Naukot city"
        ]
      },
      {
        "name": "Roshnabad",
        "centres": [
          "GD Village Roshanabad"
        ]
      }
    ],
    "Kot Ghulam Muhammad": [
      {
        "name": "Hashim Burgari",
        "centres": [
          "BHU Village Muhammad Hashim Bhugari",
          "GD Kachelo Station"
        ]
      },
      {
        "name": "Dengan",
        "centres": [
          "BHU Dengan Bhurgari City"
        ]
      },
      {
        "name": "Jawariasar",
        "centres": [
          "DC Disp Otaq Khan Bhugari"
        ]
      },
      {
        "name": "Kot Ghullam Mohd",
        "centres": [
          "THQH Kot Ghulam Muhammad City"
        ]
      },
      {
        "name": "Khudadad",
        "centres": [
          "BHU Village Dial Garh",
          "BHU Village Sikriyari"
        ]
      },
      {
        "name": "Mir Ghullam Hussain",
        "centres": [
          "BHU Kot Mir. S City",
          "GD Mir Ghulam Hussain"
        ]
      },
      {
        "name": "Mir Imam Bux",
        "centres": [
          "BHU Khachelo Farm"
        ]
      },
      {
        "name": "Hadi Bux",
        "centres": [
          "BHU Ubedullah Bhurgri",
          "GD Muhammad Ali Kalro"
        ]
      }
    ],
    "Mirpur Khas": [
      {
        "name": "Mirpurkhas-1",
        "centres": [
          "ST Tresa Hospital Hyd Road Mps"
        ]
      },
      {
        "name": "Mirpurkhas-2",
        "centres": [
          "BHU Hameedpura Colony Mirpurks",
          "MCH Hamidpura Colony Mirpurkhs"
        ]
      },
      {
        "name": "Mirpurkhas-3",
        "centres": [
          "Disable Center Lal Chandabad"
        ]
      },
      {
        "name": "Mirpurkhas-4",
        "centres": [
          "Ali Medical Center Adam Town",
          "Bhitai Dental Collage Hospital MPS",
          "Civil Hospital Mirpurkhas"
        ]
      },
      {
        "name": "Mirpurkhas-5",
        "centres": [
          "BHU Nawab Colony",
          "MCH Center Gaya Trust Shadman",
          "SMBB Charitable Hospital"
        ]
      },
      {
        "name": "Mirpurkhas-6",
        "centres": [
          "BHU Mehmoodabad",
          "BHU Satellite Town"
        ]
      },
      {
        "name": "Mirpurkhas-7",
        "centres": [
          "Chatan Hospital Mirpurkhas"
        ]
      },
      {
        "name": "Mirpurkhas-8",
        "centres": [
          "PTCL Dispensary",
          "Social Welfare Dispensary"
        ]
      }
    ],
    "Shujabad": [
      {
        "name": "Doulat Pur",
        "centres": [
          "BHU Village Doulat Laghari",
          "GD Village Kak Bungalow"
        ]
      },
      {
        "name": "Jhaluri",
        "centres": [
          "BHU Jhulori City",
          "CHC 78 Mori"
        ]
      },
      {
        "name": "Makhan Samoon",
        "centres": [
          "BHU Village Ghulam Hyder Shah",
          "BHU Village Khadim Ali Shah",
          "BHU Village Makhan Samon"
        ]
      },
      {
        "name": "Mirwah Gorchani",
        "centres": [
          "Al-Rehmat Medical Center",
          "BHU Village Khumbri",
          "MCH Mirwah City",
          "RHC Mirwah City"
        ]
      }
    ],
    "Sindhri": [
      {
        "name": "Hingorno",
        "centres": [
          "BHU Hingorno City",
          "BHU Village Din Muhammad Junejo"
        ]
      },
      {
        "name": "Sindhri- Balochabad",
        "centres": [
          "BHU Village Usman Junejo"
        ]
      },
      {
        "name": "Girhor Sharif",
        "centres": [
          "BHU Girhore Sharif City"
        ]
      },
      {
        "name": "Ismail Kumbhar",
        "centres": [
          "BHU Village Ismail Kunbhar"
        ]
      },
      {
        "name": "Kherao",
        "centres": [
          "BHU Village Muhram kanio"
        ]
      },
      {
        "name": "Phullahdiyoon",
        "centres": [
          "RHC Phulladyoun City"
        ]
      }
    ]
  },
  "Naushahro Feroze": {
    "Bhiria": [
      {
        "name": "Dalipota",
        "centres": [
          "BHU Lutuf Panhwar",
          "GD Dalipota"
        ]
      },
      {
        "name": "KOT BAHADUR",
        "centres": [
          "BHU Dali",
          "BHU Saeed khan lakho"
        ]
      },
      {
        "name": "MOLHAN",
        "centres": [
          "RHC Machur"
        ]
      },
      {
        "name": "QASIM KHAHI",
        "centres": [
          "BHU Kundha Khahi"
        ]
      },
      {
        "name": "UC Tharushah",
        "centres": [
          "RHC Tharushah (UC Tharushah)"
        ]
      },
      {
        "name": "UC Bhiria",
        "centres": [
          "RHC Bhiria"
        ]
      },
      {
        "name": "Bhiria Road",
        "centres": [
          "BHU Bhiria Road"
        ]
      },
      {
        "name": "Chaheen",
        "centres": [
          "BHU Chaheen"
        ]
      },
      {
        "name": "Ghair Gaju",
        "centres": [
          "BHU Ghair Gaju"
        ]
      },
      {
        "name": "Palahno",
        "centres": [
          "RHC Tharushah (UC Palahno"
        ]
      }
    ],
    "Kandiaro": [
      {
        "name": "Kandeyaro- Abad",
        "centres": [
          "THQ Kandiaro"
        ]
      },
      {
        "name": "Bhority",
        "centres": [
          "BHU Bhority"
        ]
      },
      {
        "name": "Darbelo",
        "centres": [
          "BHU Manjuth",
          "RHC Darbelo"
        ]
      },
      {
        "name": "Ghangra",
        "centres": [
          "BHU Bazid Pur"
        ]
      },
      {
        "name": "Ghulam shah",
        "centres": [
          "BHU Kandhar"
        ]
      },
      {
        "name": "Jam Norullah",
        "centres": [
          "BHU Mehmood Chandio"
        ]
      },
      {
        "name": "Kamal Dero",
        "centres": [
          "RHC Kamal Dero"
        ]
      },
      {
        "name": "Kandiaro UC",
        "centres": [
          "THQ Kandiaro"
        ]
      },
      {
        "name": "Khanwahan",
        "centres": [
          "BHU Khanwahan",
          "BHU Tunia Baka Shah"
        ]
      },
      {
        "name": "Mohbat daro jatoaie",
        "centres": [
          "BHU Mohbat Dero Jatoi"
        ]
      }
    ],
    "Mehrabpur": [
      {
        "name": "UC Halani",
        "centres": [
          "RHC Halani"
        ]
      },
      {
        "name": "Jaendo rajper",
        "centres": [
          "BHU Ali Sheer Chang",
          "BHU Jeando-Rajper"
        ]
      },
      {
        "name": "Kotri kabir",
        "centres": [
          "BHU Kotri Kabir",
          "GD Baharo Mulla"
        ]
      },
      {
        "name": "Lakha Road",
        "centres": [
          "BHU LAKHAROAD"
        ]
      },
      {
        "name": "Mehrabpur- Mehrabpur 1",
        "centres": [
          "GD New Town"
        ]
      },
      {
        "name": "Mehrabpur- Saeed Pur",
        "centres": [
          "GD New Town"
        ]
      },
      {
        "name": "Mehrabpur 2",
        "centres": [
          "GD New Town"
        ]
      },
      {
        "name": "Behlani",
        "centres": [
          "BHU Behlani"
        ]
      }
    ],
    "Moro": [
      {
        "name": "Daras",
        "centres": [
          "BHU Nandha Doger"
        ]
      },
      {
        "name": "Deparja",
        "centres": [
          "BHU Deparja"
        ]
      },
      {
        "name": "Fatoo Bilal",
        "centres": [
          "BHU Fatoo Balal"
        ]
      },
      {
        "name": "Gachero",
        "centres": [
          "BHU Mulo Ismail",
          "BHU Rahim Chand"
        ]
      },
      {
        "name": "Kahkat",
        "centres": [
          "GD Lundo",
          "RHC Sonahri Farm"
        ]
      },
      {
        "name": "Khairwah",
        "centres": [
          "BHU Murad Pahor",
          "BHU Qamaruddin Chandio"
        ]
      },
      {
        "name": "Lalia",
        "centres": [
          "BHU Puran"
        ]
      },
      {
        "name": "Moro 2",
        "centres": [
          "THQ Moro 2"
        ]
      },
      {
        "name": "Moro 3",
        "centres": [
          "THQ Moro 3"
        ]
      },
      {
        "name": "Moro-1",
        "centres": [
          "THQ Moro 1"
        ]
      },
      {
        "name": "New Jatoi",
        "centres": [
          "RHC New Jatoi"
        ]
      },
      {
        "name": "Manahaeen",
        "centres": [
          "BHU GUll Muhammad Jatoi",
          "GD Sadhuja"
        ]
      }
    ],
    "Naushahro Feroze": [
      {
        "name": "Abran",
        "centres": [
          "GD Abran"
        ]
      },
      {
        "name": "Bhambhri",
        "centres": [
          "BHU Kamil Rajper",
          "BHU Miran Pur"
        ]
      },
      {
        "name": "Dangeja",
        "centres": [
          "BHU Dangeja"
        ]
      },
      {
        "name": "Darya Khan Marri",
        "centres": [
          "RHC Darya Khan Mari"
        ]
      },
      {
        "name": "koor hassan",
        "centres": [
          "GD Attal Bohio"
        ]
      },
      {
        "name": "Masur Ji wah",
        "centres": [
          "BHU Masur Ji Wah"
        ]
      },
      {
        "name": "Mithiani",
        "centres": [
          "RHC Mithiani"
        ]
      },
      {
        "name": "UC Naushahro Feroze",
        "centres": [
          "BHU Baig Mohd Panhwar",
          "DHQ N.Feroze"
        ]
      },
      {
        "name": "Noor pur",
        "centres": [
          "BHU Pinjal Faqeer"
        ]
      },
      {
        "name": "Padidan",
        "centres": [
          "RHC Padidan"
        ]
      },
      {
        "name": "Phull",
        "centres": [
          "BHU Phull"
        ]
      }
    ]
  },
  "Sanghar": {
    "Jam Nawaz Ali": [
      {
        "name": "Berani",
        "centres": [
          "GD Abdullah Sangrasi",
          "MCHC Berani"
        ]
      },
      {
        "name": "Hot Wasan",
        "centres": [
          "BHU Amal Wassan",
          "GD Mehrab Liskani"
        ]
      },
      {
        "name": "UC Jam Nawaz Ali",
        "centres": [
          "GD Dilor Mori",
          "RHC Jam Nawaz Ali"
        ]
      },
      {
        "name": "Nau Abab",
        "centres": [
          "BHU Nauabad"
        ]
      },
      {
        "name": "84 JAMRAO",
        "centres": [
          "84 JAMRAO"
        ]
      },
      {
        "name": "BERANI (TC)",
        "centres": [
          "GD Abdullah Sangrasi",
          "MCHC Berani"
        ]
      },
      {
        "name": "BHIRO",
        "centres": [
          "BHIRO"
        ]
      },
      {
        "name": "JAM JANI",
        "centres": [
          "JAM JANI"
        ]
      },
      {
        "name": "JAM NAWAZ ALI (TC)",
        "centres": [
          "GD Dilor Mori",
          "RHC Jam Nawaz Ali"
        ]
      },
      {
        "name": "MANSOORA",
        "centres": [
          "MANSOORA"
        ]
      },
      {
        "name": "TILLA SHAH",
        "centres": [
          "TILLA SHAH"
        ]
      }
    ],
    "Khipro": [
      {
        "name": "Dhilyar",
        "centres": [
          "BHU Dhilyar"
        ]
      },
      {
        "name": "Hathungo",
        "centres": [
          "BHU Hathungo"
        ]
      },
      {
        "name": "Qazi Faiz Mohd",
        "centres": [
          "BHU Haji Hassan Hingoro",
          "BHU Qazi Wali M Rajar",
          "GD Adam Bhambhro"
        ]
      },
      {
        "name": "Kamil Hingoro",
        "centres": [
          "BHU Kamil Hingoro",
          "GD Jadam Dars"
        ]
      },
      {
        "name": "Khahi",
        "centres": [
          "BHU Hamzo Dars",
          "BHU Khahi"
        ]
      },
      {
        "name": "UC Khipro",
        "centres": [
          "THQ Khipro"
        ]
      },
      {
        "name": "Khori",
        "centres": [
          "BHU Kalu Rajer",
          "BHU Malook Mehar"
        ]
      },
      {
        "name": "Roonjho",
        "centres": [
          "BHU Bhit Bhaitee"
        ]
      },
      {
        "name": "Bilawal Hingorjo",
        "centres": [
          "BHU Bilawal Hingorjo",
          "BHU Yamin Hingoro"
        ]
      },
      {
        "name": "BANKO CHANIHO",
        "centres": [
          "BANKO CHANIHO"
        ]
      },
      {
        "name": "HAFIZ RAJAR",
        "centres": [
          "HAFIZ RAJAR"
        ]
      },
      {
        "name": "HAJI JAN MUHAMMAD",
        "centres": [
          "HAJI JAN MUHAMMAD"
        ]
      },
      {
        "name": "HAMZO KHAN DARS",
        "centres": [
          "HAMZO KHAN DARS"
        ]
      },
      {
        "name": "KHIPRO 1 (TC)",
        "centres": [
          "THQ Khipro"
        ]
      },
      {
        "name": "KHIPRO 2 (TC)",
        "centres": [
          "THQ Khipro"
        ]
      },
      {
        "name": "KHIPRO 3 (TC)",
        "centres": [
          "THQ Khipro"
        ]
      },
      {
        "name": "LOON KHAN",
        "centres": [
          "LOON KHAN"
        ]
      },
      {
        "name": "RANAK DAHAR",
        "centres": [
          "RANAK DAHAR"
        ]
      }
    ],
    "Sanghar": [
      {
        "name": "Kanhar",
        "centres": [
          "BHU Dhani Parto Rajpar"
        ]
      },
      {
        "name": "Kehore",
        "centres": [
          "GD DILBAR NIZAMANI"
        ]
      },
      {
        "name": "Khadwari",
        "centres": [
          "DCD Chak-8"
        ]
      },
      {
        "name": "Mian",
        "centres": [
          "GD Sabir Wasan"
        ]
      },
      {
        "name": "Sanghar 2",
        "centres": [
          "Civil Hospital Sanghar-2"
        ]
      },
      {
        "name": "Sethar Pir",
        "centres": [
          "BHU Muhib Junejo",
          "BHU Peromal"
        ]
      },
      {
        "name": "Chutiaryoon",
        "centres": [
          "BHU Chotiyaroon",
          "BHU Tando Mitha Khan"
        ]
      },
      {
        "name": "Gujree",
        "centres": [
          "BHU Gujree"
        ]
      },
      {
        "name": "Kandyari",
        "centres": [
          "BHU Bassi",
          "RHC Kandiyari"
        ]
      },
      {
        "name": "Sanghar 1",
        "centres": [
          "Civil Hospital Sanghar-1"
        ]
      },
      {
        "name": "Shah Sikandar Abad",
        "centres": [
          "BHU Awadh",
          "BHU Head Jamrao",
          "DC Dispensary Chak 41"
        ]
      },
      {
        "name": "BEHRAM BARI",
        "centres": [
          "BEHRAM BARI"
        ]
      },
      {
        "name": "BOBI",
        "centres": [
          "BOBI"
        ]
      },
      {
        "name": "DARO BAZAR",
        "centres": [
          "DARO BAZAR"
        ]
      },
      {
        "name": "DHORO JANIB",
        "centres": [
          "DHORO JANIB"
        ]
      },
      {
        "name": "JAKHRAO",
        "centres": [
          "JAKHRAO"
        ]
      },
      {
        "name": "KANDIARI (TC)",
        "centres": [
          "BHU Bassi",
          "RHC Kandiyari"
        ]
      },
      {
        "name": "KOT NAWAB",
        "centres": [
          "KOT NAWAB"
        ]
      },
      {
        "name": "KUNDHO",
        "centres": [
          "KUNDHO"
        ]
      },
      {
        "name": "PERUMAL (TC)",
        "centres": [
          "PERUMAL (TC)"
        ]
      },
      {
        "name": "PIR KIHORE",
        "centres": [
          "GD DILBAR NIZAMANI"
        ]
      },
      {
        "name": "SADHNO",
        "centres": [
          "SADHNO"
        ]
      },
      {
        "name": "SADRATH",
        "centres": [
          "SADRATH"
        ]
      },
      {
        "name": "SANGHAR-1 (MC)",
        "centres": [
          "Civil Hospital Sanghar-1"
        ]
      },
      {
        "name": "SANGHAR-2 (MC)",
        "centres": [
          "Civil Hospital Sanghar-2"
        ]
      },
      {
        "name": "TANDO MITHA KHAN (TC)",
        "centres": [
          "TANDO MITHA KHAN (TC)"
        ]
      },
      {
        "name": "KALLAR",
        "centres": [
          "BHU Dhani Parto Rajpar"
        ]
      }
    ],
    "Shahdadpur": [
      {
        "name": "Asgharabad",
        "centres": [
          "BHU Abdul Hakeem Bhanbhro",
          "BHU Khan Sanjrani"
        ]
      },
      {
        "name": "Barhoon",
        "centres": [
          "BHU Barhoon",
          "BHU Mula Hurmat"
        ]
      },
      {
        "name": "Jatia",
        "centres": [
          "FWC Jatia"
        ]
      },
      {
        "name": "Lundo",
        "centres": [
          "BHU Jaindo Rind",
          "BHU Lundo"
        ]
      },
      {
        "name": "Sarhari",
        "centres": [
          "BHU Kamil Keerio",
          "RHC Sarhari"
        ]
      },
      {
        "name": "Shahdadpur-IV",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "Shahdadpur-III",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "Shahdadpur-II",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "Shahpurchaker",
        "centres": [
          "RHC Shahpurchaker"
        ]
      },
      {
        "name": "Gul Muhammad Leghari",
        "centres": [
          "BHU Qazi Muhammad Juman Dahri.",
          "GD Din Muhammad Kakepoto",
          "GD Gohram Jamali"
        ]
      },
      {
        "name": "Maldasi",
        "centres": [
          "BHU Golo Pir",
          "GD Juma Village"
        ]
      },
      {
        "name": "Shahdadpur-I",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "Soomar Faqeer Higoro",
        "centres": [
          "BHU Mahar Ali Taluper",
          "BHU Maroof Dahri"
        ]
      },
      {
        "name": "BARACHARI",
        "centres": [
          "BHU Kamil Keerio",
          "RHC Sarhari"
        ]
      },
      {
        "name": "HABIBULLAH KERIO",
        "centres": [
          "HABIBULLAH KERIO"
        ]
      },
      {
        "name": "HAJI DAIM KHAN DHAMRAH",
        "centres": [
          "HAJI DAIM KHAN DHAMRAH"
        ]
      },
      {
        "name": "HAJI KORO KHAN UMRANI",
        "centres": [
          "HAJI KORO KHAN UMRANI"
        ]
      },
      {
        "name": "JATIA-1 (TC)",
        "centres": [
          "FWC Jatia"
        ]
      },
      {
        "name": "JATIA-2 (TC)",
        "centres": [
          "FWC Jatia"
        ]
      },
      {
        "name": "MURAD ALI RIND",
        "centres": [
          "MURAD ALI RIND"
        ]
      },
      {
        "name": "SARHARI (TC)",
        "centres": [
          "BHU Kamil Keerio",
          "RHC Sarhari"
        ]
      },
      {
        "name": "SHAH ALI NIZAMANI",
        "centres": [
          "SHAH ALI NIZAMANI"
        ]
      },
      {
        "name": "SHAHDADPUR-1 (MC)",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "SHAHDADPUR-2 (MC)",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "SHAHDADPUR-3 (MC)",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "SHAHDADPUR-4 (MC)",
        "centres": [
          "EPI Center Shahdadpur-1"
        ]
      },
      {
        "name": "SHAHMARDAN SHAH",
        "centres": [
          "SHAHMARDAN SHAH"
        ]
      },
      {
        "name": "SHAHPUR CHAKAR-1 (TC)",
        "centres": [
          "RHC Shahpurchaker"
        ]
      },
      {
        "name": "SHAHPUR CHAKAR-2 (TC)",
        "centres": [
          "RHC Shahpurchaker"
        ]
      }
    ],
    "Sinjhoro": [
      {
        "name": "Kurkali",
        "centres": [
          "BHU Mohammad Khan Rind",
          "BHU Rukkan Burira"
        ]
      },
      {
        "name": "Pritamabad",
        "centres": [
          "BHU Pritamabad"
        ]
      },
      {
        "name": "Pir Sibghatullah Shah",
        "centres": [
          "BHU Soomar Faqir Mehar",
          "GD Bobi",
          "GD Usman Nizamani"
        ]
      },
      {
        "name": "UC Sinjhoro",
        "centres": [
          "THQ sinjhoro"
        ]
      },
      {
        "name": "Jaffar Khan Lagari",
        "centres": [
          "BHU Kareem Dino Wasaan",
          "RHC Jaffar Khan Laghari"
        ]
      },
      {
        "name": "Jhol",
        "centres": [
          "BHU Raheemabad",
          "BHU Wali Muhammad Keerio",
          "RHC Jhol"
        ]
      },
      {
        "name": "Khadro",
        "centres": [
          "BHU 22 JAMRAO",
          "BHU Khadro"
        ]
      },
      {
        "name": "Shah Mardanabad",
        "centres": [
          "BHU 30 Chak",
          "BHU Jia Abad",
          "GD Rawatiani"
        ]
      },
      {
        "name": "21 JAMRAO",
        "centres": [
          "21 JAMRAO"
        ]
      },
      {
        "name": "22 JAMRAO",
        "centres": [
          "22 JAMRAO"
        ]
      },
      {
        "name": "30 JAMRAO",
        "centres": [
          "30 JAMRAO"
        ]
      },
      {
        "name": "ABBAS ABAD",
        "centres": [
          "ABBAS ABAD"
        ]
      },
      {
        "name": "AZEEM ABAD",
        "centres": [
          "BHU Pritamabad"
        ]
      },
      {
        "name": "BITOOR",
        "centres": [
          "BITOOR"
        ]
      },
      {
        "name": "GHUNDAN",
        "centres": [
          "GHUNDAN"
        ]
      },
      {
        "name": "JHOL (TC)",
        "centres": [
          "BHU Raheemabad",
          "BHU Wali Muhammad Keerio",
          "RHC Jhol"
        ]
      },
      {
        "name": "KHADRO (TC)",
        "centres": [
          "BHU 22 JAMRAO",
          "BHU Khadro"
        ]
      },
      {
        "name": "SINJHORO (MC)",
        "centres": [
          "THQ sinjhoro"
        ]
      },
      {
        "name": "WALI MUHAMMAD KEERIO",
        "centres": [
          "WALI MUHAMMAD KEERIO"
        ]
      },
      {
        "name": "SHAH MARDAN SHAH TC",
        "centres": [
          "BHU 30 Chak",
          "BHU Jia Abad",
          "GD Rawatiani"
        ]
      }
    ],
    "Tando Adam Khan": [
      {
        "name": "Kumb Darhoon",
        "centres": [
          "BHU Giddar Aphon",
          "BHU Kumb Darhoon",
          "DCD Mullan Makhan",
          "GD Baqer Nizamani"
        ]
      },
      {
        "name": "Manik Thaheem",
        "centres": [
          "BHU Bago Wadadani",
          "BHU Khairo Kaloi",
          "BHU Landhi",
          "DCD Ali Muhammad Thaheem"
        ]
      },
      {
        "name": "Mir Hassan Mari",
        "centres": [
          "BHU Ali Mardan Jamali",
          "BHU Mir Hassan Mari"
        ]
      },
      {
        "name": "Mitho Khoso",
        "centres": [
          "BHU Malook Jonejo"
        ]
      },
      {
        "name": "Tando Adam 1",
        "centres": [
          "Municipal EPI Center Tando Adam"
        ]
      },
      {
        "name": "Tando Adam 2",
        "centres": [
          "EPI Center UC-2 Tando Adam"
        ]
      },
      {
        "name": "Tando Adam 5",
        "centres": [
          "SSD-UC-5"
        ]
      },
      {
        "name": "Peero Faqir Shoro",
        "centres": [
          "BHU Peero Faqeer Shoro"
        ]
      },
      {
        "name": "Tando Adam 3",
        "centres": [
          "EPI Center Suleman Roshan",
          "THQ Tando Adam"
        ]
      },
      {
        "name": "Tando Adam 4",
        "centres": [
          "EPI Center Joharabad UC-4"
        ]
      },
      {
        "name": "DIN MUHAMMAD WARYAH",
        "centres": [
          "DIN MUHAMMAD WARYAH"
        ]
      },
      {
        "name": "FAKIR SHER MUHAMMAD DERO",
        "centres": [
          "FAKIR SHER MUHAMMAD DERO"
        ]
      },
      {
        "name": "GUJHRO",
        "centres": [
          "GUJHRO"
        ]
      },
      {
        "name": "HURBARI",
        "centres": [
          "HURBARI"
        ]
      },
      {
        "name": "TANDO ADAM 1 (MC)",
        "centres": [
          "Municipal EPI Center Tando Adam"
        ]
      },
      {
        "name": "TANDO ADAM 2 (MC)",
        "centres": [
          "EPI Center UC-2 Tando Adam"
        ]
      },
      {
        "name": "TANDO ADAM 3 (MC)",
        "centres": [
          "EPI Center Suleman Roshan",
          "THQ Tando Adam"
        ]
      },
      {
        "name": "TANDO ADAM 4 (MC)",
        "centres": [
          "EPI Center Joharabad UC-4"
        ]
      },
      {
        "name": "TANDO ADAM 5 (MC)",
        "centres": [
          "SSD-UC-5"
        ]
      },
      {
        "name": "TAYAB THAHEEM",
        "centres": [
          "BHU Bago Wadadani",
          "BHU Khairo Kaloi",
          "BHU Landhi",
          "DCD Ali Muhammad Thaheem"
        ]
      }
    ]
  },
  "Shaheed Benazirabad": {
    "Kazi Ahmed": [
      {
        "name": "Ahmed Bughio",
        "centres": [
          "BHU Nawab Wali Muhammad",
          "BHU Ramzan Rahu"
        ]
      },
      {
        "name": "TC Daulatpur",
        "centres": [
          "RHC Dolatpur"
        ]
      },
      {
        "name": "Habairi",
        "centres": [
          "BHU Habiri",
          "BHU Mitha Khan Jokhio"
        ]
      },
      {
        "name": "Khar",
        "centres": [
          "BHU Khar",
          "BHU Mukim Dahri"
        ]
      },
      {
        "name": "Manharo",
        "centres": [
          "BHU Ghullam Muhammad Jamali",
          "GD Manharo"
        ]
      },
      {
        "name": "Mirza Bagh",
        "centres": [
          "BHU Bado Mahar",
          "GD Allah Bux Kubar"
        ]
      },
      {
        "name": "TC Kazi Ahmed",
        "centres": [
          "BHU koat maqbol shah"
        ]
      },
      {
        "name": "TC Shahpur Jahania",
        "centres": [
          "GD Dodo Buhgio",
          "RHC Shahpur Jahania"
        ]
      },
      {
        "name": "Saeed Kando",
        "centres": [
          "GD Jhoojhan"
        ]
      },
      {
        "name": "Thatt",
        "centres": [
          "GD Baqar Sercheja",
          "GD Totti"
        ]
      },
      {
        "name": "Chariro",
        "centres": [
          "BHU Habiri",
          "BHU Mitha Khan Jokhio"
        ]
      },
      {
        "name": "Deran",
        "centres": [
          "Deran"
        ]
      },
      {
        "name": "Mehraro",
        "centres": [
          "BHU Ghullam Muhammad Jamali",
          "GD Manharo"
        ]
      },
      {
        "name": "Mir Muhammad Juno",
        "centres": [
          "Mir Muhammad Juno"
        ]
      },
      {
        "name": "Noor Muhammad Ja Quba",
        "centres": [
          "Noor Muhammad Ja Quba"
        ]
      },
      {
        "name": "Pat Peeral",
        "centres": [
          "Pat Peeral"
        ]
      },
      {
        "name": "Phulel",
        "centres": [
          "Phulel"
        ]
      },
      {
        "name": "Sawari",
        "centres": [
          "BHU Qutbi",
          "BHU Sansawari"
        ]
      },
      {
        "name": "Kazi Ahmed",
        "centres": [
          "BHU koat maqbol shah"
        ]
      },
      {
        "name": "San",
        "centres": [
          "San"
        ]
      }
    ],
    "Daur": [
      {
        "name": "TC Daur",
        "centres": [
          "Daur taluka hospital",
          "RHC Daur"
        ]
      },
      {
        "name": "60-Mile",
        "centres": [
          "BHU 60-Mile"
        ]
      },
      {
        "name": "Abul Hassan",
        "centres": [
          "GD Umar Sethar",
          "MCH Ghulam Muhammad Jamali"
        ]
      },
      {
        "name": "Amerji",
        "centres": [
          "BHU Karim Bux Dahri",
          "GD Mustque Ahmed Jatt"
        ]
      },
      {
        "name": "TC Bandhi",
        "centres": [
          "RHC Bandhi",
          "RHC Yar M Jamali"
        ]
      },
      {
        "name": "TC Bucheri",
        "centres": [
          "BHU Bucheri"
        ]
      },
      {
        "name": "Gupchani",
        "centres": [
          "BHU Gupchani",
          "GD Nawaz Dahri"
        ]
      },
      {
        "name": "Ismail Khan",
        "centres": [
          "BHU 68-Mori",
          "GD Major yar M.brohi"
        ]
      },
      {
        "name": "TC Jam Sahib",
        "centres": [
          "BHU Jam Sahib"
        ]
      },
      {
        "name": "Jamal Shah",
        "centres": [
          "BHU Asghar Abad",
          "GD Dourai Mahar"
        ]
      },
      {
        "name": "Jhooro Shar",
        "centres": [
          "GD Jhooro Shar"
        ]
      },
      {
        "name": "Obhari Sawri",
        "centres": [
          "GD Karim Bux Brohi",
          "GD Shafi Muhammad Gujjar"
        ]
      },
      {
        "name": "Suhelo",
        "centres": [
          "RHC Chak 3"
        ]
      },
      {
        "name": "Ghullam Hyder Shah",
        "centres": [
          "GD Ghazi Khan Burgari",
          "GD Soomar Khan Korae"
        ]
      },
      {
        "name": "Abdullah Khan Lund",
        "centres": [
          "GD Umar Sethar",
          "MCH Ghulam Muhammad Jamali"
        ]
      },
      {
        "name": "Hout Faqeer Rind",
        "centres": [
          "Hout Faqeer Rind"
        ]
      },
      {
        "name": "Jam Dattar",
        "centres": [
          "Jam Dattar"
        ]
      },
      {
        "name": "Khan Muhammad Jalbani",
        "centres": [
          "Khan Muhammad Jalbani"
        ]
      },
      {
        "name": "Mirza Farukh Baig",
        "centres": [
          "Mirza Farukh Baig"
        ]
      },
      {
        "name": "Nathiyani",
        "centres": [
          "Nathiyani"
        ]
      },
      {
        "name": "Sher Ali Shah",
        "centres": [
          "BHU Asghar Abad",
          "GD Dourai Mahar"
        ]
      },
      {
        "name": "Soomar Khan Jamali",
        "centres": [
          "BHU 68-Mori",
          "GD Major yar M.brohi"
        ]
      },
      {
        "name": "68 Mail",
        "centres": [
          "BHU 60-Mile"
        ]
      }
    ],
    "Nawabshah": [
      {
        "name": "Chanesar",
        "centres": [
          "BHU Trimor"
        ]
      },
      {
        "name": "Ghandtar",
        "centres": [
          "BHU Karam Ali Jamali",
          "GD Brohi Cotton Factory"
        ]
      },
      {
        "name": "Khair Shah",
        "centres": [
          "BHU Khair Shah",
          "GD Balooja kuba"
        ]
      },
      {
        "name": "Mureed Khan Zardari",
        "centres": [
          "Mureed Khan Zardari"
        ]
      },
      {
        "name": "Wali Muhammad Rind",
        "centres": [
          "Wali Muhammad Rind"
        ]
      },
      {
        "name": "HM Khoja-1",
        "centres": [
          "HM Khoja-1"
        ]
      },
      {
        "name": "HM Khoja-2",
        "centres": [
          "HM Khoja-2"
        ]
      },
      {
        "name": "HM Khoja-3",
        "centres": [
          "HM Khoja-3"
        ]
      },
      {
        "name": "HM Khoja-4",
        "centres": [
          "HM Khoja-4"
        ]
      },
      {
        "name": "HM Khoja-5",
        "centres": [
          "HM Khoja-5"
        ]
      },
      {
        "name": "HM Khoja-6",
        "centres": [
          "HM Khoja-6"
        ]
      },
      {
        "name": "HM Khoja-7",
        "centres": [
          "HM Khoja-7"
        ]
      },
      {
        "name": "HM Khoja-8",
        "centres": [
          "HM Khoja-8"
        ]
      },
      {
        "name": "HM Khoja-9",
        "centres": [
          "HM Khoja-9"
        ]
      },
      {
        "name": "HM Khoja-10",
        "centres": [
          "HM Khoja-10"
        ]
      },
      {
        "name": "Old Nawabshah-1",
        "centres": [
          "MCH Nawabshah",
          "New PMCH"
        ]
      },
      {
        "name": "Old Nawabshah-2",
        "centres": [
          "GD Faiz Muhammad Bangwar"
        ]
      },
      {
        "name": "Old Nawabshah-3",
        "centres": [
          "MD GAREEBABAD EPI CENTRE"
        ]
      },
      {
        "name": "Old Nawabshah-4",
        "centres": [
          "MCH Manuabad"
        ]
      },
      {
        "name": "Old Nawabshah-5",
        "centres": [
          "Railway dispensary"
        ]
      },
      {
        "name": "Old Nawabshah-6",
        "centres": [
          "SOCIAL SECURITY DISPENSARY"
        ]
      },
      {
        "name": "Old Nawabshah-7",
        "centres": [
          "GD LINE PAR"
        ]
      },
      {
        "name": "Old Nawabshah-8",
        "centres": [
          "MD Nadar Shah"
        ]
      },
      {
        "name": "Old Nawabshah-9",
        "centres": [
          "MCH Hussaini Road"
        ]
      }
    ],
    "Sakrand": [
      {
        "name": "Bhoora",
        "centres": [
          "BHU Budhal shah",
          "BHU Chattan Shah",
          "BHU Sukhiyo Manhejo"
        ]
      },
      {
        "name": "Dalel Dero",
        "centres": [
          "BHU Dino Shah",
          "BHU Majeed Keerio",
          "BHU Punhal Khan Chandio"
        ]
      },
      {
        "name": "Gohram Mari",
        "centres": [
          "GD Fatu Hal Zardari",
          "GD Ghanwar Maher",
          "GD Lakhat"
        ]
      },
      {
        "name": "Hamal Fakir",
        "centres": [
          "BHU Hamal Fakir",
          "BHU Mohd Khan Magsi"
        ]
      },
      {
        "name": "Karam Jamali",
        "centres": [
          "BHU Hassan Jamali",
          "BHU Karam Jamali",
          "RHC Mehar Ali Jamali"
        ]
      },
      {
        "name": "Khadhar",
        "centres": [
          "BHU Khabar Lakhmir",
          "GD Khadhar"
        ]
      },
      {
        "name": "Kumb Liman",
        "centres": [
          "GD Fazul Keerio",
          "GD Punhoon Khan Jamali"
        ]
      },
      {
        "name": "Marvi",
        "centres": [
          "BHU Mari Jalbani",
          "MCH Bachco Magsi"
        ]
      },
      {
        "name": "Sakrand- Mehrabpur",
        "centres": [
          "RHC Mehrabpur"
        ]
      },
      {
        "name": "TC Sakrand",
        "centres": [
          "THQ Sakrand-1"
        ]
      },
      {
        "name": "Bahawal Shah",
        "centres": [
          "Bahawal Shah"
        ]
      },
      {
        "name": "Fateh Pur",
        "centres": [
          "Fateh Pur"
        ]
      },
      {
        "name": "Hasan Jamali",
        "centres": [
          "BHU Hassan Jamali",
          "BHU Karam Jamali",
          "RHC Mehar Ali Jamali"
        ]
      },
      {
        "name": "Jamal Keerio",
        "centres": [
          "BHU Hamal Fakir",
          "BHU Mohd Khan Magsi"
        ]
      },
      {
        "name": "Morio Lakho",
        "centres": [
          "Morio Lakho"
        ]
      },
      {
        "name": "Punhal Khan Chandio",
        "centres": [
          "Punhal Khan Chandio"
        ]
      },
      {
        "name": "Sukhio Manahejo",
        "centres": [
          "Sukhio Manahejo"
        ]
      },
      {
        "name": "Majeed Keerio",
        "centres": [
          "Majeed Keerio"
        ]
      },
      {
        "name": "Maari Jalbani",
        "centres": [
          "BHU Hassan Jamali",
          "BHU Karam Jamali",
          "RHC Mehar Ali Jamali"
        ]
      }
    ]
  },
  "Shikarpur": {
    "Garhi Yasin": [
      {
        "name": "UC Garhi Yasin",
        "centres": [
          "RHC Garhi Yasin"
        ]
      },
      {
        "name": "Banbihar",
        "centres": [
          "BHU Kabalo"
        ]
      },
      {
        "name": "Dakhan",
        "centres": [
          "BHU Ali Khan",
          "BHU Dakhan"
        ]
      },
      {
        "name": "Nausharo Abro",
        "centres": [
          "BHU Dodo Detho"
        ]
      },
      {
        "name": "Waryaso",
        "centres": [
          "BHU Nabi Shah Wagan"
        ]
      },
      {
        "name": "Gahija",
        "centres": [
          "BHU Gaheja",
          "BHU Maroon Kakepota"
        ]
      },
      {
        "name": "Mirzapur",
        "centres": [
          "BHU Mirzapur"
        ]
      },
      {
        "name": "Madeji",
        "centres": [
          "Govt Hospital Madeji"
        ]
      },
      {
        "name": "Jindo Dero",
        "centres": [
          "U.C Secretary office"
        ]
      },
      {
        "name": "Chato Mangi",
        "centres": [
          "BHU Baddo",
          "BHU Chatto Mangi"
        ]
      },
      {
        "name": "Nim",
        "centres": [
          "BHU Jehangi Thaheem",
          "BHU Nim"
        ]
      },
      {
        "name": "M.Panah Odho",
        "centres": [
          "Fatima Health House"
        ]
      },
      {
        "name": "Amrote Sharif",
        "centres": [
          "BHU Amrot Sharif"
        ]
      }
    ],
    "Khanpur": [
      {
        "name": "Raheemabad",
        "centres": [
          "GD Sardarpur",
          "RHC Raheemabad"
        ]
      },
      {
        "name": "Thairo",
        "centres": [
          "GD Sardar Khadim Hussain"
        ]
      },
      {
        "name": "Mian Sahib",
        "centres": [
          "RHC Mian Sahib"
        ]
      },
      {
        "name": "Zarkhail",
        "centres": [
          "BHU Gari Budhal",
          "GD Haji Zangi Khan"
        ]
      },
      {
        "name": "Shabbirabad",
        "centres": [
          "BHU Haji Khan Kalhoro",
          "BHU Mahmood Panhwar",
          "G.D Qadir Bux Pahore",
          "RHC Napirabad"
        ]
      },
      {
        "name": "Mahmoudabad",
        "centres": [
          "BHU Mahmoudabad"
        ]
      },
      {
        "name": "Pir Bux Hujra",
        "centres": [
          "05 Bed Hospital"
        ]
      },
      {
        "name": "Gari Teigo",
        "centres": [
          "Wazir Ali Jatoi"
        ]
      },
      {
        "name": "Khanpur UC",
        "centres": [
          "RHC Khanpur"
        ]
      },
      {
        "name": "Gari Daakho",
        "centres": [
          "BHU Gari Dakho",
          "Jarar Pahore"
        ]
      }
    ],
    "Lakhi": [
      {
        "name": "UC Lakhi",
        "centres": [
          "THQ Lakhi"
        ]
      },
      {
        "name": "Wazirabad",
        "centres": [
          "BHU Wazirabad"
        ]
      },
      {
        "name": "Sher Kot",
        "centres": [
          "BHU Jamra"
        ]
      },
      {
        "name": "Ruk",
        "centres": [
          "BHU Jhali Kalwari",
          "BHU Ruk"
        ]
      },
      {
        "name": "Mungrani",
        "centres": [
          "BHU Jahan Khan",
          "BHU Soomar Goth"
        ]
      },
      {
        "name": "Abdu",
        "centres": [
          "BHU Abdu"
        ]
      },
      {
        "name": "Bhirkan",
        "centres": [
          "BHU Nimoro",
          "G.D Bhirkan",
          "GD Budh Goth"
        ]
      },
      {
        "name": "Chak",
        "centres": [
          "RHC Chak"
        ]
      },
      {
        "name": "Rustam",
        "centres": [
          "BHU Rustam",
          "GD Boriri"
        ]
      },
      {
        "name": "Sehwani",
        "centres": [
          "BHU Esso Tanwari"
        ]
      },
      {
        "name": "Taib",
        "centres": [
          "BHU Dhani Bux Malik",
          "BHU Taib"
        ]
      }
    ],
    "Shikarpur": [
      {
        "name": "Jano",
        "centres": [
          "Al-Khidmat Center"
        ]
      },
      {
        "name": "Karan",
        "centres": [
          "BHU Darwaish Kakepota",
          "H.Lutufullah B Memorial Hospital"
        ]
      },
      {
        "name": "Lodra",
        "centres": [
          "BHU Haji Khuwasti Brohi",
          "GD Hayat Junejo",
          "GD New Lalyoon"
        ]
      },
      {
        "name": "Jahanwah",
        "centres": [
          "Agha jan Akhtar"
        ]
      },
      {
        "name": "Shikarpur UC-1",
        "centres": [
          "United Memon Jamait Dispensary"
        ]
      },
      {
        "name": "Shikarpur UC-2",
        "centres": [
          "Ganga Bai Women Hospital"
        ]
      },
      {
        "name": "Shikarpur UC-3",
        "centres": [
          "Dr Pervaiz Yasir CLinic"
        ]
      },
      {
        "name": "Shikarpur UC-4",
        "centres": [
          "H.M.P Memorial center"
        ]
      },
      {
        "name": "Shikarpur UC-5",
        "centres": [
          "Shikarpur Hospital"
        ]
      },
      {
        "name": "Shikarpur UC-6",
        "centres": [
          "Hilal-e-Ahmar",
          "RBUT Hospital"
        ]
      },
      {
        "name": "Shikarpur UC-7",
        "centres": [
          "Social Security"
        ]
      },
      {
        "name": "Shikarpur UC-8",
        "centres": [
          "Christian Hospital"
        ]
      },
      {
        "name": "SultanKot",
        "centres": [
          "Feroze Begum",
          "RHC Sultan Kot"
        ]
      },
      {
        "name": "Jagan",
        "centres": [
          "BHU Jaggan"
        ]
      },
      {
        "name": "Humayun",
        "centres": [
          "BHU Hamayoon",
          "Govt Dispensary Sadhayo"
        ]
      }
    ]
  },
  "Sujawal": {
    "Jati": [
      {
        "name": "Begna Mori",
        "centres": [
          "BHU Begna Mori",
          "GD Tarr Khawaja"
        ]
      },
      {
        "name": "Gul Muhammad Baran",
        "centres": [
          "BHU Gul Muhammad Baran",
          "GD Nohria Abad"
        ]
      },
      {
        "name": "Kar Malik",
        "centres": [
          "BHU Boohar"
        ]
      },
      {
        "name": "Kothi",
        "centres": [
          "BHU Kothii"
        ]
      },
      {
        "name": "Mureed Khoso",
        "centres": [
          "BHU Mureed Khoso"
        ]
      },
      {
        "name": "Mughal Bean",
        "centres": [
          "THQ Jati"
        ]
      }
    ],
    "Mirpur Bathoro": [
      {
        "name": "Bannu",
        "centres": [
          "BHU Bannu",
          "BHU Rahooth"
        ]
      },
      {
        "name": "Darya Khan Soho",
        "centres": [
          "BHU-Darya Khan Soho",
          "GD Ahmed Khorr"
        ]
      },
      {
        "name": "Laikpur",
        "centres": [
          "BHU Laikpur"
        ]
      },
      {
        "name": "Mehar Shah",
        "centres": [
          "BHU-Mureed Jarejo"
        ]
      },
      {
        "name": "Bachal gugo",
        "centres": [
          "BHU Ali Muhammad Gugo"
        ]
      },
      {
        "name": "Daroo",
        "centres": [
          "BHU Kandhra",
          "RHC Darro"
        ]
      },
      {
        "name": "Jhok sharif",
        "centres": [
          "BHU Jhok Sharif"
        ]
      },
      {
        "name": "Mirpur Bathoro - Merpur bathro",
        "centres": [
          "THQ Mirpur Bathoro"
        ]
      }
    ],
    "Shah Bandar": [
      {
        "name": "Chuhar Jamali",
        "centres": [
          "RHC Chuhar Jamali"
        ]
      },
      {
        "name": "Jango Jalbani",
        "centres": [
          "BHU Jungo Jalbani",
          "DCD Chach Jahan Khan"
        ]
      },
      {
        "name": "Doulatpur",
        "centres": [
          "BHU Jeand Zangejo",
          "GD Hyder Shah"
        ]
      },
      {
        "name": "Goongani",
        "centres": [
          "BHU Goongani",
          "BHU Qadir Dino Shah"
        ]
      },
      {
        "name": "Ladiyoon",
        "centres": [
          "BHU Ladyun"
        ]
      }
    ],
    "Sujawal": [
      {
        "name": "Keenjhar",
        "centres": [
          "BHU Nodo Baran",
          "BHU Sayed Ghulam Mustafa Shah"
        ]
      },
      {
        "name": "Ali Bahar",
        "centres": [
          "BHU Sayed Qadir Dino Shah"
        ]
      },
      {
        "name": "Bajora",
        "centres": [
          "BHU Shah Nawaz Leghari",
          "BHU-Khair Bux Leghari"
        ]
      },
      {
        "name": "Bello",
        "centres": [
          "BHU Bello"
        ]
      },
      {
        "name": "Jaar",
        "centres": [
          "BHU Jaar",
          "GD Sher Ali Shah"
        ]
      },
      {
        "name": "Sujawal- Sujawal",
        "centres": [
          "THQ Sujawal"
        ]
      }
    ]
  },
  "Sukkur": {
    "New Sukkur": [
      {
        "name": "Hussain Arain",
        "centres": [
          "B H U Abad",
          "MCH Arain"
        ]
      },
      {
        "name": "Bagarji",
        "centres": [
          "G D Bagarji"
        ]
      },
      {
        "name": "Bachal Shah Miani",
        "centres": [
          "Bismillah Center",
          "RHC Buchal Shah Miani"
        ]
      },
      {
        "name": "Qureshi Goth",
        "centres": [
          "Bhatti Children Hospital"
        ]
      },
      {
        "name": "New Pind",
        "centres": [
          "GD Micro"
        ]
      },
      {
        "name": "Rahooja",
        "centres": [
          "S S Dispensary Rahooja"
        ]
      },
      {
        "name": "Golimar",
        "centres": [
          "Golimar"
        ]
      },
      {
        "name": "Tamachani",
        "centres": [
          "G D Naseerabad",
          "M P L Dreha"
        ]
      },
      {
        "name": "Dargah Badal Faqeer",
        "centres": [
          "Dargah Badal Faqeer"
        ]
      },
      {
        "name": "Indus",
        "centres": [
          "BHU New Pind"
        ]
      },
      {
        "name": "Bashirabad",
        "centres": [
          "Bashirabad"
        ]
      },
      {
        "name": "Maka Goth",
        "centres": [
          "Bhatti Children Hospital"
        ]
      },
      {
        "name": "Naserabad",
        "centres": [
          "Naserabad"
        ]
      },
      {
        "name": "Islam Colony",
        "centres": [
          "Islam Colony"
        ]
      },
      {
        "name": "Pir Murad Shah",
        "centres": [
          "Pir Murad Shah"
        ]
      },
      {
        "name": "Chona Batha",
        "centres": [
          "Chona Batha"
        ]
      },
      {
        "name": "Saedabad",
        "centres": [
          "Saedabad"
        ]
      },
      {
        "name": "Society",
        "centres": [
          "Society"
        ]
      },
      {
        "name": "Abad Lakha",
        "centres": [
          "Abad Lakha"
        ]
      },
      {
        "name": "City Point",
        "centres": [
          "City Point"
        ]
      }
    ],
    "Pano Akil": [
      {
        "name": "Baiji Sharif",
        "centres": [
          "BHU Haji Khan Chachar",
          "GD Baiji shareef"
        ]
      },
      {
        "name": "Dadloi",
        "centres": [
          "BHU Cheechro",
          "Gharko",
          "RHC Dadloi"
        ]
      },
      {
        "name": "Hingoro",
        "centres": [
          "BHU Hingoro"
        ]
      },
      {
        "name": "Junas",
        "centres": [
          "Maternity Home Junas"
        ]
      },
      {
        "name": "Mehran",
        "centres": [
          "THQ Pano Aqil"
        ]
      },
      {
        "name": "Mubarakpur",
        "centres": [
          "BHU Thikratho",
          "G.D Mubarakpur"
        ]
      },
      {
        "name": "Nindapur",
        "centres": [
          "BHU Hussain Kalwer",
          "GD Siyalabad"
        ]
      },
      {
        "name": "Nouraja",
        "centres": [
          "BHU Nouraja"
        ]
      },
      {
        "name": "Pano Aqel",
        "centres": [
          "Sakhi Baba Maternity Home"
        ]
      },
      {
        "name": "Sadhuja",
        "centres": [
          "BHU Samo Chachar"
        ]
      },
      {
        "name": "Sangi",
        "centres": [
          "BHU Nirch",
          "BHU Qasimpur"
        ]
      },
      {
        "name": "Sultanpur",
        "centres": [
          "BHU Sultanpur",
          "CMH Cantt",
          "Maternity Home Bhambo Malano"
        ]
      },
      {
        "name": "Bulla",
        "centres": [
          "Bulla"
        ]
      },
      {
        "name": "Cantoment",
        "centres": [
          "Cantoment"
        ]
      },
      {
        "name": "Drib",
        "centres": [
          "Drib"
        ]
      },
      {
        "name": "Manzoor Metlo",
        "centres": [
          "Manzoor Metlo"
        ]
      },
      {
        "name": "Mulla Ali",
        "centres": [
          "Mulla Ali"
        ]
      },
      {
        "name": "Mustafa Town",
        "centres": [
          "Mustafa Town"
        ]
      },
      {
        "name": "Nirch",
        "centres": [
          "Nirch"
        ]
      },
      {
        "name": "Panhwari",
        "centres": [
          "Panhwari"
        ]
      },
      {
        "name": "Pano Ghulam Ali",
        "centres": [
          "Pano Ghulam Ali"
        ]
      },
      {
        "name": "Rophar",
        "centres": [
          "Rophar"
        ]
      }
    ],
    "Rohri": [
      {
        "name": "Ali Wahan",
        "centres": [
          "GD Ali Wahan"
        ]
      },
      {
        "name": "Arore",
        "centres": [
          "BHU Arore",
          "BHU Dondako"
        ]
      },
      {
        "name": "Bedal Bekus",
        "centres": [
          "CWC Railway Hospital"
        ]
      },
      {
        "name": "Dhandhi",
        "centres": [
          "BHU Faqeerabad"
        ]
      },
      {
        "name": "Kandhra",
        "centres": [
          "RHC Kandhra"
        ]
      },
      {
        "name": "Loung Bhatti",
        "centres": [
          "BHU Tando thatti"
        ]
      },
      {
        "name": "Panhwar",
        "centres": [
          "BHU Dhubbar"
        ]
      },
      {
        "name": "PATNI",
        "centres": [
          "BHU Patni"
        ]
      },
      {
        "name": "Rohrii",
        "centres": [
          "Maternity Home",
          "Old Taluka Hospital Rohri",
          "THQ Rohri"
        ]
      },
      {
        "name": "Sangrar",
        "centres": [
          "RHC Trighathi"
        ]
      },
      {
        "name": "Trimonh",
        "centres": [
          "BHU darawahan",
          "BHU Kandri",
          "GD ABELO"
        ]
      },
      {
        "name": "Akbarpur",
        "centres": [
          "Akbarpur"
        ]
      },
      {
        "name": "Chuhara Mandi",
        "centres": [
          "Chuhara Mandi"
        ]
      },
      {
        "name": "Laiq Khan Jiskani",
        "centres": [
          "Laiq Khan Jiskani"
        ]
      },
      {
        "name": "Locoshed",
        "centres": [
          "Locoshed"
        ]
      },
      {
        "name": "Nasir Abad",
        "centres": [
          "Nasir Abad"
        ]
      },
      {
        "name": "Pir Ikhlas Shah",
        "centres": [
          "Pir Ikhlas Shah"
        ]
      },
      {
        "name": "Roshanabad",
        "centres": [
          "Roshanabad"
        ]
      },
      {
        "name": "Wah Burira",
        "centres": [
          "Wah Burira"
        ]
      },
      {
        "name": "Kotri Rohri",
        "centres": [
          "Maternity Home",
          "Old Taluka Hospital Rohri",
          "THQ Rohri"
        ]
      }
    ],
    "Salehpat": [
      {
        "name": "Lal joreo",
        "centres": [
          "G.D Sehta / Janoji"
        ]
      },
      {
        "name": "Salehpat- Salehpat",
        "centres": [
          "BHU salehpat"
        ]
      },
      {
        "name": "Trae",
        "centres": [
          "BHU Himmat Ali Shah/ Ghagro"
        ]
      },
      {
        "name": "RIAZABAD",
        "centres": [
          "RIAZABAD"
        ]
      },
      {
        "name": "WASS",
        "centres": [
          "WASS"
        ]
      },
      {
        "name": "REGISTAN MAMRO",
        "centres": [
          "REGISTAN MAMRO"
        ]
      },
      {
        "name": "JANUJI",
        "centres": [
          "JANUJI"
        ]
      },
      {
        "name": "KHABRI BHIT",
        "centres": [
          "KHABRI BHIT"
        ]
      }
    ],
    "Sukkur": [
      {
        "name": "New Goth",
        "centres": [
          "Bhatti Children Hospital"
        ]
      },
      {
        "name": "Adam Shah Colony",
        "centres": [
          "Adam Shah Colony"
        ]
      },
      {
        "name": "Kumbhar Mohallah",
        "centres": [
          "Kumbhar Mohallah"
        ]
      },
      {
        "name": "Masoom Shah",
        "centres": [
          "Masoom Shah"
        ]
      },
      {
        "name": "Old Sukkur",
        "centres": [
          "Old Sukkur"
        ]
      },
      {
        "name": "Shaikh Sheen",
        "centres": [
          "Shaikh Sheen"
        ]
      },
      {
        "name": "Shamsabad",
        "centres": [
          "Shamsabad"
        ]
      },
      {
        "name": "NOGAZ PIR",
        "centres": [
          "NOGAZ PIR"
        ]
      },
      {
        "name": "Ayub Gate",
        "centres": [
          "Ayub Gate"
        ]
      },
      {
        "name": "BARRAGE COLONY",
        "centres": [
          "BARRAGE COLONY"
        ]
      },
      {
        "name": "THERMAL",
        "centres": [
          "THERMAL"
        ]
      },
      {
        "name": "Clock Tower",
        "centres": [
          "Clock Tower"
        ]
      },
      {
        "name": "SHAH LATIF SUKKUR",
        "centres": [
          "SHAH LATIF SUKKUR"
        ]
      },
      {
        "name": "Dargah Qazi Baba",
        "centres": [
          "Dargah Qazi Baba"
        ]
      },
      {
        "name": "Baban Shah",
        "centres": [
          "Bismillah Center",
          "RHC Buchal Shah Miani"
        ]
      }
    ]
  },
  "Tando Allahyar": {
    "Chamber": [
      {
        "name": "Began Jarwar",
        "centres": [
          "BHU Koro Daidano",
          "BHU Shadiyon Walhari"
        ]
      },
      {
        "name": "Chamber-1",
        "centres": [
          "RHC Chamber"
        ]
      },
      {
        "name": "Dad Jarwar",
        "centres": [
          "GD Masso Bozdar",
          "GD Saeed Khan Laghari"
        ]
      },
      {
        "name": "Sanjar Chang",
        "centres": [
          "BHU Sanjar Chang"
        ]
      },
      {
        "name": "Chamber II",
        "centres": [
          "BHU Naseer Khan Laghari"
        ]
      }
    ],
    "Jhando Mari": [
      {
        "name": "Jhando Mari-01",
        "centres": [
          "BHU Jhando Mari"
        ]
      },
      {
        "name": "Payro Lund",
        "centres": [
          "THQ Pyaro Lund"
        ]
      },
      {
        "name": "Mirabad",
        "centres": [
          "GD Mirabad"
        ]
      },
      {
        "name": "Tando Soomro",
        "centres": [
          "BHU Tando Soomro"
        ]
      },
      {
        "name": "Misson",
        "centres": [
          "BHU Sultanabad Stand",
          "GD Sadiq Memon",
          "RHC Misson"
        ]
      },
      {
        "name": "Dassori",
        "centres": [
          "BHU Allah Rakhio Pathan",
          "BHU ShahNawaz Muhajir",
          "GD Usman Shah"
        ]
      }
    ],
    "Tando Allahyar": [
      {
        "name": "Dhigano Bozdar",
        "centres": [
          "BHU Digano Bozdar",
          "Bilqees Mushif hospital"
        ]
      },
      {
        "name": "Bukera Sharif",
        "centres": [
          "BHU Bukara Sharif"
        ]
      },
      {
        "name": "Pak Singhar",
        "centres": [
          "GD Darya Khan Hingoro",
          "GD Golo Halipoto",
          "GD Pak Singhar"
        ]
      },
      {
        "name": "Shaikh Moosa",
        "centres": [
          "BHU Ditto Kalro",
          "BHU Sultanabad Village"
        ]
      },
      {
        "name": "Nasar Pur",
        "centres": [
          "RHC Nasar Pur"
        ]
      },
      {
        "name": "Tando Allah Yar UC-01",
        "centres": [
          "Khanzada Hospital TAY"
        ]
      },
      {
        "name": "Tando Allah Yar UC-02",
        "centres": [
          "Civil Hospital Tando Allahyar-2"
        ]
      },
      {
        "name": "Tando Allah Yar UC-03",
        "centres": [
          "GD Ghulam Khan Sanjrani"
        ]
      },
      {
        "name": "Tando Allah Yar UC-04",
        "centres": [
          "Al Khidmat Hospital TAY"
        ]
      }
    ]
  },
  "Tando Muhammad Khan": {
    "Bulri Shah Karim": [
      {
        "name": "Saeed Khan Lund",
        "centres": [
          "BHU Saeed Khan Lund",
          "BHU Sehrani"
        ]
      },
      {
        "name": "Saeed Matto Shah",
        "centres": [
          "BHU Saeed Matto"
        ]
      },
      {
        "name": "Mulla Katyar",
        "centres": [
          "BHU Wasi Malook shah",
          "DCD Asgharabad Center"
        ]
      },
      {
        "name": "Bulrhi Shah Karim",
        "centres": [
          "BHU Ghulam Muhammad Jatt",
          "RHC Bulrhi shah Karim"
        ]
      },
      {
        "name": "Allahyar Turk",
        "centres": [
          "BHU Mulla Katyar",
          "DCD Allahyar Turk"
        ]
      },
      {
        "name": "Saeed Pur",
        "centres": [
          "BHU Saeed Pur",
          "DCD Suleman Soomro"
        ]
      },
      {
        "name": "Jinhaan Soomro",
        "centres": [
          "BHU Dadoo",
          "BHU Jinhan Soomro"
        ]
      }
    ],
    "Tando Ghulam Hyder": [
      {
        "name": "UC Tando Ghulam Hyder",
        "centres": [
          "BHU Tando Ghulam Hyder",
          "DCD Hakimani Sayed"
        ]
      },
      {
        "name": "Dandoo",
        "centres": [
          "DCD Koarho Lashari",
          "RHC Dandoo"
        ]
      },
      {
        "name": "Nazar Pur",
        "centres": [
          "BHU Nazar Pur",
          "DCD Sadiq Jagsi"
        ]
      },
      {
        "name": "Ghulam Shah Bagrhani",
        "centres": [
          "BHU Ghulam Shah Bagrhani"
        ]
      }
    ],
    "Tando Muhammad Khan": [
      {
        "name": "Sheikh Bhirkyo",
        "centres": [
          "BHU Sheikh Bhirkyo",
          "Unani Shifa Khana"
        ]
      },
      {
        "name": "Tando Saindad",
        "centres": [
          "DCD Tando Saindad",
          "Indus Medicale College",
          "RHC Rajo Nizaamani"
        ]
      },
      {
        "name": "T.M Khan-1",
        "centres": [
          "DHQ Hospital T.M Khan"
        ]
      },
      {
        "name": "Laakhat",
        "centres": [
          "BHU Naango Shah",
          "DCD Lakhat",
          "DCD Sain Bux Khoso"
        ]
      },
      {
        "name": "T.M Khan-3",
        "centres": [
          "Memon Charitable Hospital"
        ]
      },
      {
        "name": "T.M Khan-2",
        "centres": [
          "DHQ TMK 2"
        ]
      }
    ]
  },
  "Tharparkar": {
    "Chachro": [
      {
        "name": "Hirar",
        "centres": [
          "BHU Mubarik Rind"
        ]
      },
      {
        "name": "Kantio",
        "centres": [
          "BHU Kantio",
          "GD Aklayoon",
          "GD Goongio",
          "GD Morasio"
        ]
      },
      {
        "name": "Mithrio Charan",
        "centres": [
          "GD Khuhano Habib",
          "GD Nakario",
          "GD Ratanjo Tar"
        ]
      },
      {
        "name": "Rajoro",
        "centres": [
          "BHU Jadam Janjhi",
          "GD Dhakalo",
          "GD Gul Muhammad RInd",
          "GD Hayat Halepoto",
          "GD Rajoro"
        ]
      },
      {
        "name": "Saranghiar",
        "centres": [
          "BHU Samo Rind",
          "BHU Wahori Dora",
          "GD Sobhe Jo Tar",
          "MCHC Charnore"
        ]
      },
      {
        "name": "Tardos",
        "centres": [
          "BHU Sakario",
          "GD Karooro Bus Stop",
          "GD Tardos"
        ]
      },
      {
        "name": "Town Committee Chachro",
        "centres": [
          "GD Bhada Sandha",
          "GD Jalio Jo Tar",
          "THQ Chachro"
        ]
      },
      {
        "name": "Chachro Rural",
        "centres": [
          "GD Bhada Sandha",
          "GD Jalio Jo Tar",
          "THQ Chachro"
        ]
      },
      {
        "name": "Tar Hamir",
        "centres": [
          "Tar Hamir"
        ]
      },
      {
        "name": "Ratan Jo Tar",
        "centres": [
          "BHU Jadam Janjhi",
          "GD Dhakalo",
          "GD Gul Muhammad RInd",
          "GD Hayat Halepoto",
          "GD Rajoro"
        ]
      },
      {
        "name": "Dhaklo",
        "centres": [
          "Dhaklo"
        ]
      },
      {
        "name": "Charnore",
        "centres": [
          "GD Bhada Sandha",
          "GD Jalio Jo Tar",
          "THQ Chachro"
        ]
      },
      {
        "name": "Rawatsar",
        "centres": [
          "Rawatsar"
        ]
      },
      {
        "name": "Arabliyar",
        "centres": [
          "BHU Samo Rind",
          "BHU Wahori Dora",
          "GD Sobhe Jo Tar",
          "MCHC Charnore"
        ]
      },
      {
        "name": "Dhareendhro",
        "centres": [
          "GD Bhada Sandha",
          "GD Jalio Jo Tar",
          "THQ Chachro"
        ]
      }
    ],
    "Dahli": [
      {
        "name": "Dahali",
        "centres": [
          "GD Dhori",
          "GD Katha Ji Veri",
          "GD Salani"
        ]
      },
      {
        "name": "Gadaro",
        "centres": [
          "BHU Kankio",
          "GD Moosa Dhani"
        ]
      },
      {
        "name": "Jesse-jo par",
        "centres": [
          "GD Jesse-Jo-Par",
          "GD Kalario"
        ]
      },
      {
        "name": "Kheensar",
        "centres": [
          "BHU Khario Fazal",
          "GD Chapar Khosa",
          "GD Keetar",
          "RHC Kheensar"
        ]
      },
      {
        "name": "Laplo",
        "centres": [
          "GD Jadmani",
          "GD Mehran Varo",
          "GD Panat"
        ]
      },
      {
        "name": "Parno",
        "centres": [
          "GD Bagal",
          "GD Deenar Ji Veri",
          "GD Verhari"
        ]
      },
      {
        "name": "Tar Ahmed",
        "centres": [
          "GD Jetrar",
          "GD Rurgar"
        ]
      },
      {
        "name": "Kalario",
        "centres": [
          "BHU Kankio",
          "GD Moosa Dhani"
        ]
      },
      {
        "name": "Keetar",
        "centres": [
          "BHU Khario Fazal",
          "GD Chapar Khosa",
          "GD Keetar",
          "RHC Kheensar"
        ]
      },
      {
        "name": "Qamarhar",
        "centres": [
          "Qamarhar"
        ]
      },
      {
        "name": "Gul Muhammad Rahimoon",
        "centres": [
          "Gul Muhammad Rahimoon"
        ]
      },
      {
        "name": "Sajan Jo Par",
        "centres": [
          "GD Jesse-Jo-Par",
          "GD Kalario"
        ]
      },
      {
        "name": "Town Committee Kheme Jo Par",
        "centres": [
          "Town Committee Kheme Jo Par"
        ]
      },
      {
        "name": "Siyar",
        "centres": [
          "Siyar"
        ]
      }
    ],
    "Diplo": [
      {
        "name": "Bolhari",
        "centres": [
          "BHU Narhori Bolhari",
          "GD Dhakan",
          "GD Hathrai",
          "GD Patar Lund"
        ]
      },
      {
        "name": "Dabharo",
        "centres": [
          "BHU Mitho Dabharo",
          "GD Arbab Usman",
          "GD Doondio",
          "GD Doonhai",
          "GD Saro"
        ]
      },
      {
        "name": "Jhirmario",
        "centres": [
          "GD Dedsar",
          "GD Jhirmario",
          "GD Paneli",
          "GD Verhar"
        ]
      },
      {
        "name": "Sobhiar",
        "centres": [
          "BHU Arokhi",
          "BHU Verhijhap",
          "GD Malihar"
        ]
      },
      {
        "name": "Talo Jam",
        "centres": [
          "Talo Jam"
        ]
      },
      {
        "name": "Town Committee Diplo",
        "centres": [
          "Town Committee Diplo"
        ]
      },
      {
        "name": "Bhadoor",
        "centres": [
          "BHU Narhori Bolhari",
          "GD Dhakan",
          "GD Hathrai",
          "GD Patar Lund"
        ]
      }
    ],
    "Kaloi": [
      {
        "name": "Bhitaro",
        "centres": [
          "BHU Kot Arbab",
          "GD Arbab Zaffer Farm"
        ]
      },
      {
        "name": "Kaloi",
        "centres": [
          "BHU Kaloi",
          "GD Haji Ibrahim Khaskheli",
          "GD M Rahim Lund"
        ]
      },
      {
        "name": "Khetlari",
        "centres": [
          "BHU Khetlari",
          "GD Guria Bah"
        ]
      },
      {
        "name": "Gurirar Beh",
        "centres": [
          "Gurirar Beh"
        ]
      },
      {
        "name": "Sarhore",
        "centres": [
          "Sarhore"
        ]
      }
    ],
    "Islamkot": [
      {
        "name": "Kehari",
        "centres": [
          "GD Kehri",
          "GD Piloroo"
        ]
      },
      {
        "name": "Manjathi",
        "centres": [
          "BHU Doonjh",
          "GD Manjethi"
        ]
      },
      {
        "name": "Singaro",
        "centres": [
          "BHU Vakario",
          "GD Jiando Dars",
          "GD Meenho Lanjo"
        ]
      },
      {
        "name": "Sonal Beh",
        "centres": [
          "GD Jogi Marhi",
          "GD Banbhanio Bheel",
          "GD Seenhar Vakia",
          "Thar Foundation Hospital"
        ]
      },
      {
        "name": "Khario Ghullam Shah",
        "centres": [
          "BHU K.G Shah",
          "GD Lakhi Tobho",
          "Marvi Clinic"
        ]
      },
      {
        "name": "Town Committee Islamkot",
        "centres": [
          "RHC Islamkot"
        ]
      },
      {
        "name": "Jiando Dars",
        "centres": [
          "Jiando Dars"
        ]
      },
      {
        "name": "Bapuhar",
        "centres": [
          "Bapuhar"
        ]
      },
      {
        "name": "Ghiryancho",
        "centres": [
          "Ghiryancho"
        ]
      },
      {
        "name": "Buhariri",
        "centres": [
          "GD Kehri",
          "GD Piloroo"
        ]
      }
    ],
    "Mithi": [
      {
        "name": "Vejhiar",
        "centres": [
          "Vejhiar"
        ]
      },
      {
        "name": "Bhakhyo",
        "centres": [
          "BHU Bhakuo",
          "GD Bapuhar",
          "GD Chaunhar"
        ]
      },
      {
        "name": "Joruo",
        "centres": [
          "BHU Amerio",
          "GD Harpar",
          "GD Posarko"
        ]
      },
      {
        "name": "Malenhore Veena",
        "centres": [
          "BHU Malenhor veena",
          "BHU Pabuhar",
          "GD Lakhmiar"
        ]
      },
      {
        "name": "Mithrio Bhatti",
        "centres": [
          "BHU Bughar",
          "BHU Mithrio Bhatti",
          "GD Mithrau Dal"
        ]
      },
      {
        "name": "Mohrano",
        "centres": [
          "GD Jarihar Soomra",
          "GD Mithrio Otha",
          "GD Talhi Memon"
        ]
      },
      {
        "name": "Municipal Committee Mithi",
        "centres": [
          "Municipal Committee Mithi"
        ]
      },
      {
        "name": "Town Committee Chelhar",
        "centres": [
          "Town Committee Chelhar"
        ]
      },
      {
        "name": "Chelhar Rural",
        "centres": [
          "Chelhar Rural"
        ]
      }
    ],
    "Nagarparkar": [
      {
        "name": "Harho",
        "centres": [
          "BHU Kolhi ji veri",
          "GD Juglio"
        ]
      },
      {
        "name": "Piloo",
        "centres": [
          "GD Piloo",
          "GD Sunder"
        ]
      },
      {
        "name": "Pithapur",
        "centres": [
          "BHU Chanida",
          "GD Ailani Jo Wandio",
          "GD Ded Vero",
          "GD Kasbo",
          "GD Ranpur"
        ]
      },
      {
        "name": "Satidera",
        "centres": [
          "GD Jado Joyo",
          "GD Sakar Hajam",
          "GD Wagho Bajeer"
        ]
      },
      {
        "name": "Virawah",
        "centres": [
          "BHU Dano Dandhal",
          "BHU Virawah"
        ]
      },
      {
        "name": "Chotal",
        "centres": [
          "Chotal"
        ]
      },
      {
        "name": "Town Committee Nagarparkar",
        "centres": [
          "THQ Nagarparkar"
        ]
      },
      {
        "name": "Dabho",
        "centres": [
          "BHU Kolhi ji veri",
          "GD Juglio"
        ]
      },
      {
        "name": "Kasbo",
        "centres": [
          "Kasbo"
        ]
      },
      {
        "name": "Missri Shah",
        "centres": [
          "Missri Shah"
        ]
      },
      {
        "name": "Nagarparkar Rural",
        "centres": [
          "THQ Nagarparkar"
        ]
      }
    ]
  },
  "Thatta": {
    "Ghorabari": [
      {
        "name": "Gharro",
        "centres": [
          "BHU Garho"
        ]
      },
      {
        "name": "Khan",
        "centres": [
          "BHU Gail Mori",
          "RHC Var"
        ]
      },
      {
        "name": "Kotru Allah Rakhio Shah",
        "centres": [
          "BHU Ghora Bari"
        ]
      },
      {
        "name": "Gharobari- Mehar",
        "centres": [
          "GD Abdullah Kehar"
        ]
      },
      {
        "name": "Uddasi",
        "centres": [
          "BHU Dandhari"
        ]
      }
    ],
    "Keti Bunder": [
      {
        "name": "Keti Bander",
        "centres": [
          "RHC-Bhaghan",
          "RHC-Keti Bunder"
        ]
      },
      {
        "name": "Kharo Chann",
        "centres": [
          "BHU Sajan Wari"
        ]
      }
    ],
    "Mirpur Sakro": [
      {
        "name": "Mirpur Sakro- Buhara",
        "centres": [
          "BHU Buhara"
        ]
      },
      {
        "name": "Dhabeji",
        "centres": [
          "BHU Dhabeji"
        ]
      },
      {
        "name": "Mirpur Sakro- gharo",
        "centres": [
          "BHU Noor Muhammad Thahim",
          "RHC Gharo"
        ]
      },
      {
        "name": "Ghulamullah",
        "centres": [
          "BHU Ghulamullah"
        ]
      },
      {
        "name": "Gujjo",
        "centres": [
          "BHU Gujjo"
        ]
      },
      {
        "name": "Haji ghalirano",
        "centres": [
          "BHU Haji Muhammad Khan Sodho",
          "BHU Mathino Rind"
        ]
      },
      {
        "name": "Mirpur Sakro- Mirpur Sakro",
        "centres": [
          "Shaikh Zayed Medical Centre, Mirpur Sakro"
        ]
      },
      {
        "name": "Sukhpur",
        "centres": [
          "BHU Ghari Wah"
        ]
      },
      {
        "name": "Chowbandi",
        "centres": [
          "BHU Jokhia Village"
        ]
      },
      {
        "name": "Karampor",
        "centres": [
          "DCD Village Soomar Hotel"
        ]
      }
    ],
    "Thatta": [
      {
        "name": "Jungshahi",
        "centres": [
          "RHC Jungshahi"
        ]
      },
      {
        "name": "Kalri",
        "centres": [
          "BHU Achar Jakhro",
          "DCD Gul Munda"
        ]
      },
      {
        "name": "Thatta-1",
        "centres": [
          "Town Dispensary Thatta"
        ]
      },
      {
        "name": "Thatta-2",
        "centres": [
          "SAUMH Thatta"
        ]
      },
      {
        "name": "Kalakot",
        "centres": [
          "GD Labour Colony"
        ]
      },
      {
        "name": "Doomani",
        "centres": [
          "GD Nagan"
        ]
      },
      {
        "name": "Makli",
        "centres": [
          "CHT Makli Thatta"
        ]
      },
      {
        "name": "Chatto Chand",
        "centres": [
          "BHU chutto Chand",
          "GD Peer Bux Brohi"
        ]
      },
      {
        "name": "Sonda",
        "centres": [
          "BHU Ali Bhar",
          "G.D Hillaya"
        ]
      },
      {
        "name": "Jhirck",
        "centres": [
          "RHC Jhirk"
        ]
      },
      {
        "name": "Tando Hafiz Shah",
        "centres": [
          "BHU Tando Hafiz Shah"
        ]
      },
      {
        "name": "Onger",
        "centres": [
          "GD New Road"
        ]
      },
      {
        "name": "Jhumpir",
        "centres": [
          "BHU Jhampir"
        ]
      }
    ]
  },
  "Umerkot": {
    "Kunri": [
      {
        "name": "Bustan",
        "centres": [
          "BHU M Hassan Gujrati",
          "GD Sajjan Khan Chandio"
        ]
      },
      {
        "name": "Dadhro",
        "centres": [
          "Dadhro"
        ]
      },
      {
        "name": "TC Kunri",
        "centres": [
          "THQ Kunri"
        ]
      },
      {
        "name": "Shaheed Raja Iqbal Memon",
        "centres": [
          "Shaheed Raja Iqbal Memon"
        ]
      },
      {
        "name": "TC Nabisar",
        "centres": [
          "BHU Nabisir Thar",
          "RHC Nabisar Road"
        ]
      },
      {
        "name": "Sher Khan Chandio",
        "centres": [
          "BHU Darello"
        ]
      },
      {
        "name": "Talhi",
        "centres": [
          "BHU Talhi"
        ]
      },
      {
        "name": "Nabisar Thar",
        "centres": [
          "BHU Nabisir Thar",
          "RHC Nabisar Road"
        ]
      },
      {
        "name": "Nawabad",
        "centres": [
          "Nawabad"
        ]
      },
      {
        "name": "Shaheed Mai Bakhtawar",
        "centres": [
          "Shaheed Mai Bakhtawar"
        ]
      },
      {
        "name": "Shakh Darelo",
        "centres": [
          "Shakh Darelo"
        ]
      }
    ],
    "Pithoro": [
      {
        "name": "UC Pithoro",
        "centres": [
          "BHU Nawaz Ali Shah",
          "THQ Pithoro"
        ]
      },
      {
        "name": "TC Shadi Pali",
        "centres": [
          "BHU Haji Peer Shah",
          "BHU Shadi Palli"
        ]
      },
      {
        "name": "Shah Mardan Shah",
        "centres": [
          "BHU Abdul Hakeem Arisar",
          "BHU Ghulam Nabi Shah"
        ]
      },
      {
        "name": "Bareji",
        "centres": [
          "Bareji"
        ]
      },
      {
        "name": "Ghulam Nabi Shah",
        "centres": [
          "BHU Abdul Hakeem Arisar",
          "BHU Ghulam Nabi Shah"
        ]
      },
      {
        "name": "Haji Peer Shah",
        "centres": [
          "BHU Abdul Hakeem Arisar",
          "BHU Ghulam Nabi Shah"
        ]
      },
      {
        "name": "Makhoom Talib UL Moula",
        "centres": [
          "Makhoom Talib UL Moula"
        ]
      },
      {
        "name": "TC Pithoro",
        "centres": [
          "BHU Nawaz Ali Shah",
          "THQ Pithoro"
        ]
      }
    ],
    "Samaro": [
      {
        "name": "Araro Bhurgri",
        "centres": [
          "BHU Araro Bhurgri",
          "BHU Saleh Bhanbhro"
        ]
      },
      {
        "name": "Padhiryo Farm",
        "centres": [
          "BHU Padhiryo Farm",
          "BHU Tobhan Wari"
        ]
      },
      {
        "name": "Rename Samaro",
        "centres": [
          "THQ Samaro"
        ]
      },
      {
        "name": "Samaro Road",
        "centres": [
          "BHU Pir Sarahndi",
          "BHU Samaro Thar"
        ]
      },
      {
        "name": "Satiryoon",
        "centres": [
          "BHU Mir Din Muhammad"
        ]
      },
      {
        "name": "Gulzar E Khalil",
        "centres": [
          "Gulzar E Khalil"
        ]
      },
      {
        "name": "Rais Noor Khan Dhonkai",
        "centres": [
          "Rais Noor Khan Dhonkai"
        ]
      },
      {
        "name": "TC Samaro",
        "centres": [
          "THQ Samaro"
        ]
      },
      {
        "name": "Tobhan Wari",
        "centres": [
          "Tobhan Wari"
        ]
      }
    ],
    "Umerkot": [
      {
        "name": "Atta Muhammad Palli",
        "centres": [
          "BHU Fateh Mohammad Rajar",
          "GD KS Atta Muhammad Palli"
        ]
      },
      {
        "name": "TC Chhore",
        "centres": [
          "GD Hawelli Thakur",
          "MTD New Chhore",
          "RHC Chhore",
          "RHC Fakir Amin Mangrio"
        ]
      },
      {
        "name": "TC Dhoronaro",
        "centres": [
          "RHC Dhoronaro"
        ]
      },
      {
        "name": "Fakir Abdullah",
        "centres": [
          "BHU Faqeer Abdullah Janhero"
        ]
      },
      {
        "name": "MC Umerkot 3",
        "centres": [
          "DHQ Hospital",
          "GD Shewani Paro",
          "MCH Centre Shewani Paro"
        ]
      },
      {
        "name": "Kaplore",
        "centres": [
          "FAMC Marohar Halepoto",
          "GD Jhamerari",
          "GD Kerlo"
        ]
      },
      {
        "name": "Kharoro Syed",
        "centres": [
          "BHU Ahori Farm",
          "BHU Khararo Syed",
          "BHU Rana Jagir"
        ]
      },
      {
        "name": "Khejrari",
        "centres": [
          "GD Dhanaser",
          "RHC Hyder Farm"
        ]
      },
      {
        "name": "Khokhrapar",
        "centres": [
          "BHU Dhamboro",
          "BHU Mendre-Jo-Par",
          "RHC Khokhrapaar"
        ]
      },
      {
        "name": "Gapno",
        "centres": [
          "Gapno"
        ]
      },
      {
        "name": "Koonjeli",
        "centres": [
          "Koonjeli"
        ]
      },
      {
        "name": "MC Umerkot 1",
        "centres": [
          "DHQ Hospital",
          "GD Shewani Paro",
          "MCH Centre Shewani Paro"
        ]
      },
      {
        "name": "Debo",
        "centres": [
          "Debo"
        ]
      },
      {
        "name": "Hazrat Mian Jan Mohammad",
        "centres": [
          "Hazrat Mian Jan Mohammad"
        ]
      },
      {
        "name": "Kacholi",
        "centres": [
          "Kacholi"
        ]
      },
      {
        "name": "Kharoro Charan",
        "centres": [
          "BHU Ahori Farm",
          "BHU Khararo Syed",
          "BHU Rana Jagir"
        ]
      },
      {
        "name": "Mahendre Jo PAR",
        "centres": [
          "Mahendre Jo PAR"
        ]
      },
      {
        "name": "MC Umerkot 2",
        "centres": [
          "DHQ Hospital",
          "GD Shewani Paro",
          "MCH Centre Shewani Paro"
        ]
      },
      {
        "name": "MC Umerkot 4",
        "centres": [
          "DHQ Hospital",
          "GD Shewani Paro",
          "MCH Centre Shewani Paro"
        ]
      },
      {
        "name": "Mohammad Siddique Saand",
        "centres": [
          "Mohammad Siddique Saand"
        ]
      },
      {
        "name": "New Chhore",
        "centres": [
          "GD Hawelli Thakur",
          "MTD New Chhore",
          "RHC Chhore",
          "RHC Fakir Amin Mangrio"
        ]
      },
      {
        "name": "Sekhro",
        "centres": [
          "Sekhro"
        ]
      },
      {
        "name": "Soofi",
        "centres": [
          "Soofi"
        ]
      },
      {
        "name": "Syed Haji Mian Shah",
        "centres": [
          "Syed Haji Mian Shah"
        ]
      },
      {
        "name": "Walidad Palli",
        "centres": [
          "BHU Fateh Mohammad Rajar",
          "GD KS Atta Muhammad Palli"
        ]
      }
    ]
  }
};
