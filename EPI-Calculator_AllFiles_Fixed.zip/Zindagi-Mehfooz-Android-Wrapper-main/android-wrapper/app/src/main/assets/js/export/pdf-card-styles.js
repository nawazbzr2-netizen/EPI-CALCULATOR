// ---------- Card Style PDF: the six card designs (1, 2, 3, G, I, D) ----------
// Draws ONE child card for the design that is currently chosen in the app (getCardStyle()).
// Called twice per card by buildRecordCardsPdf (js/export/pdf-records.js): first with pg = null just to
// measure the height, then with the real page — so measuring and drawing can never drift apart.
// Layout (same as on screen): picture | name, father, DOB | EPI No + QR Code No box, then the address,
// then the vaccination status, then the tap-to-call button, then the status / serial line.
// The Call button is a real tappable link (tel:) — tapping it in the PDF starts the phone call.

const PCS_THEMES = {
  '1': { kind: 'rows', box: '#1f2420', fg: '#ffffff', lbl: '#d8dcd6', acc: '#1f2420', dose: '#1f2420', head: '#eeece6', headFg: '#5f665d', zebra: '#f7f5f0' },
  '2': { kind: 'rows', box: '#e1f3ea', fg: '#1b6b45', lbl: '#1b6b45', acc: '#1b6b45', dose: '#1b6b45', dashed: '#8fb9a2', line: true, headLine: '#b7cdbf' },
  '3': { kind: 'grid', box: '#e6f0fb', fg: '#185fa5', lbl: '#185fa5', acc: '#185fa5', dose: '#185fa5', cell: '#f4f2ee' },
  'G': { kind: 'rows', box: null, outline: '#5b3fa6', fg: '#1f2420', lbl: '#5b3fa6', acc: '#5b3fa6', dose: '#4b35a0', chip: '#eeebf9', line: true, headLine: '#d9d2ef' },
  'I': { kind: 'two',  box: '#ffffff', boxLine: '#d3e1f2', panel: '#eef4fc', fg: '#185fa5', lbl: '#185fa5', acc: '#185fa5', dose: '#185fa5' },
  'D': { kind: 'rows', box: '#faeeda', fg: '#854f0b', lbl: '#854f0b', acc: '#854f0b', dose: '#1f2420', head: '#faeeda', headFg: '#854f0b', line: true }
};

const PCS_NOOP = { text(){}, rect(){}, line(){}, image(){}, fillColor(){}, strokeColor(){}, lineWidth(){}, link(){} };

function pcsWrap(text, maxW, size, bold){
  const raw = String(text == null ? '' : text);
  if (!raw.trim()) return ['—'];
  const lines = [];
  for (const para of raw.split('\n')) {
    const words = para.split(/\s+/).filter(Boolean);
    let cur = '';
    for (const w of words) {
      const test = cur ? cur + ' ' + w : w;
      if (measureText(test, size, bold) <= maxW) { cur = test; continue; }
      if (cur) lines.push(cur);
      if (measureText(w, size, bold) <= maxW) { cur = w; continue; }
      let piece = '';
      for (const ch of w) {
        if (piece && measureText(piece + ch, size, bold) > maxW) { lines.push(piece); piece = ch; }
        else piece += ch;
      }
      cur = piece;
    }
    if (cur) lines.push(cur);
  }
  return lines.length ? lines : ['—'];
}

function drawStyledCard(pgIn, xCard, y0, f, idx, styleId, CARD_W){
  const P = pgIn || PCS_NOOP;
  const T = PCS_THEMES[styleId] || PCS_THEMES['1'];
  const PADX = 14, AV = 56, TW = CARD_W - 2 * PADX;
  const INK = '#1f2420', GRAY = '#5f665d', LINE = '#eee8de';
  const avName = f.isTt ? 'Woman' : (f.gender === 'M' ? 'Boy' : (f.gender === 'F' ? 'Girl' : null));
  let cy = y0 + 14;

  // ---------- top row: picture | details | EPI No + QR Code No ----------
  const IDW = 128;                                   // width of the EPI / QR box
  const panelPad = T.panel ? 8 : 0;                  // design I: the whole top row sits on a tinted panel
  const rowX = xCard + PADX + panelPad, rowW = TW - 2 * panelPad;
  const idX = rowX + rowW - IDW;
  const detX = rowX + AV + 8, detW = idX - 8 - detX;
  const details = [];
  pcsWrap(f.name, detW, 13, true).slice(0, 3).forEach(t => details.push([t, 13, true, INK, 15]));
  pcsWrap(f.personLabel.replace(' Name', '') + ': ' + f.fatherName, detW, 10.5, false).slice(0, 4).forEach(t => details.push([t, 10.5, false, GRAY, 13]));
  details.push(['DOB: ' + f.dobText, 10.5, false, GRAY, 13]);
  const detH = details.reduce((s, l) => s + l[4], 0);
  const ID_H = 70;
  const topH = Math.max(AV, detH, ID_H);
  if (T.panel) { P.fillColor(T.panel); P.rect(xCard + PADX, cy - 6, TW, topH + 12, 'f'); }
  if (avName) P.image(avName, rowX, cy, AV, AV);
  let ty = cy;
  details.forEach(l => { ty += l[4] - 3; P.text(detX, ty, l[0], l[1], l[2], l[3]); ty += 3; });
  // EPI / QR box
  if (T.box) { P.fillColor(T.box); P.rect(idX, cy, IDW, topH, 'f'); }
  if (T.boxLine) { P.strokeColor(T.boxLine); P.lineWidth(0.8); P.rect(idX, cy, IDW, topH, 'S'); }
  if (T.outline) { P.strokeColor(T.outline); P.lineWidth(1.4); P.rect(idX, cy, IDW, topH, 'S'); }
  if (T.dashed) {                                    // ticket: dashed tear-off line on the left edge of the box
    P.strokeColor(T.dashed); P.lineWidth(1.4);
    for (let y = cy; y < cy + topH - 2; y += 6) P.line(idX, y, idX, Math.min(y + 3, cy + topH));
  }
  const ix = idX + 9, iy = cy + (topH - ID_H) / 2;
  P.text(ix, iy + 17, 'EPI No', 8.5, true, T.lbl);
  P.text(ix, iy + 32, String(f.epi), 14, true, T.fg);
  P.text(ix, iy + 49, 'QR Code No', 8.5, true, T.lbl);
  const qrTxt = String(f.qr);
  P.text(ix, iy + 62, qrTxt, measureText(qrTxt, 10.5, true) > IDW - 14 ? 9 : 10.5, true, T.fg);
  cy += topH + (T.panel ? 12 : 8);

  // ---------- address ----------
  P.strokeColor(LINE); P.lineWidth(0.8); P.line(xCard + PADX, cy, xCard + CARD_W - PADX, cy);
  cy += 3;
  const al = pcsWrap(f.addr, TW, 11, false);
  P.text(xCard + PADX, cy + 10, 'Address', 8.5, true, T.acc);
  al.forEach((t, i) => P.text(xCard + PADX, cy + 23 + i * 14, t, 11, false, INK));
  cy += 12 + al.length * 14 + 8;

  // ---------- vaccination status ----------
  P.text(xCard + PADX, cy + 10, 'Vaccination status', 8.5, true, T.acc);
  cy += 16;
  if (T.kind === 'grid') {
    const GAPX = 6, CW = (TW - GAPX) / 2;
    for (let i = 0; i < f.visits.length; i += 2) {
      const pair = [f.visits[i], f.visits[i + 1]].filter(Boolean);
      const info = pair.map(v => ({ dl: pcsWrap(v.vaccine, CW - 14, 11.5, true), wl: pcsWrap(v.who, CW - 14, 10, false) }));
      const rowH = Math.max.apply(null, info.map(o => 8 + o.dl.length * 14 + 13 + o.wl.length * 12 + 6));
      pair.forEach((v, k) => {
        const cx = xCard + PADX + k * (CW + GAPX);
        P.fillColor(T.cell); P.rect(cx, cy, CW, rowH, 'f');
        let y = cy + 8;
        info[k].dl.forEach(t => { y += 11.5; P.text(cx + 8, y, t, 11.5, true, T.dose); y += 2.5; });
        y += 10.5; P.text(cx + 8, y, v.date, 10, false, INK);
        info[k].wl.forEach(t => { y += 12; P.text(cx + 8, y, t, 10, false, GRAY); });
      });
      cy += rowH + 6;
    }
  } else if (T.kind === 'two') {
    f.visits.forEach((v, i) => {
      const dl = pcsWrap(v.vaccine, TW - 70, 11.5, true), wl = pcsWrap(v.who, TW, 10, false);
      if (i) { P.strokeColor(LINE); P.lineWidth(0.6); P.line(xCard + PADX, cy, xCard + CARD_W - PADX, cy); }
      dl.forEach((t, k) => P.text(xCard + PADX + 2, cy + 13 + k * 14, t, 11.5, true, T.dose));
      P.text(xCard + CARD_W - PADX - 2 - measureText(v.date, 10.5, false), cy + 13, v.date, 10.5, false, GRAY);
      let h = 6 + dl.length * 14;
      wl.forEach((t, k) => P.text(xCard + PADX + 2, cy + h + 7 + k * 12, t, 10, false, GRAY));
      cy += h + wl.length * 12 + 8;
    });
    cy += 2;
  } else {
    const C1 = 66, C2 = 84, C3 = TW - C1 - C2 - 8;
    const x1 = xCard + PADX + 4, x2 = x1 + C1, x3 = x2 + C2;
    if (T.head) { P.fillColor(T.head); P.rect(xCard + PADX, cy, TW, 17, 'f'); }
    P.text(x1, cy + 12, 'Date', 8.5, true, T.headFg || GRAY);
    P.text(x2, cy + 12, 'Dose', 8.5, true, T.headFg || GRAY);
    P.text(x3, cy + 12, 'Vaccinator', 8.5, true, T.headFg || GRAY);
    cy += 17;
    if (!T.head) { P.strokeColor(T.headLine || '#cfc9bf'); P.lineWidth(1.2); P.line(xCard + PADX, cy, xCard + CARD_W - PADX, cy); }
    f.visits.forEach((v, i) => {
      const l1 = pcsWrap(v.date, C1 - 4, 11, false), l2 = pcsWrap(v.vaccine, C2 - (T.chip ? 14 : 6), 11, true), l3 = pcsWrap(v.who, C3, 11, false);
      const n = Math.max(l1.length, l2.length, l3.length);
      const rh = n * 13.5 + 8;
      if (T.zebra && i % 2 === 0) { P.fillColor(T.zebra); P.rect(xCard + PADX, cy, TW, rh, 'f'); }
      if (T.chip) { P.fillColor(T.chip); P.rect(x2 - 4, cy + 3, Math.min(C2 - 2, measureText(l2[0], 11, true) + 10), 15, 'f'); }
      for (let k = 0; k < n; k++) {
        const by = cy + 13 + k * 13.5;
        if (l1[k]) P.text(x1, by, l1[k], 11, false, INK);
        if (l2[k]) P.text(x2, by, l2[k], 11, true, T.dose);
        if (l3[k]) P.text(x3, by, l3[k], 11, false, INK);
      }
      if (T.line || !T.zebra) { P.strokeColor(LINE); P.lineWidth(0.6); P.line(xCard + PADX, cy + rh, xCard + CARD_W - PADX, cy + rh); }
      cy += rh;
    });
    cy += 4;
  }

  // ---------- Call button (under the vaccination details): a real link, tap = phone call ----------
  if (f.phone) {
    cy += 6;
    const BH = 30;
    P.fillColor('#1f9d55'); P.rect(xCard + PADX, cy, TW, BH, 'f');
    const label = 'Call  ' + f.phone, lw = measureText(label, 12.5, true);
    P.text(xCard + PADX + (TW - lw) / 2, cy + 19.5, label, 12.5, true, '#ffffff');
    P.link({ x: xCard + PADX, yTop: cy, w: TW, h: BH, uri: 'tel:' + f.phone });
    cy += BH + 6;
  } else {
    cy += 4;
  }

  // ---------- status / serial line ----------
  P.text(xCard + PADX, cy + 12, f.statusText, 9.5, false, GRAY);
  const ser = 'Serial ' + (idx + 1);
  P.text(xCard + CARD_W - PADX - measureText(ser, 9.5, false), cy + 12, ser, 9.5, false, GRAY);
  return cy;   // absolute y of the content's bottom edge (the caller adds the bottom padding)
}
