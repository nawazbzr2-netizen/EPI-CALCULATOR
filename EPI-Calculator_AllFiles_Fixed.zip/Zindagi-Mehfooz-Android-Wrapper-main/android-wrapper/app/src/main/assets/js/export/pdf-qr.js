// ============================================================
// QR Codes PDF export — EPI Pakistan style: numbered QR tiles.
// Each tile draws a real scannable QR whose payload is the
// number printed under it. Uses a compact pure-JS QR encoder
// (numeric/byte mode) and the app's existing PdfWriter.
// ============================================================

// --- Minimal QR Code generator (ISO/IEC 18004, byte mode) ---
// Supports versions 1–10 which cover up to ~14-digit codes easily.
(function (root) {
  'use strict';

  // GF(256) for Reed-Solomon
  const EXP = new Uint8Array(512);
  const LOG = new Uint8Array(256);
  (function initGF() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      EXP[i] = x;
      LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  })();
  function gfMul(a, b) { return a && b ? EXP[LOG[a] + LOG[b]] : 0; }

  function rsGenerator(ecLen) {
    let g = [1];
    for (let i = 0; i < ecLen; i++) {
      const ng = new Array(g.length + 1).fill(0);
      for (let j = 0; j < g.length; j++) {
        ng[j] ^= g[j];
        ng[j + 1] ^= gfMul(g[j], EXP[i]);
      }
      g = ng;
    }
    return g;
  }
  function rsEncode(data, ecLen) {
    const gen = rsGenerator(ecLen);
    const res = new Array(ecLen).fill(0);
    for (let i = 0; i < data.length; i++) {
      const factor = data[i] ^ res[0];
      res.shift();
      res.push(0);
      for (let j = 0; j < ecLen; j++) res[j] ^= gfMul(gen[j + 1] || 0, factor);
    }
    return res;
  }

  // ECC table for versions 1-10, level M (15% recovery) — [totalCodewords, ecPerBlock, blocks]
  // Simplified: single block where possible.
  const ECC_M = {
    1:  [16, 10, 1],  2: [28, 16, 1],  3: [44, 26, 1],  4: [64, 18, 2],
    5:  [86, 24, 2],  6: [108, 16, 4], 7: [124, 18, 4], 8: [154, 22, 4],
    9:  [182, 22, 4], 10:[216, 26, 6]
  };
  const SIZE = v => 21 + (v - 1) * 4;

  function chooseVersion(dataLen) {
    // Byte mode capacity (approx) for level M
    const cap = { 1: 14, 2: 26, 3: 42, 4: 62, 5: 84, 6: 106, 7: 122, 8: 152, 9: 180, 10: 213 };
    for (let v = 1; v <= 10; v++) if (dataLen <= cap[v]) return v;
    return 10;
  }

  function setModule(mod, size, x, y, val) {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    mod[y * size + x] = val ? 1 : 0;
  }
  function getModule(mod, size, x, y) {
    if (x < 0 || y < 0 || x >= size || y >= size) return 0;
    return mod[y * size + x];
  }

  function placeFinder(mod, size, ox, oy) {
    for (let y = -1; y <= 7; y++) {
      for (let x = -1; x <= 7; x++) {
        const inPat = x >= 0 && x <= 6 && y >= 0 && y <= 6 &&
          (x === 0 || x === 6 || y === 0 || y === 6 || (x >= 2 && x <= 4 && y >= 2 && y <= 4));
        setModule(mod, size, ox + x, oy + y, inPat);
      }
    }
  }
  function placeTiming(mod, size) {
    for (let i = 8; i < size - 8; i++) {
      setModule(mod, size, i, 6, i % 2 === 0);
      setModule(mod, size, 6, i, i % 2 === 0);
    }
  }
  function placeDark(mod, size) {
    setModule(mod, size, 8, size - 8, 1);
  }
  function isReserved(size, x, y) {
    // Finder + separators
    if (x < 9 && y < 9) return true;
    if (x >= size - 8 && y < 9) return true;
    if (x < 9 && y >= size - 8) return true;
    // Timing
    if (x === 6 || y === 6) return true;
    // Format info areas
    if (y === 8 && (x <= 8 || x >= size - 8)) return true;
    if (x === 8 && (y <= 8 || y >= size - 7)) return true;
    return false;
  }

  // Alignment pattern centers for versions 2-10
  const ALIGN = {
    2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]
  };
  function placeAlign(mod, size, version) {
    const pos = ALIGN[version];
    if (!pos) return;
    for (let i = 0; i < pos.length; i++) {
      for (let j = 0; j < pos.length; j++) {
        const cx = pos[i], cy = pos[j];
        // Skip if overlaps finder
        if ((cx < 9 && cy < 9) || (cx > size - 10 && cy < 9) || (cx < 9 && cy > size - 10)) continue;
        for (let y = -2; y <= 2; y++) {
          for (let x = -2; x <= 2; x++) {
            const black = Math.max(Math.abs(x), Math.abs(y)) !== 1;
            // outer ring + center
            const v = (Math.abs(x) === 2 || Math.abs(y) === 2 || (x === 0 && y === 0));
            setModule(mod, size, cx + x, cy + y, v);
          }
        }
      }
    }
  }

  function formatBits(mask) {
    // ECC level M = 00, mask 0-7. BCH(15,5)
    const data = (0x0 << 3) | mask; // M = 00
    let d = data << 10;
    const poly = 0x537;
    for (let i = 14; i >= 10; i--) {
      if ((d >> i) & 1) d ^= poly << (i - 10);
    }
    const bits = ((data << 10) | d) ^ 0x5412;
    return bits;
  }
  function placeFormat(mod, size, mask) {
    const bits = formatBits(mask);
    // horizontal near top-left finder
    for (let i = 0; i < 8; i++) {
      const b = (bits >> i) & 1;
      const x = i < 6 ? i : i + 1;
      setModule(mod, size, x, 8, b);
    }
    for (let i = 8; i < 15; i++) {
      const b = (bits >> i) & 1;
      const x = size - 15 + i;
      setModule(mod, size, x, 8, b);
    }
    // vertical
    for (let i = 0; i < 7; i++) {
      const b = (bits >> (14 - i)) & 1;
      const y = i < 6 ? i : i + 1;
      setModule(mod, size, 8, y, b);
    }
    for (let i = 7; i < 15; i++) {
      const b = (bits >> (14 - i)) & 1;
      const y = size - 15 + i;
      setModule(mod, size, 8, y, b);
    }
  }

  function buildBitStream(str, version) {
    const bytes = [];
    for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i) & 0xff);
    // mode (4 bits) = 0100 byte, count (8 bits for v1-9, 16 for v10+)
    const bits = [];
    function push(val, n) {
      for (let i = n - 1; i >= 0; i--) bits.push((val >> i) & 1);
    }
    push(0b0100, 4);
    push(bytes.length, version <= 9 ? 8 : 16);
    bytes.forEach(b => push(b, 8));
    // terminator
    const totalDataBits = ECC_M[version][0] * 8;
    const term = Math.min(4, totalDataBits - bits.length);
    push(0, term);
    while (bits.length % 8) bits.push(0);
    // pad bytes
    const padBytes = [0xec, 0x11];
    let pi = 0;
    while (bits.length / 8 < ECC_M[version][0]) {
      push(padBytes[pi % 2], 8);
      pi++;
    }
    const data = [];
    for (let i = 0; i < bits.length; i += 8) {
      let b = 0;
      for (let j = 0; j < 8; j++) b = (b << 1) | (bits[i + j] || 0);
      data.push(b);
    }
    return data;
  }

  function interleave(data, version) {
    const [totalCW, ecPerBlock, blocks] = ECC_M[version];
    const dataPerBlock = Math.floor((totalCW) / blocks); // approximate — use total data / blocks
    // Better: total data codewords = totalCW, split into blocks
    // For simplicity use single-block path when blocks===1
    if (blocks === 1) {
      const ec = rsEncode(data.slice(0, totalCW), ecPerBlock);
      // Wait - data length should equal totalCW - but data includes only data codewords
      // ECC_M totalCW is DATA codewords only in our simplified table... 
      // Fix: ECC_M[v] = [dataCodewords, ecPerBlock, numBlocks]
      return data.concat(ec);
    }
    // Multi-block
    const shortBlocks = blocks - (totalCW % blocks);
    const shortLen = Math.floor(totalCW / blocks);
    const longLen = shortLen + 1;
    const dc = [];
    const ec = [];
    let offset = 0;
    for (let b = 0; b < blocks; b++) {
      const len = b < shortBlocks ? shortLen : longLen;
      const block = data.slice(offset, offset + len);
      offset += len;
      dc.push(block);
      ec.push(rsEncode(block, ecPerBlock));
    }
    const out = [];
    const maxD = longLen;
    for (let i = 0; i < maxD; i++) {
      for (let b = 0; b < blocks; b++) if (i < dc[b].length) out.push(dc[b][i]);
    }
    for (let i = 0; i < ecPerBlock; i++) {
      for (let b = 0; b < blocks; b++) out.push(ec[b][i]);
    }
    return out;
  }

  function maskFn(mask, x, y) {
    switch (mask) {
      case 0: return (x + y) % 2 === 0;
      case 1: return y % 2 === 0;
      case 2: return x % 3 === 0;
      case 3: return (x + y) % 3 === 0;
      case 4: return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
      case 5: return ((x * y) % 2) + ((x * y) % 3) === 0;
      case 6: return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0;
      case 7: return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
      default: return false;
    }
  }

  function placeData(mod, size, codewords, mask) {
    let bitIdx = 0;
    const bits = [];
    codewords.forEach(cw => {
      for (let i = 7; i >= 0; i--) bits.push((cw >> i) & 1);
    });
    let upward = true;
    for (let x = size - 1; x > 0; x -= 2) {
      if (x === 6) x--; // skip timing
      for (let i = 0; i < size; i++) {
        const y = upward ? size - 1 - i : i;
        for (let dx = 0; dx < 2; dx++) {
          const xx = x - dx;
          if (isReserved(size, xx, y)) continue;
          let bit = bitIdx < bits.length ? bits[bitIdx++] : 0;
          if (maskFn(mask, xx, y)) bit ^= 1;
          setModule(mod, size, xx, y, bit);
        }
      }
      upward = !upward;
    }
  }

  function encodeQR(text) {
    const str = String(text || '');
    const version = chooseVersion(str.length);
    const size = SIZE(version);
    const data = buildBitStream(str, version);
    // trim/pad data to exact data codeword count
    const dataCW = ECC_M[version][0];
    while (data.length < dataCW) data.push(0xec);
    data.length = dataCW;
    const codewords = interleave(data, version);
    // Try mask 0 only for simplicity (scanners accept any valid mask)
    const mask = 0;
    const mod = new Uint8Array(size * size);
    // init white
    placeFinder(mod, size, 0, 0);
    placeFinder(mod, size, size - 7, 0);
    placeFinder(mod, size, 0, size - 7);
    placeTiming(mod, size);
    placeAlign(mod, size, version);
    placeDark(mod, size);
    placeData(mod, size, codewords, mask);
    placeFormat(mod, size, mask);
    // return matrix as 2D array of 0/1
    const matrix = [];
    for (let y = 0; y < size; y++) {
      const row = [];
      for (let x = 0; x < size; x++) row.push(getModule(mod, size, x, y));
      matrix.push(row);
    }
    return matrix;
  }

  root.encodeQRMatrix = encodeQR;
})(typeof window !== 'undefined' ? window : globalThis);

// --- PDF export using the app's PdfWriter (from pdf-writer.js) ---
async function exportQrCodesPdf(codes) {
  if (!codes || !codes.length) return;
  if (typeof PdfWriter === 'undefined' && typeof makePdfDoc === 'undefined') {
    // Fallback: try window helpers
  }

  // Page layout: A4 portrait, grid of QR tiles
  const pageW = 595; // A4 points
  const pageH = 842;
  const margin = 28;
  const cols = 3;
  const rows = 4;
  const gap = 12;
  const usableW = pageW - margin * 2;
  const usableH = pageH - margin * 2 - 36; // leave room for header
  const cellW = (usableW - gap * (cols - 1)) / cols;
  const cellH = (usableH - gap * (rows - 1)) / rows;
  const perPage = cols * rows;

  // Build pages
  const pages = [];
  for (let i = 0; i < codes.length; i += perPage) {
    pages.push(codes.slice(i, i + perPage));
  }

  // Use the low-level writer if available
  const doc = (typeof createPdfDocument === 'function')
    ? createPdfDocument({ width: pageW, height: pageH })
    : null;

  // Prefer the shared path used by other exports
  if (typeof buildSimplePdf === 'function') {
    // not available
  }

  // Manual PDF construction with rectangles for QR modules + text via existing writer
  // Fallback path: use PdfWriter class if exported
  let pdfBytes;
  try {
    pdfBytes = await buildQrPdfBytes(codes, {
      pageW, pageH, margin, cols, rows, gap, cellW, cellH, perPage, pages
    });
  } catch (err) {
    console.error('QR PDF failed', err);
    if (typeof alertDialog === 'function') await alertDialog('Could not build QR PDF: ' + (err && err.message ? err.message : err));
    return;
  }

  const fname = 'QR-Codes-EPI-' + new Date().toISOString().slice(0, 10) + '.pdf';
  NativeBridge.primeNotifications();
  if (typeof downloadBlob === 'function') {
    downloadBlob(new Blob([pdfBytes], { type: 'application/pdf' }), fname);
  } else if (typeof shareOrDownloadBlob === 'function') {
    await shareOrDownloadBlob(new Blob([pdfBytes], { type: 'application/pdf' }), fname, 'QR Codes');
  } else {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([pdfBytes], { type: 'application/pdf' }));
    a.download = fname;
    a.click();
  }
  if (typeof backupMsg === 'function') backupMsg('QR Codes PDF saved.');
}

async function buildQrPdfBytes(codes, layout) {
  const { pageW, pageH, margin, cols, rows, gap, cellW, cellH, perPage, pages } = layout;

  // Collect content streams per page
  const pageStreams = [];
  const fontObjs = []; // not needed if we use built-in Helvetica via writer

  // If the app exposes a high-level PDF builder, use it; otherwise emit raw PDF.
  // Strategy: draw each QR as filled rectangles + text via a minimal PDF assembler
  // that only needs Helvetica (standard 14).

  function escPdfStr(s) {
    return String(s).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
  }

  for (let pi = 0; pi < pages.length; pi++) {
    const pageCodes = pages[pi];
    let ops = [];
    // Header
    ops.push('BT /F1 12 Tf 28 ' + (pageH - 22) + ' Td (' + escPdfStr('EPI Pakistan — QR Codes') + ') Tj ET');
    ops.push('BT /F1 9 Tf 28 ' + (pageH - 34) + ' Td (' + escPdfStr('Page ' + (pi + 1) + ' of ' + pages.length + '  |  Total: ' + codes.length) + ') Tj ET');

    pageCodes.forEach((code, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const x0 = margin + col * (cellW + gap);
      const y0 = pageH - margin - 40 - (row + 1) * cellH - row * gap; // bottom-left of cell

      // Cell border
      ops.push('0.7 w 0.75 0.75 0.75 RG ' + x0.toFixed(1) + ' ' + y0.toFixed(1) + ' ' + cellW.toFixed(1) + ' ' + cellH.toFixed(1) + ' re S');

      // QR matrix
      const matrix = window.encodeQRMatrix(String(code));
      const n = matrix.length;
      const quiet = 2; // quiet zone modules
      const totalMod = n + quiet * 2;
      const qrMax = Math.min(cellW - 16, cellH - 28);
      const modSize = qrMax / totalMod;
      const qrSize = modSize * totalMod;
      const qx = x0 + (cellW - qrSize) / 2;
      const qy = y0 + 18; // leave space for number below

      // White background for QR
      ops.push('1 1 1 rg ' + qx.toFixed(2) + ' ' + qy.toFixed(2) + ' ' + qrSize.toFixed(2) + ' ' + qrSize.toFixed(2) + ' re f');
      ops.push('0 0 0 rg');
      for (let y = 0; y < n; y++) {
        for (let x = 0; x < n; x++) {
          if (!matrix[y][x]) continue;
          const rx = qx + (x + quiet) * modSize;
          const ry = qy + (n - 1 - y + quiet) * modSize;
          ops.push(rx.toFixed(2) + ' ' + ry.toFixed(2) + ' ' + modSize.toFixed(2) + ' ' + modSize.toFixed(2) + ' re f');
        }
      }

      // Number under QR (centered)
      const label = String(code);
      const fontSize = label.length > 12 ? 8 : 10;
      // Approximate text width for centering (Helvetica ~0.5*size per char avg)
      const tw = label.length * fontSize * 0.5;
      const tx = x0 + (cellW - tw) / 2;
      const ty = y0 + 6;
      ops.push('BT /F1 ' + fontSize + ' Tf ' + tx.toFixed(1) + ' ' + ty.toFixed(1) + ' Td (' + escPdfStr(label) + ') Tj ET');
    });

    pageStreams.push(ops.join('\n'));
  }

  // Assemble PDF
  const objs = [];
  function addObj(str) {
    objs.push(str);
    return objs.length; // 1-based object number
  }

  // 1: Catalog
  // 2: Pages
  // 3: Font
  // then page objects + content streams

  const fontObj = 3;
  const pageObjNums = [];
  const contentObjNums = [];

  // We'll assign numbers: 1=catalog, 2=pages, 3=font, then pairs of page+content
  let next = 4;
  for (let i = 0; i < pageStreams.length; i++) {
    pageObjNums.push(next++);
    contentObjNums.push(next++);
  }

  const parts = [];
  parts.push('%PDF-1.4\n');
  const offsets = [0];

  function writeObj(num, body) {
    offsets[num] = parts.join('').length;
    parts.push(num + ' 0 obj\n' + body + '\nendobj\n');
  }

  writeObj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  writeObj(2, '<< /Type /Pages /Kids [' + pageObjNums.map(n => n + ' 0 R').join(' ') + '] /Count ' + pageObjNums.length + ' >>');
  writeObj(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');

  for (let i = 0; i < pageStreams.length; i++) {
    const pNum = pageObjNums[i];
    const cNum = contentObjNums[i];
    writeObj(pNum, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + pageW + ' ' + pageH + '] /Contents ' + cNum + ' 0 R /Resources << /Font << /F1 3 0 R >> >> >>');
    const stream = pageStreams[i];
    writeObj(cNum, '<< /Length ' + stream.length + ' >>\nstream\n' + stream + '\nendstream');
  }

  const xrefPos = parts.join('').length;
  const totalObjs = next - 1;
  let xref = 'xref\n0 ' + (totalObjs + 1) + '\n';
  xref += '0000000000 65535 f \n';
  for (let i = 1; i <= totalObjs; i++) {
    xref += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
  }
  parts.push(xref);
  parts.push('trailer\n<< /Size ' + (totalObjs + 1) + ' /Root 1 0 R >>\n');
  parts.push('startxref\n' + xrefPos + '\n%%EOF\n');

  const pdfStr = parts.join('');
  // Convert to Uint8Array (binary-safe for ASCII PDF)
  const out = new Uint8Array(pdfStr.length);
  for (let i = 0; i < pdfStr.length; i++) out[i] = pdfStr.charCodeAt(i) & 0xff;
  return out;
}
