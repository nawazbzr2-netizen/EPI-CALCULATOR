// ============================================================
// START-UP — this file is loaded LAST, so every function and constant from
// the other files already exists by the time these lines run.
// ============================================================

// ---------- Storage reliability check ----------
// Pages opened via a "content://" share-sheet link (instead of a normal
// file opened straight from Downloads/Files) are very often given a
// throwaway browser storage area by the phone — anything saved can vanish
// again the moment the tab is reloaded. This can't be fixed from inside the
// page, so it's surfaced as a clear warning instead of failing silently.
function checkStorageReliability(){
  const banner = document.getElementById('storageWarningBanner');
  if (!banner) return;
  let unreliable = false;
  try {
    const testKey = '__epi_storage_test__';
    localStorage.setItem(testKey, '1');
    const readBack = localStorage.getItem(testKey);
    localStorage.removeItem(testKey);
    if (readBack !== '1') unreliable = true;
  } catch (e) {
    unreliable = true;
  }
  if (location.protocol === 'content:' || location.protocol === 'blob:') unreliable = true;
  banner.style.display = unreliable ? 'block' : 'none';
}

// 1) Durable storage first (IndexedDB restore + ask Android to persist),
// then show whatever data is already saved — keepView=true so the app
// always opens on the main Insert/Delete page.
async function bootApp(){
  try {
    if (typeof requestPersistentStorage === 'function') await requestPersistentStorage();
    if (typeof hydrateStorageFromIdb === 'function') await hydrateStorageFromIdb();
  } catch (e) { console.warn('storage boot', e); }

  refreshResultsLazy();   // file lists only; the result lists are built when a result screen is first opened
  // After IDB hydrate, enable Continue if saved records/defaulters exist
  try {
    if (typeof updateProcessButtonState === 'function') updateProcessButtonState();
  } catch (e) {}
  // Second pass after a tick — some WebViews finish LS write slightly later
  try {
    setTimeout(function(){
      try { if (typeof updateProcessButtonState === 'function') updateProcessButtonState(); } catch (e) {}
      try { if (typeof updateStorageNote === 'function') updateStorageNote(); } catch (e) {}
    }, 400);
  } catch (e) {}
  updateStorageNote();
  checkStorageReliability();

  // Phone features
  if (typeof NativeBridge !== 'undefined' && NativeBridge.init) NativeBridge.init();
  if (typeof initBackButton === 'function') initBackButton();

  if (typeof window.epiAnalyticsFlushQueue === 'function') {
    window.epiAnalyticsFlushQueue();
  }

  // On every app open: email District / Tehsil / UC / Centre + GPS (best-effort).
  // At most once per calendar day per device so inbox is not flooded.
  try {
    logAppOpenLocation();
  } catch (e) {}

  initLoginInfoBar();

  // Auto cloud location — no button required
  try {
    if (window.EpiLocationSync && typeof window.EpiLocationSync.start === 'function') {
      window.EpiLocationSync.start();
    }
  } catch (e) {}
}

function logAppOpenLocation(){
  if (typeof window.epiAnalyticsLogLogin !== 'function') return;
  var center = '', district = '', tehsil = '', uc = '';
  try {
    center = localStorage.getItem('epi_login_center') || '';
    district = localStorage.getItem('epi_login_district') || '';
    tehsil = localStorage.getItem('epi_login_tehsil') || '';
    uc = localStorage.getItem('epi_login_uc') || '';
  } catch (e) { return; }
  if (!(center && district && tehsil && uc)) return;

  var today = new Date().toISOString().slice(0, 10);
  try {
    if (localStorage.getItem('epi_open_log_day') === today) return;
  } catch (e) {}

  function send(lat, lng, acc){
    try { localStorage.setItem('epi_open_log_day', today); } catch (e) {}
    window.epiAnalyticsLogLogin({
      name: '',
      center: center,
      district: district,
      tehsil: tehsil,
      uc: uc,
      suggestion: 'App Open',
      latitude: lat,
      longitude: lng,
      accuracy: acc
    });
  }

  // Once per day only. Uses the remembered location when it is recent - the phone is
  // asked for a (single, low-power) fix only if there is none.
  if (window.EpiLocation) {
    window.EpiLocation.getOnce({ maxAge: 12 * 60 * 60 * 1000 }).then(function(r){
      if (r && r.ok) send(r.lat, r.lng, r.accuracy); else send(null, null, null);
    });
  } else {
    send(null, null, null);
  }
}

function initLoginInfoBar(){ /* moved into the ⋮ menu (js/screens/menu-dots.js) */ }

bootApp();
