// ============================================================
// DOWNLOADS — the ONE place every file (PDF, CSV, TXT) leaves the app.
// ============================================================

function downloadBlobFile(filename, blob){
  try {
    // IE / legacy Edge
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, filename);
      try { if (typeof NativeBridge !== 'undefined') NativeBridge.notifyDownloaded(filename); } catch (e) {}
      return true;
    }
  } catch (e) {}

  // Android WebView APK bridge (base64) — most reliable for APK
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.downloadBase64 === 'function') {
      const reader = new FileReader();
      reader.onloadend = function(){
        try {
          const dataUrl = reader.result || '';
          const b64 = String(dataUrl).split(',')[1] || '';
          window.AndroidBridge.downloadBase64(filename, b64, blob.type || 'application/pdf');
        } catch (e) {}
      };
      reader.readAsDataURL(blob);
      try { if (typeof NativeBridge !== 'undefined') NativeBridge.notifyDownloaded(filename); } catch (e) {}
      return true;
    }
  } catch (e) {}

  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    a.setAttribute('download', filename);
    document.body.appendChild(a);
    a.click();
    setTimeout(function(){
      try { URL.revokeObjectURL(url); } catch (e) {}
      try { a.remove(); } catch (e) {}
    }, 4000);
    try { if (typeof NativeBridge !== 'undefined') NativeBridge.notifyDownloaded(filename); } catch (e) {}
    return true;
  } catch (e) {
    console.error('download failed', e);
    return false;
  }
}

function downloadText(filename, mime, text){
  downloadBlobFile(filename, new Blob([text], { type: mime || 'text/plain' }));
}

// Share a PDF blob via native sheet when possible; otherwise download.
async function shareOrDownloadBlob(blob, filename, title){
  // APK bridge first
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.shareBase64 === 'function') {
      const b64 = await new Promise(function(resolve, reject){
        const reader = new FileReader();
        reader.onloadend = function(){
          try { resolve(String(reader.result || '').split(',')[1] || ''); }
          catch (e) { reject(e); }
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
      window.AndroidBridge.shareBase64(filename, b64, blob.type || 'application/pdf', title || filename);
      return 'shared';
    }
  } catch (e) { console.warn('Android share bridge failed', e); }

  // Web Share API with files (HTTPS / supported browsers)
  try {
    const file = new File([blob], filename, { type: blob.type || 'application/pdf' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: title || filename, text: title || filename });
      return 'shared';
    }
  } catch (e) {
    if (e && e.name === 'AbortError') return 'cancelled';
    console.warn('file share failed', e);
  }

  // Some browsers allow share without files
  try {
    if (navigator.share) {
      await navigator.share({ title: title || filename, text: (title || filename) + '\n(PDF saved to Downloads)' });
      downloadBlobFile(filename, blob);
      return 'shared-text';
    }
  } catch (e) {
    if (e && e.name === 'AbortError') return 'cancelled';
  }

  // Fallback: download
  downloadBlobFile(filename, blob);
  return 'downloaded';
}
