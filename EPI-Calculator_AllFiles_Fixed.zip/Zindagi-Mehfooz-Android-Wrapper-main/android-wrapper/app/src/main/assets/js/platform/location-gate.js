// ============================================================
// location-gate.js
// ------------------------------------------------------------
// The app ALWAYS opens and works, whether the phone's Location / GPS is on
// or off, and whether the permission was given or not. Nothing is blocked
// and no "location required" page is shown.
//
//  - Location ON + allowed  -> the location goes to the server by itself
//    (EpiLocationSync). Nothing for the user to do.
//  - Location OFF / denied  -> the app simply works; the sending is skipped
//    quietly and starts again by itself when location becomes available.
//
// The Android permission box is shown only ONCE, the first time after install
// (see MainActivity.kt). It is never asked again.
// ============================================================
(function () {
  var gate = document.getElementById('locationGate');
  var wrap = document.getElementById('appWrap');
  if (gate) { gate.style.display = 'none'; gate.innerHTML = ''; }
  if (wrap) wrap.style.visibility = 'visible';

  try {
    if (window.EpiLocationSync && typeof window.EpiLocationSync.start === 'function') {
      window.EpiLocationSync.start();
    }
  } catch (e) {}
})();
