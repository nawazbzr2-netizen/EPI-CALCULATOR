// ---------- Result card designs (1, 2, 3, G, I, D) ----------
// ONE card structure for every design; the chosen design is only a CSS class, so changing the
// design is instant and the shared / downloaded Card Style PDF (js/export/pdf-card-styles.js)
// uses the very same choice.
const CARD_STYLES = [
  { id: '1', name: 'Design 1 - Dark band',    color: '#1f2420' },
  { id: '2', name: 'Design 2 - Green ticket', color: '#1b6b45' },
  { id: '3', name: 'Design 3 - Blue boxes',   color: '#185fa5' },
  { id: 'G', name: 'Design G - Purple lines', color: '#5b3fa6' },
  { id: 'I', name: 'Design I - Side panel',   color: '#378add' },
  { id: 'D', name: 'Design D - Amber',        color: '#ba7517' }
];
const CARD_STYLE_KEY = 'epiCardStyle';

function getCardStyle(){
  let id = '1';
  try { id = localStorage.getItem(CARD_STYLE_KEY) || '1'; } catch (e) {}
  return CARD_STYLES.some(s => s.id === id) ? id : '1';
}
function cardStyleName(id){
  const s = CARD_STYLES.find(x => x.id === (id || getCardStyle()));
  return s ? s.name : CARD_STYLES[0].name;
}
function setCardStyle(id){
  if (!CARD_STYLES.some(s => s.id === id)) return;
  try { localStorage.setItem(CARD_STYLE_KEY, id); } catch (e) {}
  // switch every card that is on screen right now
  document.querySelectorAll('.cs').forEach(el => {
    el.className = el.className.replace(/\bcs-s\w+\b/g, '').replace(/\s+/g, ' ').trim() + ' cs-s' + id;
  });
  document.querySelectorAll('.cs-style-name').forEach(el => { el.textContent = cardStyleName(id); });
}

// small SVG icons (no icon font needed)
const CS_SVG = {
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg>',
  seir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19.5 12.6 12 20l-7.5-7.4A5 5 0 0 1 12 6a5 5 0 0 1 7.5 6.6z"/><path d="M3 12h4l2-3 3 6 2-3h7"/></svg>'
};

// The bar above a list of cards with the "change design" button.
function cardStyleBarHtml(){
  return `<div class="cs-bar"><button type="button" class="cs-style-btn" aria-label="Change card design">🎨 Card design: <b class="cs-style-name">${escapeHtml(cardStyleName())}</b> ▾</button></div>`;
}

// ONE result card (used by every list of vaccinated children / women).
function cardStyleHtml(r, idx, opts){
  opts = opts || {};
  const sid = getCardStyle();
  const isTt = isTtRecord(r.doses);
  const dobText = r.dob ? `${String(r.dob.day).padStart(2,'0')}/${String(r.dob.month).padStart(2,'0')}/${r.dob.year}` : '?';
  const personLabel = isTt ? 'Husband' : 'Father';
  const avSrc = recordCardAvatarSrc(r, isTt);
  const avHtml = avSrc ? `<img class="cs-av" src="${avSrc}" alt="" width="56" height="56">` : '<span class="cs-av-ph"></span>';
  const phone = recordPhone(r);
  const addressText = r.address ? (phone ? recordAddressNoPhone(r) : r.address) : '';
  const statusText = r.outOfDistrict ? 'Out From District' : (r.outOfTaluka ? 'Out From Taluka' : (r.outOfUc ? 'Out of UC' : (isTt ? 'Woman' : AGE_LABELS[ageBracketKey(ageMonths(r.dob, r.vaccDate))])));
  const rows = visitRows(r).map(v =>
    `<div class="cs-row"><span class="cs-date">${escapeHtml(v.date)}</span><span class="cs-dose">${escapeHtml(v.vaccine)}</span><span class="cs-vacc">${escapeHtml(v.who)}</span></div>`).join('');
  const epi = r.epiNo ? escapeHtml(r.epiNo) : '?';
  const qr = r.id ? escapeHtml(r.id) : '?';
  const copy = (val, what) => val ? `<button type="button" class="cs-copy" data-cs-copy="${escapeHtml(val)}" aria-label="Copy ${what}">${CS_SVG.copy}</button>` : '';
  const seirBtn = `<button type="button" class="seir-follow-btn${r.id ? '' : ' cs-off'}" data-seir-qr="${r.id ? escapeHtml(r.id) : ''}" aria-label="SEIR Follow-up">${CS_SVG.seir}<b>SEIR</b><i>Follow-up</i></button>`;
  const callBtn = phone
    ? `<button type="button" class="call-btn" data-call="${escapeHtml(phone)}" aria-label="Call ${escapeHtml(phone)}">${CS_SVG.phone}<span class="cl">Call</span><span class="cn">${escapeHtml(phone)}</span></button>`
    : '';
  const shareBtn = opts.shareButton
    ? `<button type="button" class="card-share-btn" data-idx="${idx}">📤 Share / Download this card</button>`
    : '';
  return `<article class="child-card result-card cs cs-s${sid}">
      <div class="cs-top">
        <div class="cs-who">${avHtml}<div class="cs-who-main">
          <div class="cs-name">${r.name ? escapeHtml(r.name) : 'Name not recorded'}</div>
          <div class="cs-father">${personLabel}: ${r.fatherName ? escapeHtml(r.fatherName) : '?'}</div>
          <div class="cs-dob">DOB: ${dobText}</div>
        </div></div>
        <div class="cs-id">
          <div class="cs-id-row"><span class="cs-lbl">EPI No</span><span class="cs-val"><span class="cs-num cs-num-epi">${epi}</span>${copy(r.epiNo, 'EPI No')}</span></div>
          <div class="cs-id-row"><span class="cs-lbl">QR Code No</span><span class="cs-val"><span class="cs-num">${qr}</span>${copy(r.id, 'QR Code No')}</span></div>
        </div>
      </div>
      <div class="cs-addr">${CS_SVG.pin}<span>${addressText ? escapeHtml(addressText) : '?'}</span></div>
      <div class="cs-sec-title">Vaccination status</div>
      <div class="cs-status"><div class="cs-head"><span>Date</span><span>Dose</span><span>Vaccinator</span></div>${rows}</div>
      <div class="cs-actions">${seirBtn}${callBtn}</div>
      <div class="cs-foot"><span>${escapeHtml(statusText)}</span><span>Serial ${idx + 1}</span></div>
      ${shareBtn}
    </article>`;
}

// ---- the "change design" chooser ----
function chooseCardStyle(){
  return new Promise(resolve => {
    const cur = getCardStyle();
    const back = document.createElement('div');
    back.className = 'modal-backdrop';
    back.innerHTML = `<div class="modal-box" role="dialog" aria-modal="true">
      <div class="modal-msg">Choose a card design (used on screen and in Share / Download):</div>
      <div class="modal-actions" style="flex-direction:column;gap:8px;">
        ${CARD_STYLES.map(s => `<button type="button" class="go secondary" data-answer="${s.id}" style="text-align:left;display:flex;align-items:center;gap:10px;"><span style="width:18px;height:18px;border-radius:5px;background:${s.color};flex:none;"></span><span style="flex:1;">${s.name}</span>${s.id === cur ? '<span>✔</span>' : ''}</button>`).join('')}
        <button type="button" class="go secondary" data-answer="cancel" style="background:transparent;border:none;color:var(--muted);margin-top:0;">Cancel</button>
      </div>
    </div>`;
    let settled = false;
    const cancelFromBack = () => finish(null);
    const finish = value => {
      if (settled) return;
      settled = true;
      back.remove();
      document.removeEventListener('keydown', onKey);
      const i = openModalStack.indexOf(cancelFromBack);
      if (i !== -1) openModalStack.splice(i, 1);
      resolve(value);
    };
    const onKey = e => { if (e.key === 'Escape') finish(null); };
    back.addEventListener('click', e => {
      if (e.target === back) return finish(null);
      const btn = e.target.closest('[data-answer]');
      if (btn) finish(btn.dataset.answer === 'cancel' ? null : btn.dataset.answer);
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    openModalStack.push(cancelFromBack);
  });
}

document.addEventListener('click', async ev => {
  const styleBtn = ev.target.closest && ev.target.closest('.cs-style-btn');
  if (styleBtn) {
    ev.preventDefault();
    const pick = await chooseCardStyle();
    if (pick) setCardStyle(pick);
    return;
  }
  const cp = ev.target.closest && ev.target.closest('.cs-copy');
  if (cp) {
    ev.preventDefault();
    const val = cp.getAttribute('data-cs-copy') || '';
    if (val) qrCopyText(val, 'Copied: ' + val);
  }
});

// SEIR Follow-up logo: opens the SEIR app installed on the phone (native bridge AndroidEpi.openSeirFollowUp).
document.addEventListener('click', function (ev) {
  const b = ev.target.closest && ev.target.closest('.seir-follow-btn');
  if (!b) return;
  ev.preventDefault();
  const qr = (b.getAttribute('data-seir-qr') || '').replace(/\D/g, '');
  if (!qr) return;
  try {
    if (window.AndroidEpi && typeof window.AndroidEpi.openSeirFollowUp === 'function') { window.AndroidEpi.openSeirFollowUp(qr); return; }
  } catch (e) {}
  // Old build without the native "open SEIR" function: at least copy the QR so it can be pasted in SEIR Search.
  let copied = false;
  try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(qr); copied = true; } } catch (e) {}
  try { if (typeof backupMsg === 'function') backupMsg(copied ? 'QR copied. Open the SEIR app and paste it in Search.' : 'This version of the app cannot open the SEIR app yet.', !copied); } catch (e) {}
});
