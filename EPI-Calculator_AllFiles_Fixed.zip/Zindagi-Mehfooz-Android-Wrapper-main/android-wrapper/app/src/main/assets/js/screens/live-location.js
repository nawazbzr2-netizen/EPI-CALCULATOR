// ============================================================
// LIVE LOCATION (📍 لائیو لوکیشن)
// ------------------------------------------------------------
// Shows the user's current GPS position while the phone's location
// is ON and the app is open. No village-visit history, no automatic
// stop logging, no Timeline import.
//
// Updates every few seconds when this screen is visible.
// Opens Google Maps / OSM with one tap.
// ============================================================
(function () {
  const $ = (id) => document.getElementById(id);
  let watchId = null;
  let lastFix = null;
  let lastErr = '';
  let pollTimer = null;

  function pad(n) {
    return String(n).padStart(2, '0');
  }
  function hm(ms) {
    const d = new Date(ms);
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function stopWatch() {
    if (watchId != null && navigator.geolocation) {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
      watchId = null;
    }
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function onFix(pos) {
    const c = pos.coords;
    if (!c) return;
    lastErr = '';
    lastFix = {
      lat: c.latitude,
      lng: c.longitude,
      accuracy: c.accuracy,
      t: Date.now()
    };
    try {
      if (window.EpiLocation) window.EpiLocation.remember(c.latitude, c.longitude, c.accuracy);
    } catch (e) {}
    render();
  }

  function onErr(err) {
    if (err && err.code === 1) lastErr = 'denied';
    else if (err && err.code === 2) lastErr = 'unavailable';
    else if (err && err.code === 3) lastErr = 'timeout';
    else lastErr = 'error';
    render();
  }

  function startWatch() {
    stopWatch();
    if (!('geolocation' in navigator)) {
      lastErr = 'unsupported';
      render();
      return;
    }
    // Prefer continuous watch while this screen is open
    try {
      watchId = navigator.geolocation.watchPosition(onFix, onErr, {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 20000
      });
    } catch (e) {
      lastErr = 'error';
    }
    // Also poll via EpiLocation every 15s as fallback (low power cached)
    pollTimer = setInterval(function () {
      if (!window.EpiLocation) return;
      window.EpiLocation.getOnce({ maxAge: 0, timeout: 12000 }).then(function (r) {
        if (r && r.ok) {
          lastErr = '';
          lastFix = { lat: r.lat, lng: r.lng, accuracy: r.accuracy, t: Date.now() };
          render();
        } else if (r && r.denied) {
          lastErr = 'denied';
          render();
        }
      });
    }, 15000);
  }

  function render() {
    const statusEl = $('liveLocStatus');
    const detailEl = $('liveLocDetail');
    const mapEl = $('liveLocMapLinks');
    if (!statusEl || !detailEl) return;

    if (lastErr === 'denied') {
      statusEl.innerHTML =
        '<span style="color:var(--danger,#b91c1c);">🔴 لوکیشن کی اجازت بند ہے — فون سیٹنگ میں Location آن کریں اور اس ایپ کو اجازت دیں۔</span>';
      detailEl.innerHTML = '';
      if (mapEl) mapEl.innerHTML = '';
      return;
    }
    if (lastErr === 'unsupported') {
      statusEl.innerHTML = '<span style="color:var(--danger,#b91c1c);">🔴 اس ڈیوائس پر GPS دستیاب نہیں۔</span>';
      detailEl.innerHTML = '';
      if (mapEl) mapEl.innerHTML = '';
      return;
    }
    if (lastErr === 'unavailable' || lastErr === 'timeout') {
      statusEl.innerHTML =
        '<span class="note" style="margin:0;">🟡 لوکیشن نہیں مل رہی — GPS آن رکھیں، کھلی جگہ میں جائیں، اور انتظار کریں۔</span>';
    } else if (lastFix && Date.now() - lastFix.t < 60000) {
      statusEl.innerHTML =
        '<span class="ok">🟢 لائیو لوکیشن آن ہے · آخری اپڈیٹ: ' + hm(lastFix.t) + '</span>';
    } else if (lastFix) {
      statusEl.innerHTML =
        '<span class="note" style="margin:0;">🟡 آخری لوکیشن پرانی ہے · GPS چیک کریں · ' + hm(lastFix.t) + '</span>';
    } else {
      statusEl.innerHTML =
        '<span class="note" style="margin:0;">🟡 لوکیشن کا انتظار ہے — فون کی لائیو لوکیشن / GPS آن رکھیں اور ایپ کھلی رکھیں۔</span>';
    }

    if (!lastFix) {
      detailEl.innerHTML = '';
      if (mapEl) mapEl.innerHTML = '';
      return;
    }

    const acc =
      lastFix.accuracy != null && isFinite(lastFix.accuracy)
        ? Math.round(lastFix.accuracy) + ' میٹر'
        : '—';
    detailEl.innerHTML =
      '<div style="font-size:15px;line-height:1.7;">' +
      '<div><b>عرض بلد (Latitude)</b><br><code style="font-size:16px;">' +
      lastFix.lat.toFixed(6) +
      '</code></div>' +
      '<div style="margin-top:10px;"><b>طول بلد (Longitude)</b><br><code style="font-size:16px;">' +
      lastFix.lng.toFixed(6) +
      '</code></div>' +
      '<div style="margin-top:10px;"><b>درستگی (Accuracy)</b><br>' +
      acc +
      '</div>' +
      '<div style="margin-top:10px;"><b>وقت</b><br>' +
      hm(lastFix.t) +
      '</div>' +
      '</div>';

    if (mapEl) {
      const gUrl =
        'https://www.google.com/maps?q=' + lastFix.lat + ',' + lastFix.lng;
      const osmUrl =
        'https://www.openstreetmap.org/?mlat=' +
        lastFix.lat +
        '&mlon=' +
        lastFix.lng +
        '#map=16/' +
        lastFix.lat +
        '/' +
        lastFix.lng;
      mapEl.innerHTML =
        '<a class="go secondary" href="' +
        gUrl +
        '" target="_blank" rel="noopener" style="display:inline-block;margin:4px 4px 4px 0;text-decoration:none;">🗺 Google Maps</a>' +
        '<a class="go secondary" href="' +
        osmUrl +
        '" target="_blank" rel="noopener" style="display:inline-block;margin:4px;text-decoration:none;">🗺 OpenStreetMap</a>';
    }
  }

  function isThisViewVisible() {
    const v = $('villageTrackingView');
    return v && v.style.display !== 'none';
  }

  window.showVillageTrackingView = function () {
    hideAllViews();
    const v = $('villageTrackingView');
    if (v) v.style.display = 'block';
    // Seed from last remembered location immediately
    try {
      if (window.EpiLocation) {
        const l = window.EpiLocation.last();
        if (l) {
          lastFix = { lat: l.lat, lng: l.lng, accuracy: l.accuracy, t: l.t || Date.now() };
        }
      }
    } catch (e) {}
    render();
    startWatch();
    window.scrollTo(0, 0);
  };

  // Stop GPS watch when leaving the screen (hideAllViews is called first)
  const _origHide = typeof hideAllViews === 'function' ? hideAllViews : null;
  // Poll visibility: if user navigates away, stop watch
  setInterval(function () {
    if (!isThisViewVisible()) stopWatch();
  }, 2000);

  const hubBtn = $('btnGoVillageTracking');
  if (hubBtn) {
    hubBtn.addEventListener('click', function () {
      window.showVillageTrackingView();
    });
  }

  const refreshBtn = $('btnLiveLocRefresh');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function () {
      lastErr = '';
      if (window.EpiLocation) {
        window.EpiLocation.getOnce({ maxAge: 0, timeout: 15000 }).then(function (r) {
          if (r && r.ok) {
            lastFix = { lat: r.lat, lng: r.lng, accuracy: r.accuracy, t: Date.now() };
            lastErr = '';
          } else if (r && r.denied) lastErr = 'denied';
          else lastErr = 'unavailable';
          render();
        });
      }
      startWatch();
      render();
    });
  }

  const pushBtn = $('btnLiveLocPush');
  if (pushBtn) {
    pushBtn.addEventListener('click', function () {
      if (window.EpiLocationSync && window.EpiLocationSync.pushOnce) {
        window.EpiLocationSync.pushOnce();
      }
    });
  }
})();
