let selectedFiles = [];

// Adds go straight on: the queued PDFs are processed by themselves and the results menu
// opens. Used after a file is picked, dropped or shared into the app.
let __autoProcessRunning = false;
async function autoProcessAndOpenResults(){
  if (__autoProcessRunning) return;
  if (!selectedFiles.length && !selectedDefaulterFiles.length) return;
  __autoProcessRunning = true;
  try {
    if (typeof window.__epiBusy === 'function') window.__epiBusy(true, 'رپورٹ پروسیس ہو رہی ہے…');
    await new Promise(r => setTimeout(r, 80));
    if (processBtn.dataset.mode === 'forward') processBtn.dataset.mode = '';
    processBtn.click();
    // the button is switched off while the files are being processed; wait until it is back
    const t0 = Date.now();
    while (processBtn.disabled && Date.now() - t0 < 240000) {
      await new Promise(r => setTimeout(r, 300));
    }
    await new Promise(r => setTimeout(r, 150));
    const hadProblem = !!statusEl.querySelector('.err');
    const note = statusEl.textContent;
    if (processBtn.dataset.mode === 'forward') processBtn.click();   // open the results menu
    if (hadProblem && typeof alertDialog === 'function') {
      try { if (typeof window.__epiBusy === 'function') window.__epiBusy(false); } catch (e) {}
      await alertDialog(note);
    }
  } catch (e) {
    console.warn('auto process failed', e);
  } finally {
    try { if (typeof window.__epiBusy === 'function') window.__epiBusy(false); } catch (e) {}
    __autoProcessRunning = false;
  }
}

// Tells the Android app which kind of report the next file chooser is for, so it
// can pick that kind of PDF from the reports folder automatically.
function setPickerSource(src){
  try { if (window.AndroidEpi && typeof window.AndroidEpi.setPickerSource === 'function') window.AndroidEpi.setPickerSource(src); } catch (e) {}
}
function setPickerKind(kind){
  try { if (window.AndroidEpi && typeof window.AndroidEpi.setPickerKind === 'function') window.AndroidEpi.setPickerKind(kind); } catch (e) {}
}
// True when the app picked the files by itself (not the user): already-saved
// files are then skipped quietly instead of asking "Read again?" for each one.
function takeAutoPickFlag(){ const a = !!window.__epiAutoPick; window.__epiAutoPick = false; return a; }

btnPickDaily.addEventListener('click', async () => {
  // If any Daily Immunization Report is already saved, offer Insert or Delete.
  // Insert → phone file picker (Downloads). Delete → saved-files page.
  let savedCount = 0;
  try { savedCount = Object.keys(deriveFileList(loadStore())).length; } catch (e) {}
  if (savedCount > 0) {
    const choice = await chooseInsertOrDelete(
      savedCount + ' Daily Immunization Report file(s) already saved. Insert more, or delete existing?'
    );
    if (choice === 'delete') {
      if (typeof openSavedFilesPage === 'function') openSavedFilesPage('daily');
      return;
    }
    if (choice !== 'insert') return;
  }
  setPickerKind('daily');
  if (window.AndroidEpi && typeof window.AndroidEpi.setPickerSource === 'function') {
    const src = await chooseReportSource();
    if (!src) return;
    // WhatsApp / Storage: the app searches the phone itself and recognises the reports by content
    if ((src === 'whatsapp' || src === 'storage') && typeof window.hasReportFinder === 'function' && window.hasReportFinder()) {
      await window.findReportsOnPhone(src);
      return;
    }
    setPickerSource(src);
  }
  fileInput.click();
});
btnPickDaily.addEventListener('dragover', e => { e.preventDefault(); btnPickDaily.classList.add('drag'); });
btnPickDaily.addEventListener('dragleave', () => btnPickDaily.classList.remove('drag'));
btnPickDaily.addEventListener('drop', e => { e.preventDefault(); btnPickDaily.classList.remove('drag'); addFiles(e.dataTransfer.files); });
fileInput.addEventListener('change', e => addFiles(e.target.files));

async function addFiles(list){
  const auto = takeAutoPickFlag();
  const incoming = Array.from(list).filter(f => (f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf')) && !/defaulter/i.test(f.name));
  // Match on name + size, not name alone — different vaccinators often export
  // same-named "Daily Immunization Registry" PDFs for the same date, and those
  // are different files (different content/size) that must both be allowed in.
  const importedFiles = deriveFileList(loadStore());
  const skipped = [];
  const toAdd = [];
  const alreadySaved = [];
  for (const f of incoming) {
    const alreadyQueued = selectedFiles.some(sf => sf.name === f.name && sf.size === f.size);
    const alreadyImported = !!importedFiles[sourceKey(f.name, f.size)];
    if (alreadyQueued) { skipped.push(f.name); continue; }
    if (alreadyImported) { alreadySaved.push(f); continue; }
    toAdd.push(f);
  }
  // A file that is already saved can be read again. Nothing is duplicated: the
  // records stay as they are and only missing details (such as the EPI No,
  // which older saves did not read) are filled in.
  if (alreadySaved.length && auto) {
    skipped.push(...alreadySaved.map(f => f.name));
  } else if (alreadySaved.length) {
    const names = alreadySaved.map(f => f.name).join(', ');
    const again = await confirmDialog(`Already saved: ${names}. Read again to fill in missing EPI numbers? (Nothing will be duplicated.)`, 'Read again');
    if (again) toAdd.push(...alreadySaved);
    else skipped.push(...alreadySaved.map(f => f.name));
  }
  selectedFiles = selectedFiles.concat(toAdd);
  renderFileList();
  if (auto) {
    statusEl.innerHTML = `✔ ${toAdd.length} new file(s) picked automatically from the reports folder.` +
      (skipped.length ? ` ${skipped.length} already saved/added file(s) skipped.` : '');
  } else {
    statusEl.innerHTML = skipped.length
      ? `<span class="err">Already added, so not added again: ${skipped.map(escapeHtml).join(', ')}</span>`
      : '';
  }
  if (toAdd.length && !window.__epiSuppressAuto) await autoProcessAndOpenResults();
}

const filelistExpandState = { filelist: true, defaultersFilelist: true };

function updateFilelistToggle(toggleId, labelId, listId, count, wasEmpty){
  const toggle = document.getElementById(toggleId);
  const list = document.getElementById(listId);
  const label = document.getElementById(labelId);
  if (count === 0) {
    toggle.style.display = 'none';
    list.style.display = 'none';
    return;
  }
  toggle.style.display = 'flex';
  label.textContent = `${count} file${count === 1 ? '' : 's'} added`;
  if (wasEmpty) filelistExpandState[listId] = true; // auto-expand as soon as files appear
  const expanded = filelistExpandState[listId];
  list.style.display = expanded ? 'block' : 'none';
  toggle.classList.toggle('open', expanded);
}

document.getElementById('filesToggle').addEventListener('click', () => {
  filelistExpandState.filelist = !filelistExpandState.filelist;
  document.getElementById('filelist').style.display = filelistExpandState.filelist ? 'block' : 'none';
  document.getElementById('filesToggle').classList.toggle('open', filelistExpandState.filelist);
});
document.getElementById('defaultersFilesToggle').addEventListener('click', () => {
  filelistExpandState.defaultersFilelist = !filelistExpandState.defaultersFilelist;
  document.getElementById('defaultersFilelist').style.display = filelistExpandState.defaultersFilelist ? 'block' : 'none';
  document.getElementById('defaultersFilesToggle').classList.toggle('open', filelistExpandState.defaultersFilelist);
});

function renderFileList(){
  const prevCount = filelistEl.dataset.count ? parseInt(filelistEl.dataset.count, 10) : 0;
  filelistEl.innerHTML = selectedFiles.map((f, i) => `
    <div class="frow"><span>📄 ${escapeHtml(f.name)}</span><button class="rmbtn" data-i="${i}" title="Remove" aria-label="Remove ${escapeHtml(f.name)}">✕</button></div>
  `).join('');
  filelistEl.querySelectorAll('.rmbtn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedFiles.splice(parseInt(btn.dataset.i,10), 1);
      renderFileList();
      updateProcessButtonState();
    });
  });
  updateFilelistToggle('filesToggle', 'filesToggleLabel', 'filelist', selectedFiles.length, prevCount === 0 && selectedFiles.length > 0);
  filelistEl.dataset.count = selectedFiles.length;
  updateProcessButtonState();
}

// processBtn does double duty: "process the queued files" when files are waiting, or
// "go forward to the results" when nothing is queued but data already exists.
function updateProcessButtonState(){
  if (!processBtn) return;
  const hasQueuedFiles = (typeof selectedFiles !== 'undefined' && selectedFiles.length > 0)
    || (typeof selectedDefaulterFiles !== 'undefined' && selectedDefaulterFiles.length > 0);
  let hasAnySavedData = false;
  try {
    const store = typeof loadStore === 'function' ? loadStore() : {};
    const defs = typeof loadDefaultersStore === 'function' ? loadDefaultersStore() : {};
    hasAnySavedData = !!(store && Object.keys(store).length) || !!(defs && Object.keys(defs).length);
  } catch (e) { hasAnySavedData = false; }
  if (hasQueuedFiles) {
    processBtn.textContent = 'Process and Save Data';
    processBtn.dataset.mode = 'process';
    processBtn.disabled = false;
  } else if (hasAnySavedData) {
    processBtn.textContent = 'Continue ⟶';
    processBtn.dataset.mode = 'forward';
    processBtn.disabled = false;
  } else {
    processBtn.textContent = 'Process and Save Data';
    processBtn.dataset.mode = 'process';
    processBtn.disabled = true;
  }
}

// ---- Defaulters List upload (separate icon + queue, but processed together with the button below) ----
const btnPickDefaulters = document.getElementById('btnPickDefaulters');
const defaultersFileInput = document.getElementById('defaultersFileInput');
const defaultersFilelistEl = document.getElementById('defaultersFilelist');

let selectedDefaulterFiles = [];

btnPickDefaulters.addEventListener('click', async () => {
  let savedCount = 0;
  try { savedCount = Object.keys(deriveDefaulterFileList(loadDefaultersStore())).length; } catch (e) {}
  if (savedCount > 0) {
    const choice = await chooseInsertOrDelete(
      savedCount + ' Children Defaulter Report file(s) already saved. Insert more, or delete existing?'
    );
    if (choice === 'delete') {
      if (typeof openSavedFilesPage === 'function') openSavedFilesPage('defaulters');
      return;
    }
    if (choice !== 'insert') return;
  }
  setPickerKind('defaulters');
  if (window.AndroidEpi && typeof window.AndroidEpi.setPickerSource === 'function') {
    const src = await chooseReportSource('Take the Children Defaulters Report files from:');
    if (!src) return;
    if ((src === 'whatsapp' || src === 'storage') && typeof window.hasReportFinder === 'function' && window.hasReportFinder()) {
      await window.findReportsOnPhone(src);
      return;
    }
    setPickerSource(src);
  }
  defaultersFileInput.click();
});
btnPickDefaulters.addEventListener('dragover', e => { e.preventDefault(); btnPickDefaulters.classList.add('drag'); });
btnPickDefaulters.addEventListener('dragleave', () => btnPickDefaulters.classList.remove('drag'));
btnPickDefaulters.addEventListener('drop', e => { e.preventDefault(); btnPickDefaulters.classList.remove('drag'); addDefaulterFiles(e.dataTransfer.files); });
defaultersFileInput.addEventListener('change', e => addDefaulterFiles(e.target.files));

async function addDefaulterFiles(list){
  const auto = takeAutoPickFlag();
  const incoming = Array.from(list).filter(f => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf'));
  // Unlike the Daily Registry (where re-importing would duplicate visits), the
  // Defaulters List is a SNAPSHOT that replaces entries by id — re-importing it
  // is a normal, safe way to refresh the data. An earlier version blocked this,
  // which made it impossible to re-read an already-imported file (for example
  // to pick up the EPI No). Same file already sitting in the queue is still
  // skipped; an already-imported file is allowed through with a note.
  const importedFiles = deriveDefaulterFileList(loadDefaultersStore());
  const reimported = [];
  const toAdd = [];
  for (const f of incoming) {
    if (selectedDefaulterFiles.some(sf => sf.name === f.name && sf.size === f.size)) continue;
    if (importedFiles[sourceKey(f.name, f.size)]) {
      if (auto) continue;          // auto-pick: leave already-imported files out
      reimported.push(f.name);
    }
    toAdd.push(f);
  }
  selectedDefaulterFiles = selectedDefaulterFiles.concat(toAdd);
  renderDefaulterFileList();
  updateProcessButtonState();
  if (auto) {
    statusEl.innerHTML = `✔ ${toAdd.length} new defaulters file(s) picked automatically from the reports folder.`;
  } else if (reimported.length) {
    statusEl.innerHTML = `Already imported before — it will be read again and the saved defaulters refreshed: ${reimported.map(escapeHtml).join(', ')}`;
  }  if (toAdd.length && !window.__epiSuppressAuto) await autoProcessAndOpenResults();
}

function renderDefaulterFileList(){
  const prevCount = defaultersFilelistEl.dataset.count ? parseInt(defaultersFilelistEl.dataset.count, 10) : 0;
  defaultersFilelistEl.innerHTML = selectedDefaulterFiles.map((f, i) => `
    <div class="frow"><span>📋 ${escapeHtml(f.name)}</span><button class="rmbtn" data-i="${i}" title="Remove" aria-label="Remove ${escapeHtml(f.name)}">✕</button></div>
  `).join('');
  defaultersFilelistEl.querySelectorAll('.rmbtn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedDefaulterFiles.splice(parseInt(btn.dataset.i,10), 1);
      renderDefaulterFileList();
      updateProcessButtonState();
    });
  });
  updateFilelistToggle('defaultersFilesToggle', 'defaultersFilesToggleLabel', 'defaultersFilelist', selectedDefaulterFiles.length, prevCount === 0 && selectedDefaulterFiles.length > 0);
  defaultersFilelistEl.dataset.count = selectedDefaulterFiles.length;
}

// Parses and saves whatever Defaulters List files are queued; returns how
// many were saved in total (across this and previous uploads) and a list of
// any files that failed to read, so the single Process button can report
// one combined status message covering both queues.
async function processDefaulterFilesQueue(onProgress){
  if (!selectedDefaulterFiles.length) return null;
  const defStore = loadDefaultersStoreCopy();
  const failedFiles = [];
  const skippedFiles = [];
  const filesToProcess = selectedDefaulterFiles.slice();

  // Phase 1: read every queued file, reject any page that doesn't actually
  // have the Defaulters List table structure, and note each file's report
  // period + center (for spotting an exact duplicate upload below).
  const fileInfos = [];
  for (const file of filesToProcess) {
    if (onProgress) onProgress(file.name);
    try {
      const buf = await file.arrayBuffer();
      const bytes = new Uint8Array(buf);
      const text = bytesToLatin1(bytes);
      const pages = await getAllPageTextRuns(bytes, text);

      const validPages = pages.filter(isValidDefaulterRuns);
      if (!validPages.length) {
        skippedFiles.push({ name: file.name, reason: 'does not look like a Children Defaulters Report (table headers not found)' });
        continue;
      }

      let recs = [];
      for (const runs of validPages) recs = recs.concat(extractDefaultersFromRuns(runs));
      if (!recs.length) {
        skippedFiles.push({ name: file.name, reason: 'no defaulter rows could be read from this file' });
        continue;
      }

      const normPage = normalizeDefaulterRunsOrientation(validPages[0]);
      const facility = (getFacilityName(normPage) || '').trim().toLowerCase();
      const facilityLabel = (getFacilityName(normPage) || '').trim();    // as written, for display
      const dateRange = extractReportDateRange(normPage);
      const groupKey = dateRange ? `${dateRange}|${facility}` : null;
      fileInfos.push({ file, recs, groupKey, reportEnd: defReportEndMs(dateRange), facility: facilityLabel || null, dateRange: dateRange || null });
    } catch (err) {
      console.error('failed on defaulters file', file.name, err);
      failedFiles.push(file.name);
    }
  }

  // Phase 2: the exact same report period for the exact same center,
  // uploaded more than once in this batch — keep only the copy listing the
  // most children. Files with a different period OR a different center are
  // never affected by this and are all kept.
  const groups = {};
  fileInfos.forEach(info => {
    const key = info.groupKey || `__unique__${info.file.name}|${info.file.size}`;
    (groups[key] = groups[key] || []).push(info);
  });
  const winners = [];
  Object.keys(groups).forEach(key => {
    const list = groups[key];
    if (list.length === 1) { winners.push(list[0]); return; }
    list.sort((a, b) => b.recs.length - a.recs.length);
    winners.push(list[0]);
    for (let i = 1; i < list.length; i++) {
      skippedFiles.push({ name: list[i].file.name, reason: `duplicate report for the same period/center — ${list[0].file.name} lists more children (${list[0].recs.length} vs ${list[i].recs.length}) and was kept instead` });
    }
  });

  // Phase 3: save the winners. Each defaulter is keyed by their QR code
  // (id) — the same child appearing in more than one file is merged into
  // one record instead of the later file silently overwriting the earlier
  // one (see mergeDefaulterRec).
  for (const info of winners) {
    const { file, recs } = info;
    for (const r of recs) {
      r.sources = [{ name: file.name, size: file.size }];
      r.defaultedVaccines = defSortTags(r.defaultedVaccines);     // EPI schedule order
      r.reportFacility = info.facility || null;                   // which center / facility this report is for
      r.reportRange = info.dateRange || null;
      const existing = defStore[r.id];
      // a newer report REPLACES what was saved for this QR code (see defaulter-rules.js)
      defStore[r.id] = applyDefaulterReport(existing || null, r, info.reportEnd);
    }
  }

  const saveOk = saveDefaultersStore(defStore);
  selectedDefaulterFiles = [];
  renderDefaulterFileList();
  defaultersFileInput.value = '';
  renderProcessedFileLists();
  updateStorageNote();
  return { total: Object.keys(defStore).length, failedFiles, skippedFiles, saveOk };
}


// ============================================================
// In-app list of PDF reports (shown by the Android app after the user chose
// SEIR Folder / From Download / From WhatsApp). Works with any file app,
// because the list is drawn here and not by the phone's file picker.
// ============================================================
window.__epiShowPicker = function(json){
  let data;
  try { data = JSON.parse(json); } catch (e) { return; }
  const items = (data && data.items) || [];
  const sel = new Set();
  items.forEach((it, i) => { if (it.suggested) sel.add(i); });
  const bridge = window.AndroidEpi || {};
  let query = '';

  const back = document.createElement('div');
  back.className = 'modal-backdrop';
  back.innerHTML = '<div class="modal-box" role="dialog" aria-modal="true" style="max-width:520px;width:94%;">' +
    '<div class="modal-msg" style="margin-bottom:6px;"></div>' +
    '<input type="search" class="ep-q" placeholder="Search file name…" style="width:100%;box-sizing:border-box;padding:9px;border:1px solid #ccc;border-radius:8px;margin-bottom:8px;font-size:14px;">' +
    '<div class="ep-bar" style="display:flex;gap:8px;margin-bottom:8px;">' +
      '<button type="button" class="ep-all" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:8px;background:#fff;font-weight:600;">☑ Select All</button>' +
      '<button type="button" class="ep-none" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:8px;background:#fff;font-weight:600;">✖ Clear</button>' +
    '</div>' +
    '<div class="ep-list" style="max-height:44vh;overflow:auto;border:1px solid #e3ded5;border-radius:10px;"></div>' +
    '<div class="modal-actions" style="flex-direction:column;gap:8px;margin-top:10px;">' +
      '<button type="button" class="go ep-add">Add Selected (0)</button>' +
      '<button type="button" class="go secondary ep-other" style="background:#fff;color:var(--ink);border:1px solid #ccc;margin-top:0;">📂 Other apps…</button>' +
      '<button type="button" class="go secondary ep-cancel" style="background:transparent;border:none;color:var(--muted);margin-top:0;">Cancel</button>' +
    '</div></div>';

  const msg = back.querySelector('.modal-msg');
  const listEl = back.querySelector('.ep-list');
  const addBtn = back.querySelector('.ep-add');
  msg.textContent = (data.title || 'Choose files') + ' — ' + items.length + ' PDF file(s)';

  function fmtSize(b){ return b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }
  function fmtDate(t){ if (!t) return ''; const d = new Date(t); return d.toLocaleDateString('en-GB') + ' ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }); }

  function render(){
    const q = query.trim().toLowerCase();
    const rows = [];
    items.forEach((it, i) => {
      if (q && it.name.toLowerCase().indexOf(q) === -1) return;
      rows.push('<label style="display:flex;gap:10px;align-items:flex-start;padding:9px 10px;border-bottom:1px solid #eee;">' +
        '<input type="checkbox" data-i="' + i + '"' + (sel.has(i) ? ' checked' : '') + ' style="width:20px;height:20px;margin-top:2px;flex:none;">' +
        '<span style="min-width:0;"><span style="display:block;font-size:14px;word-break:break-all;">' + escapeHtml(it.name) + '</span>' +
        '<span style="display:block;font-size:12px;color:#7a746a;">' + escapeHtml(fmtDate(it.modified)) + (it.size ? ' · ' + fmtSize(it.size) : '') + '</span></span></label>');
    });
    listEl.innerHTML = rows.length ? rows.join('') : '<div style="padding:16px;color:#7a746a;text-align:center;">No PDF files found here.</div>';
    addBtn.textContent = 'Add Selected (' + sel.size + ')';
    addBtn.disabled = sel.size === 0;
  }

  let settled = false;
  function close(){
    if (settled) return; settled = true;
    back.remove();
    const idx = openModalStack.indexOf(onBack);
    if (idx !== -1) openModalStack.splice(idx, 1);
  }
  function onBack(){ try { bridge.pickerCancel && bridge.pickerCancel(); } catch (e) {} close(); }

  listEl.addEventListener('change', e => {
    const cb = e.target.closest('input[data-i]');
    if (!cb) return;
    const i = Number(cb.dataset.i);
    if (cb.checked) sel.add(i); else sel.delete(i);
    addBtn.textContent = 'Add Selected (' + sel.size + ')';
    addBtn.disabled = sel.size === 0;
  });
  back.querySelector('.ep-q').addEventListener('input', e => { query = e.target.value; render(); });
  back.querySelector('.ep-all').addEventListener('click', () => {
    const q = query.trim().toLowerCase();
    items.forEach((it, i) => { if (!q || it.name.toLowerCase().indexOf(q) !== -1) sel.add(i); });
    render();
  });
  back.querySelector('.ep-none').addEventListener('click', () => { sel.clear(); render(); });
  addBtn.addEventListener('click', () => {
    const picked = Array.from(sel).sort((a, b) => a - b);
    try { bridge.pickerDone && bridge.pickerDone(JSON.stringify(picked)); } catch (e) {}
    close();
  });
  back.querySelector('.ep-other').addEventListener('click', () => {
    try { bridge.pickerOtherApps && bridge.pickerOtherApps(); } catch (e) {}
    close();
  });
  back.querySelector('.ep-cancel').addEventListener('click', onBack);

  document.body.appendChild(back);
  openModalStack.push(onBack);
  render();
};

// ============================================================
// Files shared into the app from any other app (Share / Open with).
// The Android app keeps them and calls this; names with "defaulter" go to the
// Children Defaulters queue, everything else to the Daily Immunization queue.
// They are only queued — the user presses "Process and Save Data" as usual.
// ============================================================
window.__epiSharedReady = async function(){
  const b = window.AndroidEpi;
  if (!b || typeof b.sharedCount !== 'function') return;
  const n = parseInt(b.sharedCount(), 10) || 0;
  if (!n) return;
  const daily = [], defs = [];
  for (let i = 0; i < n; i++) {
    try {
      const name = String(b.sharedName(i) || ('shared-' + i + '.pdf'));
      const b64 = b.sharedBase64(i);
      if (!b64) continue;
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let k = 0; k < bin.length; k++) bytes[k] = bin.charCodeAt(k);
      const file = new File([bytes], /\.pdf$/i.test(name) ? name : name + '.pdf', { type: 'application/pdf' });
      (/defaulter/i.test(name) ? defs : daily).push(file);
    } catch (e) { console.warn('shared file failed', e); }
  }
  try { b.sharedClear && b.sharedClear(); } catch (e) {}
  if (!daily.length && !defs.length) return;

  // Bring the Insert screen to the front.
  try {
    ['resultsWrap','qrMenuView','qrCodeSection','qrDeleteView','savedFilesSection'].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
    const up = document.getElementById('uploadView'); if (up) up.style.display = 'block';
    window.scrollTo(0, 0);
  } catch (e) {}

  window.__epiSuppressAuto = true;        // one combined processing at the end
  window.__epiAutoPick = true;            // quietly skip files that are already saved
  if (daily.length) await addFiles(daily);
  window.__epiAutoPick = true;
  if (defs.length) await addDefaulterFiles(defs);
  window.__epiAutoPick = false;
  window.__epiSuppressAuto = false;
  try {
    statusEl.innerHTML = '✔ ' + (daily.length + defs.length) + ' file(s) received from another app (' + daily.length + ' daily, ' + defs.length + ' defaulters).';
  } catch (e) {}

  // Files shared in (for example from the SEIR app) are processed straight away and the
  // results open — no permission, no extra taps.
  await autoProcessAndOpenResults();
};
// If the app was opened by a share, the Android side calls __epiSharedReady itself;
// this catches the case where the files were already waiting when the page loaded.
setTimeout(function(){ try { window.__epiSharedReady(); } catch (e) {} }, 600);
