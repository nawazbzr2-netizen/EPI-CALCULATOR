package org.zm.calculator

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * "Document scanner" clean-up of a photo, done fully on the phone (no internet):
 *  - [scanLook]      shadows and uneven light removed, contrast stretched, sharpened
 *                    (the "Auto / Magic colour" look of a scanner app)
 *  - [blackAndWhite] pure black on white, adaptive to local light (the "B&W document" look)
 * The picture keeps its size, so positions found in it match the original.
 */
object ImageCleaner {

    private fun grayOf(src: Bitmap): IntArray {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            px[i] = (r * 299 + g * 587 + b * 114) / 1000
        }
        return px
    }

    // running sums, so the average of any rectangle is found in O(1)
    private fun integralOf(v: IntArray, w: Int, h: Int): IntArray {
        val iw = w + 1
        val out = IntArray(iw * (h + 1))
        for (y in 1..h) {
            var rowSum = 0
            val base = y * iw
            val prev = (y - 1) * iw
            val src = (y - 1) * w
            for (x in 1..w) {
                rowSum += v[src + x - 1]
                out[base + x] = out[prev + x] + rowSum
            }
        }
        return out
    }

    private fun boxMean(integral: IntArray, w: Int, h: Int, x: Int, y: Int, r: Int): Int {
        val iw = w + 1
        val x0 = max(0, x - r)
        val y0 = max(0, y - r)
        val x1 = min(w, x + r + 1)
        val y1 = min(h, y + r + 1)
        val area = (x1 - x0) * (y1 - y0)
        val sum = integral[y1 * iw + x1] - integral[y0 * iw + x1] - integral[y1 * iw + x0] + integral[y0 * iw + x0]
        return sum / area
    }

    private fun toBitmap(gray: IntArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (i in px.indices) {
            val g = gray[i].coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Evens out the light: every pixel is compared with the paper around it. */
    private fun flatten(gray: IntArray, w: Int, h: Int): IntArray {
        val integral = integralOf(gray, w, h)
        val r = max(24, min(w, h) / 10)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val bg = max(1, boxMean(integral, w, h, x, y, r))
                out[y * w + x] = min(255, gray[y * w + x] * 255 / bg)
            }
        }
        return out
    }

    fun scanLook(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val flat = flatten(grayOf(src), w, h)

        // stretch contrast between the darkest and the lightest 1 %
        val hist = IntArray(256)
        for (v in flat) hist[v.coerceIn(0, 255)]++
        val total = flat.size
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[lo] < total / 100) { acc += hist[lo]; lo++ }
        acc = 0
        var hi = 255
        while (hi > 1 && acc + hist[hi] < total / 100) { acc += hist[hi]; hi-- }
        if (hi - lo < 40) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()
        for (i in flat.indices) flat[i] = (((flat[i] - lo) / span) * 255f).toInt().coerceIn(0, 255)

        // sharpen: add back the difference from a slightly blurred copy
        val integral = integralOf(flat, w, h)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val blur = boxMean(integral, w, h, x, y, 2)
                val v = flat[y * w + x]
                out[y * w + x] = (v + 1.4f * (v - blur)).toInt().coerceIn(0, 255)
            }
        }
        return toBitmap(out, w, h)
    }

    fun blackAndWhite(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val gray = grayOf(src)
        val integral = integralOf(gray, w, h)
        val r = max(20, min(w, h) / 24)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val mean = boxMean(integral, w, h, x, y, r)
                out[y * w + x] = if (gray[y * w + x] < mean * 90 / 100 - 4) 0 else 255
            }
        }
        return toBitmap(out, w, h)
    }
}
